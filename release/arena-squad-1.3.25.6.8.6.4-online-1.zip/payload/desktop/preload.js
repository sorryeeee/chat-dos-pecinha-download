const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("arenaDesktop", {
  getRuntimeInfo: () =>
    ipcRenderer.invoke(
      "runtime:get-info"
    ),

  getSystemIdleState: () =>
    ipcRenderer.invoke(
      "system:get-idle-state"
    ),

  onSystemIdleState: callback => {
    const handler =
      (_event, snapshot) => {
        callback(snapshot);
      };

    ipcRenderer.on(
      "system:idle-state",
      handler
    );

    return () => {
      ipcRenderer.removeListener(
        "system:idle-state",
        handler
      );
    };
  },

  setAppFullscreen: enabled =>
    ipcRenderer.invoke(
      "window:set-fullscreen",
      enabled === true
    ),

  onAppFullscreenChanged: callback => {
    const handler =
      (_event, enabled) => {
        callback(
          enabled === true
        );
      };

    ipcRenderer.on(
      "window:fullscreen-changed",
      handler
    );

    return () => {
      ipcRenderer.removeListener(
        "window:fullscreen-changed",
        handler
      );
    };
  },


  getScreenSources: () =>
    ipcRenderer.invoke("screen:get-sources"),

  setSelectedScreenSource: sourceId =>
    ipcRenderer.invoke(
      "screen:set-selected-source",
      sourceId
    ),

  consumeScreenCaptureGrant: () =>
    ipcRenderer.invoke(
      "screen:consume-capture-grant"
    ),

  startIsolatedAudio: sourceId =>
    ipcRenderer.invoke(
      "screen:start-isolated-audio",
      sourceId
    ),

  stopIsolatedAudio: () =>
    ipcRenderer.invoke(
      "screen:stop-isolated-audio"
    ),

  onIsolatedAudioData: callback => {
    const handler = (_event, bytes) => {
      callback(bytes);
    };

    ipcRenderer.on(
      "screen:isolated-audio-data",
      handler
    );

    return () => {
      ipcRenderer.removeListener(
        "screen:isolated-audio-data",
        handler
      );
    };
  },

  getServerUrl: () =>
    ipcRenderer.invoke(
      "config:get-server-url"
    ),

  getTailscaleIP: () => ipcRenderer.invoke("tailscale:get-ip"),
  saveRememberedLogin: (login) =>
    ipcRenderer.invoke("auth:save-remembered", login),
  loadRememberedLogin: () =>
    ipcRenderer.invoke("auth:load-remembered"),
  clearRememberedLogin: () =>
    ipcRenderer.invoke("auth:clear-remembered"),
  notify: (title, body) =>
    ipcRenderer.invoke("system:notify", { title, body }),
  urgentCall: (from, recipient) =>
    ipcRenderer.invoke("system:urgent-call", {
      from,
      recipient
    }),
  sosoHeadsetAlert: () =>
    ipcRenderer.invoke("system:soso-headset-alert")
});
