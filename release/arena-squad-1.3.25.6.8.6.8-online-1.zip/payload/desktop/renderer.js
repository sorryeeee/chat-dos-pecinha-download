let PLAYERS = ["sorrye", "dealer", "taka", "sage", "gordao trem balinha"];

let me = "";
let lastProfile = localStorage.getItem("arena-player") || "";
let authenticated = false;
let rememberedToken = "";
let rememberedPlayer = "";
let pendingAuthProfile = "";
let authRequestTimer = null;
const CLIENT_PROTOCOL_VERSION = 14;
let localAppVersion = "";
let serverProtocolVersion = 0;
let serverAppVersion = "";
let versionPolicy = null;
let clientVersions = {};
let mandatoryUpdateRequired = false;
let updateLaunching = false;
let createUserRequestTimer = null;
let changePasswordRequestTimer = null;
let deleteUserRequestTimer = null;
let loginAuthRequested = false;
let appEntered = false;
let presence = Object.fromEntries(
  PLAYERS.map(p => [
    p,
    {
      status: "unset",
      targetAt: null,
      customText: "",
      activity: "unset"
    }
  ])
);
let presenceTicker = null;
let online = Object.fromEntries(
  PLAYERS.map(p => [p, false])
);
let computerPresence = Object.fromEntries(
  PLAYERS.map(p => [
    p,
    {
      state: "offline",
      idleSeconds: 0,
      updatedAt: null
    }
  ])
);
let localSystemIdleState = {
  state: "online",
  idleSeconds: 0,
  thresholdSeconds: 300,
  at: Date.now()
};
let lastIdleStateSent = "";
let lastIdleHeartbeatAt = 0;
let lastSeen = Object.fromEntries(
  PLAYERS.map(p => [p, null])
);
let sharing = Object.fromEntries(PLAYERS.map(p => [p, false]));
let socket = null;
let myTailscaleIP = "";

let activeServerUrl = "";
let serverLatencyMs = null;
let latencyTimer = null;
const recentActivities = [];
const MAX_RECENT_ACTIVITIES = 12;
let previousComputerPresence = {};
let previousSharingState = {};
let previousVoiceMembers = {};

const PERFORMANCE_SETTINGS_STORAGE_KEY =
  "chat-dos-pecinha-performance-v1";

const DEFAULT_PERFORMANCE_SETTINGS =
  Object.freeze({
    lowEndMode: false,
    reduceEffects: false,
    hideLocalPreview: false,
    limitOneStream: false,
    slowUiUpdates: false,
    forceLowQuality: false
  });

function loadPerformanceSettings() {
  try {
    const raw =
      localStorage.getItem(
        PERFORMANCE_SETTINGS_STORAGE_KEY
      );

    if (!raw) {
      return {
        ...DEFAULT_PERFORMANCE_SETTINGS
      };
    }

    const parsed =
      JSON.parse(raw);

    return {
      ...DEFAULT_PERFORMANCE_SETTINGS,
      ...(parsed || {})
    };
  } catch {
    return {
      ...DEFAULT_PERFORMANCE_SETTINGS
    };
  }
}

let performanceSettings =
  loadPerformanceSettings();
let currentDashboardTab = "homeTab";

// Voice call state
let voiceMembers = {};
let voiceLocalStream = null;
let voiceMuted = false;
let voiceDeafened = false;
let voiceJoining = false;

// Local voice UI sounds are synthesized with Web Audio, so the
// app does not need to ship separate sound files.
let voiceCueContext = null;

// Microphone self-test state.
let voiceMicTestActive = false;
let voiceMicTestStream = null;
let voiceMicTestRecorder = null;
let voiceMicTestContext = null;
let voiceMicTestSource = null;
let voiceMicTestAnalyser = null;
let voiceMicTestAnimation = null;
let voiceMicTestTimer = null;
let voiceMicTestPlaybackUrl = "";
let voiceMicTestChunks = [];

const voicePeers = new Map();
const voicePendingIce = new Map();
const voiceRemoteStreams = new Map();
const voiceAudioElements = new Map();

// Per-listener volume controls. These values never leave this PC.
let voiceOutputContext = null;
const voiceRemoteSources = new Map();
const voiceRemoteGains = new Map();
let voiceUserVolumes = {};
let voiceVolumeLoadedFor = "";

// Screen share state
let localStream = null;
let fullscreenStreamPlayer = "";

// Transmission presets are local to this PC and never leave the
// renderer except through the resulting WebRTC media parameters.
const SCREEN_QUALITY_STORAGE_KEY =
  "arena-screen-quality-v1";

const SCREEN_QUALITY_PRESETS =
  Object.freeze({
    low: Object.freeze({
      key: "low",
      label: "Leve",
      resolutionLabel: "480p",
      width: 854,
      height: 480,
      fps: 30,
      maxBitrate: 1_200_000,
      degradationPreference:
        "maintain-framerate",
      contentHint: "motion",
      hint:
        "480p · 30 FPS · até 1,2 Mbps · ideal para PC fraco"
    }),
    balanced: Object.freeze({
      key: "balanced",
      label: "Balanceado",
      resolutionLabel: "720p",
      width: 1280,
      height: 720,
      fps: 30,
      maxBitrate: 2_500_000,
      degradationPreference:
        "balanced",
      contentHint: "detail",
      hint:
        "720p · 30 FPS · até 2,5 Mbps · recomendado"
    }),
    smooth: Object.freeze({
      key: "smooth",
      label: "Fluido",
      resolutionLabel: "720p",
      width: 1280,
      height: 720,
      fps: 60,
      maxBitrate: 4_000_000,
      degradationPreference:
        "maintain-framerate",
      contentHint: "motion",
      hint:
        "720p · 60 FPS · até 4 Mbps · mais fluidez"
    }),
    quality: Object.freeze({
      key: "quality",
      label: "Qualidade",
      resolutionLabel: "1080p",
      width: 1920,
      height: 1080,
      fps: 30,
      maxBitrate: 4_500_000,
      degradationPreference:
        "maintain-resolution",
      contentHint: "detail",
      hint:
        "1080p · 30 FPS · até 4,5 Mbps · mais nitidez"
    }),
    max: Object.freeze({
      key: "max",
      label: "Máximo",
      resolutionLabel: "1080p",
      width: 1920,
      height: 1080,
      fps: 60,
      maxBitrate: 8_000_000,
      degradationPreference:
        "balanced",
      contentHint: "motion",
      hint:
        "1080p · 60 FPS · até 8 Mbps · exige mais do PC"
    })
  });

let screenQualityKey =
  localStorage.getItem(
    SCREEN_QUALITY_STORAGE_KEY
  ) || "balanced";

if (
  !Object.prototype.hasOwnProperty.call(
    SCREEN_QUALITY_PRESETS,
    screenQualityKey
  )
) {
  screenQualityKey =
    "balanced";
}

let isolatedAudioContext = null;
let isolatedAudioProcessor = null;
let isolatedAudioDestination = null;
let isolatedAudioUnsubscribe = null;
let isolatedAudioQueue = [];
let isolatedAudioQueueSamples = 0;
let isolatedAudioCurrentChunk = null;
let isolatedAudioCurrentOffset = 0;

// Multiple incoming WebRTC streams can now be open together.
const watchedSharers = new Set();
const receiverPeers = new Map();
const remoteStreams = new Map();
const receiverStatus = new Map();
const remoteAudioEnabled = new Map();

const senderPeers = new Map();
const pendingIce = new Map();
const activeViewers = new Set();

const $ = id => document.getElementById(id);


function savePerformanceSettings() {
  localStorage.setItem(
    PERFORMANCE_SETTINGS_STORAGE_KEY,
    JSON.stringify(
      performanceSettings
    )
  );
}

function syncLocalPreviewPerformance() {
  const video =
    $("localVideo");

  const wrap =
    $("localPreviewWrap");

  const placeholder =
    $("screenPreviewPlaceholder");

  const hidePreview =
    !!(
      localStream &&
      performanceSettings
        .hideLocalPreview
    );

  if (video) {
    video.srcObject =
      localStream &&
      !hidePreview
        ? localStream
        : null;
  }

  if (wrap) {
    wrap.classList.toggle(
      "hidden",
      !localStream ||
      hidePreview
    );
  }

  if (placeholder) {
    placeholder.classList.toggle(
      "hidden",
      !!localStream &&
      !hidePreview
    );

    placeholder.classList.toggle(
      "performance-preview-disabled",
      hidePreview
    );

    const title =
      placeholder.querySelector(
        "strong"
      );

    const text =
      placeholder.querySelector(
        "span"
      );

    if (hidePreview) {
      if (title) {
        title.textContent =
          "Preview desativado";
      }

      if (text) {
        text.textContent =
          "Modo de desempenho: a transmissão continua ativa.";
      }
    } else {
      if (title) {
        title.textContent =
          "Pré-visualização";
      }

      if (text) {
        text.textContent =
          "Sua tela será exibida aqui";
      }
    }
  }
}

function renderPerformanceSettings() {
  const map = {
    perfLowEndMode:
      "lowEndMode",
    perfReduceEffects:
      "reduceEffects",
    perfHideLocalPreview:
      "hideLocalPreview",
    perfLimitOneStream:
      "limitOneStream",
    perfSlowUiUpdates:
      "slowUiUpdates",
    perfForceLowQuality:
      "forceLowQuality"
  };

  for (
    const [id, key] of
    Object.entries(map)
  ) {
    const input =
      $(id);

    if (input) {
      input.checked =
        !!performanceSettings[key];
    }
  }

  document.body.classList.toggle(
    "performance-lite",
    !!performanceSettings
      .reduceEffects
  );

  if ($("perfModeSummary")) {
    const enabledCount =
      [
        "reduceEffects",
        "hideLocalPreview",
        "limitOneStream",
        "slowUiUpdates",
        "forceLowQuality"
      ]
        .filter(
          key =>
            !!performanceSettings[
              key
            ]
        )
        .length;

    $("perfModeSummary").textContent =
      performanceSettings
        .lowEndMode
        ? (
            "Modo PC Fraco ativo: " +
            `${enabledCount}/5 otimizações ligadas.`
          )
        : (
            enabledCount
              ? `${enabledCount}/5 otimizações individuais ativas.`
              : "Modo normal: todos os recursos visuais ativos."
          );
  }

  syncLocalPreviewPerformance();
}

function updatePerformanceSetting(
  key,
  enabled
) {
  performanceSettings = {
    ...performanceSettings,
    [key]:
      enabled === true
  };

  if (
    key !== "lowEndMode"
  ) {
    const allRecommended =
      performanceSettings
        .reduceEffects &&
      performanceSettings
        .hideLocalPreview &&
      performanceSettings
        .limitOneStream &&
      performanceSettings
        .slowUiUpdates &&
      performanceSettings
        .forceLowQuality;

    performanceSettings
      .lowEndMode =
      allRecommended;
  }

  savePerformanceSettings();
  renderPerformanceSettings();

  if (
    key === "slowUiUpdates" ||
    key === "lowEndMode"
  ) {
    startPresenceTicker();
  }

  if (
    key === "forceLowQuality" &&
    enabled &&
    !localStream
  ) {
    setScreenQualityPreset(
      "low"
    );
  }
}

function setLowEndMode(
  enabled
) {
  const active =
    enabled === true;

  performanceSettings = {
    ...performanceSettings,
    lowEndMode: active,
    reduceEffects: active,
    hideLocalPreview: active,
    limitOneStream: active,
    slowUiUpdates: active,
    forceLowQuality: active
  };

  savePerformanceSettings();

  if (
    active &&
    !localStream
  ) {
    setScreenQualityPreset(
      "low"
    );
  }

  renderPerformanceSettings();
  startPresenceTicker();
}


function relativeActivityTime(timestamp) {
  const value = Number(timestamp) || Date.now();
  const seconds = Math.max(0, Math.floor((Date.now() - value) / 1000));
  if (seconds < 10) return "Agora";
  if (seconds < 60) return `${seconds}s atrás`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} min atrás`;
  return `${Math.floor(minutes / 60)}h atrás`;
}

function addRecentActivity(text, type = "info", timestamp = Date.now()) {
  const clean = String(text || "").replace(/\s+/g, " ").trim().slice(0, 140);
  if (!clean) return;
  const latest = recentActivities[0];
  if (latest && latest.text === clean && Date.now() - latest.timestamp < 1500) return;
  recentActivities.unshift({ text: clean, type, timestamp: Number(timestamp) || Date.now() });
  if (recentActivities.length > MAX_RECENT_ACTIVITIES) recentActivities.length = MAX_RECENT_ACTIVITIES;
  renderActivityFeed();
}

function renderActivityFeed() {
  const holder = $("activityFeed");
  if (!holder) return;
  holder.innerHTML = "";
  if (!recentActivities.length) {
    const empty = document.createElement("div");
    empty.className = "activity-empty";
    empty.textContent = "Nenhuma atividade recente.";
    holder.appendChild(empty);
    return;
  }
  for (const activity of recentActivities.slice(0, 5)) {
    const item = document.createElement("div");
    item.className = `serious-activity-item activity-${activity.type}`;
    const icon = activity.type === "online" ? "●" : activity.type === "away" ? "◐" : activity.type === "voice" ? "☎" : activity.type === "stream" ? "▣" : activity.type === "chat" ? "◌" : "•";
    item.innerHTML = `<span class="activity-item-icon">${icon}</span><span class="activity-item-copy"><strong>${escapeHtml(activity.text)}</strong><small>${escapeHtml(relativeActivityTime(activity.timestamp))}</small></span>`;
    holder.appendChild(item);
  }
}

function diffComputerPresence(next) {
  const old = previousComputerPresence || {};
  for (const player of Object.keys(next || {})) {
    const before = old[player]?.state;
    const after = next[player]?.state;
    if (before && after && before !== after) {
      addRecentActivity(after === "away" ? `${player} ficou ausente` : `${player} voltou e está online`, after === "away" ? "away" : "online");
    }
  }
  previousComputerPresence = structuredClone(next || {});
}

function diffSharingState(next) {
  const old = previousSharingState || {};
  const players = new Set([...Object.keys(old), ...Object.keys(next || {})]);
  for (const player of players) {
    const before = !!old[player];
    const after = !!next?.[player];
    if (before !== after) addRecentActivity(after ? `${player} iniciou uma transmissão` : `${player} encerrou a transmissão`, "stream");
  }
  previousSharingState = { ...(next || {}) };
}

function diffVoiceMembers(next) {
  const oldPlayers = new Set(Object.keys(previousVoiceMembers || {}));
  const newPlayers = new Set(Object.keys(next || {}));
  for (const player of newPlayers) if (!oldPlayers.has(player)) addRecentActivity(`${player} entrou no Voice Call`, "voice");
  for (const player of oldPlayers) if (!newPlayers.has(player)) addRecentActivity(`${player} saiu do Voice Call`, "voice");
  previousVoiceMembers = structuredClone(next || {});
}

function setCollapsiblePanel(panelId, open) {
  const panel = $(panelId);
  if (!panel) return;
  panel.classList.toggle("panel-open", open === true);
  if (open) panel.scrollIntoView({ behavior: "smooth", block: "start" });
}

async function measureServerLatency() {
  if (!activeServerUrl) return;
  const started = performance.now();
  try {
    const response = await fetch(`${activeServerUrl}/health?ts=${Date.now()}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    serverLatencyMs = Math.max(1, Math.round(performance.now() - started));
  } catch { serverLatencyMs = null; }
  if ($("footerLatency")) $("footerLatency").textContent = serverLatencyMs == null ? "— ms" : `${serverLatencyMs} ms`;
}

function startLatencyMonitor() {
  if (latencyTimer) clearInterval(latencyTimer);
  measureServerLatency();
  latencyTimer = setInterval(measureServerLatency, 15000);
}


function ensureClientPlayerState() {
  for (const player of PLAYERS) {
    if (!presence[player]) {
      presence[player] = {
        status: "unset",
        targetAt: null,
        customText: "",
        activity: "unset"
      };
    }

    if (typeof online[player] !== "boolean") {
      online[player] = false;
    }

    if (!computerPresence[player]) {
      computerPresence[player] = {
        state: "offline",
        idleSeconds: 0,
        updatedAt: null
      };
    }

    if (!Object.prototype.hasOwnProperty.call(
      lastSeen,
      player
    )) {
      lastSeen[player] = null;
    }

    if (typeof sharing[player] !== "boolean") {
      sharing[player] = false;
    }
  }
}

function setPlayers(nextPlayers) {
  if (!Array.isArray(nextPlayers)) return;

  const clean = nextPlayers
    .map(value => String(value || "").trim())
    .filter(Boolean);

  if (!clean.length) return;

  PLAYERS = [...new Set(clean)];
  ensureClientPlayerState();

  if (
    rememberedPlayer &&
    !PLAYERS.includes(rememberedPlayer)
  ) {
    const deletedRemembered = rememberedPlayer;

    rememberedToken = "";
    rememberedPlayer = "";

    if (lastProfile === deletedRemembered) {
      lastProfile = "";
    }

    window.arenaDesktop
      ?.clearRememberedLogin?.()
      .catch?.(() => {});

    if (!authenticated && $("loginError")) {
      $("loginError").textContent =
        `A conta ${deletedRemembered} não existe mais.`;
    }
  }

  renderLoginPlayers();
  renderDeleteUserOptions();

  // Remembered login is intentionally NOT authenticated here.
  // The user must explicitly click "Entrar".
}

function clearCreateUserTimer() {
  if (createUserRequestTimer) {
    clearTimeout(createUserRequestTimer);
    createUserRequestTimer = null;
  }
}

function openCreateUserModal() {
  $("createUsername").value = "";
  $("createPassword").value = "";
  $("createPasswordConfirm").value = "";
  $("createUserError").textContent = "";
  $("createUserSubmit").disabled = false;
  $("createUserModal").classList.remove("hidden");

  setTimeout(() => {
    $("createUsername").focus();
  }, 30);
}

function closeCreateUserModal() {
  clearCreateUserTimer();
  $("createUserModal").classList.add("hidden");
  $("createUserError").textContent = "";
  $("createUserSubmit").disabled = false;
}

function failCreateUser(message) {
  clearCreateUserTimer();
  $("createUserSubmit").disabled = false;
  $("createUserError").textContent = message;
}

function submitCreateUser(username, password) {
  if (!socket?.connected) {
    failCreateUser(
      "Servidor desconectado. O HOST precisa estar online."
    );
    return;
  }

  $("createUserSubmit").disabled = true;
  $("createUserError").textContent =
    "Criando usuário...";

  clearCreateUserTimer();

  createUserRequestTimer = setTimeout(() => {
    failCreateUser(
      "O servidor não respondeu. Tente novamente."
    );
  }, 8000);

  socket.emit("create-user", {
    username,
    password
  });
}

const RTC_CONFIG = {
  // Tailscale remains the preferred private path.
  // Public STUN is only a fallback candidate discovery path.
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" }
  ],
  iceTransportPolicy: "all",
  iceCandidatePoolSize: 4
};

function candidateToObject(candidate) {
  if (!candidate) return null;

  if (typeof candidate.toJSON === "function") {
    return candidate.toJSON();
  }

  return {
    candidate: candidate.candidate,
    sdpMid: candidate.sdpMid,
    sdpMLineIndex: candidate.sdpMLineIndex,
    usernameFragment: candidate.usernameFragment
  };
}

function makeTailscaleCandidate(candidate) {
  if (!candidate || !myTailscaleIP) return null;

  const raw = candidate.candidate || "";
  const parts = raw.split(" ");

  // candidate:<foundation> <component> <protocol> <priority>
  // <address> <port> typ <type> ...
  if (parts.length < 8 || parts[6] !== "typ" || parts[7] !== "host") {
    return null;
  }

  if (parts[4] === myTailscaleIP) {
    return null;
  }

  parts[4] = myTailscaleIP;

  const result = candidateToObject(candidate);
  result.candidate = parts.join(" ");
  return result;
}

function emitIceCandidate(to, candidate, purpose = "offerer") {
  if (!candidate || !socket?.connected || !me) return;

  const normal = candidateToObject(candidate);

  socket.emit("webrtc-ice", {
    from: me,
    to,
    candidate: normal,
    purpose
  });

  // Chromium can advertise host candidates through mDNS or omit the
  // useful 100.x address in signaling. Mirror every host socket candidate
  // with our authenticated Tailscale IPv4 so the peer can reach the same
  // WebRTC socket through the tailnet.
  const tailscaleCandidate = makeTailscaleCandidate(candidate);

  if (tailscaleCandidate) {
    console.log(
      "Enviando candidato WebRTC via Tailscale:",
      myTailscaleIP,
      tailscaleCandidate.candidate
    );

    socket.emit("webrtc-ice", {
      from: me,
      to,
      candidate: tailscaleCandidate,
      purpose
    });
  }
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function timeOf(iso) {
  return new Date(iso).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit"
  });
}


function normalizePresence(value) {
  const fallback = {
    status: "unset",
    targetAt: null,
    customText: "",
    activity: "unset"
  };

  if (
    value &&
    typeof value === "object" &&
    typeof value.status === "string"
  ) {
    return {
      status: value.status,
      targetAt:
        Number.isFinite(Number(value.targetAt))
          ? Number(value.targetAt)
          : null,
      customText:
        typeof value.customText === "string"
          ? value.customText
          : "",
      activity:
        typeof value.activity === "string"
          ? value.activity
          : "unset"
    };
  }

  // Compatibilidade temporária com versões antigas.
  if (value === true) {
    return {
      ...fallback,
      status: "playing"
    };
  }

  return fallback;
}

function presenceInfo(player) {
  return normalizePresence(presence[player]);
}

function formatClock(ms) {
  return new Date(ms).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit"
  });
}

function countdownText(targetAt) {
  const diff = Number(targetAt) - Date.now();

  if (!Number.isFinite(diff)) return "";
  if (diff <= 0) return "horário chegou";

  const totalSeconds = Math.ceil(diff / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) {
    return `${hours}h ${String(minutes).padStart(2, "0")}m ${String(seconds).padStart(2, "0")}s`;
  }

  return `${minutes}m ${String(seconds).padStart(2, "0")}s`;
}

function presenceDisplay(player) {
  const info = presenceInfo(player);

  if (info.status === "playing") {
    return {
      icon: "✅",
      text: "Vou jogar agora",
      css: "status-playing"
    };
  }

  if (info.status === "not_now") {
    return {
      icon: "🟡",
      text: "Não vou jogar agora",
      css: "status-not-now"
    };
  }

  if (info.status === "not_today") {
    return {
      icon: "❌",
      text: "Não vou jogar hoje",
      css: "status-not-today"
    };
  }

  if (info.status === "later" && info.targetAt) {
    return {
      icon: "⏰",
      text: `Entro às ${formatClock(info.targetAt)} · ${countdownText(info.targetAt)}`,
      css: "status-later"
    };
  }

  if (
    info.status === "custom" &&
    info.customText
  ) {
    return {
      icon: "💬",
      text: info.customText,
      css: "status-custom"
    };
  }

  return {
    icon: "—",
    text: "Sem status",
    css: "status-unset"
  };
}

function formatIdleDuration(seconds) {
  const total = Math.max(0, Math.floor(Number(seconds) || 0));

  if (total < 60) return "menos de 1 min";

  const minutes = Math.floor(total / 60);
  if (minutes < 60) return `${minutes} min`;

  const hours = Math.floor(minutes / 60);
  const restMinutes = minutes % 60;

  if (hours < 24) {
    return restMinutes
      ? `${hours}h ${restMinutes}min`
      : `${hours}h`;
  }

  return `${Math.floor(hours / 24)}d`;
}

function playerComputerPresenceDisplay(player) {
  if (!online[player]) {
    return {
      icon: "◷",
      text: formatLastSeen(lastSeen[player]),
      css: "activity-offline"
    };
  }

  const info = computerPresence[player] || {};

  if (info.state === "away") {
    const updatedAt = Number(info.updatedAt) || Date.now();
    const elapsed = Math.max(
      0,
      Math.floor((Date.now() - updatedAt) / 1000)
    );
    const idleSeconds = Math.max(
      300,
      Number(info.idleSeconds) || 0
    ) + elapsed;

    return {
      icon: "●",
      text: `Ausente · ${formatIdleDuration(idleSeconds)} sem atividade`,
      css: "activity-away activity-auto"
    };
  }

  return {
    icon: "●",
    text: "Online",
    css: "activity-online activity-auto"
  };
}

function playerManualActivityDisplay(player) {
  const info = presenceInfo(player);
  const states = {
    giving_butt: {
      icon: "🍑",
      text: "Dando a bunda",
      css: "activity-giving-butt"
    },
    delivery: {
      icon: "📦",
      text: "Fazendo entrega",
      css: "activity-delivery"
    },
    ana: {
      icon: "💗",
      text: "Ana",
      css: "activity-ana"
    },
    poop: {
      icon: "🚽",
      text: "Fui cagar rapidinho",
      css: "activity-poop"
    }
  };

  return states[info.activity] || null;
}

function normalizeSystemIdleSnapshot(snapshot) {
  const idleSeconds = Math.max(
    0,
    Math.floor(Number(snapshot?.idleSeconds) || 0)
  );
  const thresholdSeconds = Math.max(
    300,
    Number(snapshot?.thresholdSeconds) || 300
  );

  return {
    state:
      idleSeconds >= thresholdSeconds || snapshot?.state === "away"
        ? "away"
        : "online",
    idleSeconds,
    thresholdSeconds,
    at: Number(snapshot?.at) || Date.now()
  };
}

function sendLocalComputerPresence(force = false) {
  if (!me || !authenticated || !socket?.connected) return;

  const state =
    localSystemIdleState.state === "away"
      ? "away"
      : "online";
  const now = Date.now();

  if (
    !force &&
    state === lastIdleStateSent &&
    now - lastIdleHeartbeatAt < 30_000
  ) {
    return;
  }

  socket.emit("client-idle-state", {
    state,
    idleSeconds: localSystemIdleState.idleSeconds
  });

  lastIdleStateSent = state;
  lastIdleHeartbeatAt = now;
}

function handleSystemIdleSnapshot(snapshot) {
  const previousState = localSystemIdleState.state;
  localSystemIdleState = normalizeSystemIdleSnapshot(snapshot);

  sendLocalComputerPresence(
    previousState !== localSystemIdleState.state
  );

  if (me && computerPresence[me]) {
    computerPresence[me] = {
      state: localSystemIdleState.state,
      idleSeconds: localSystemIdleState.idleSeconds,
      updatedAt: Date.now()
    };
    renderPlayers();
  }
}


function nextTargetFromTime(value) {
  if (!/^\d{2}:\d{2}$/.test(value || "")) return null;

  const [hours, minutes] = value.split(":").map(Number);

  if (
    hours < 0 ||
    hours > 23 ||
    minutes < 0 ||
    minutes > 59
  ) {
    return null;
  }

  const now = new Date();
  const target = new Date(now);
  target.setHours(hours, minutes, 0, 0);

  if (target.getTime() <= now.getTime()) {
    target.setDate(target.getDate() + 1);
  }

  return target.getTime();
}

function timerAlertKey(player, targetAt) {
  return `arena-timer-alerted:${player}:${targetAt}`;
}

function playTimerSound() {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;

  if (!AudioCtx) return;

  const ctx = new AudioCtx();
  const now = ctx.currentTime;

  [0, .22, .44, .66, .95, 1.17, 1.39].forEach((offset, index) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = index % 2 ? "square" : "sawtooth";
    osc.frequency.setValueAtTime(
      index % 2 ? 980 : 740,
      now + offset
    );

    gain.gain.setValueAtTime(.0001, now + offset);
    gain.gain.exponentialRampToValueAtTime(
      .24,
      now + offset + .02
    );
    gain.gain.exponentialRampToValueAtTime(
      .0001,
      now + offset + .18
    );

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now + offset);
    osc.stop(now + offset + .2);
  });

  setTimeout(() => ctx.close(), 2200);
}

function checkMyPresenceTimer() {
  if (!me || !authenticated) return;

  const info = presenceInfo(me);

  if (info.status !== "later" || !info.targetAt) return;
  if (Date.now() < info.targetAt) return;

  const key = timerAlertKey(me, info.targetAt);

  if (localStorage.getItem(key) === "1") return;

  localStorage.setItem(key, "1");

  $("toastTitle").textContent = "⏰ Arena";
  $("toastText").textContent =
    `Seu horário chegou: ${formatClock(info.targetAt)}.`;
  $("toast").classList.remove("hidden");

  window.arenaDesktop?.notify?.(
    "⏰ Deu a hora do Arena",
    `Você marcou entrada para ${formatClock(info.targetAt)}.`
  );

  playTimerSound();

  setTimeout(() => {
    $("toast").classList.add("hidden");
  }, 12000);
}

function startPresenceTicker() {
  if (presenceTicker) {
    clearInterval(presenceTicker);
  }

  const tickerMs =
    performanceSettings
      .slowUiUpdates
      ? 3000
      : 1000;

  presenceTicker = setInterval(() => {
    renderPlayers();
    renderControls();
    checkMyPresenceTimer();
  }, tickerMs);

  checkMyPresenceTimer();
}

function setPresenceStatus(
  status,
  targetAt = null,
  customText = ""
) {
  if (!me || !authenticated || !socket?.connected) return;

  socket.emit("set-presence", {
    player: me,
    status,
    targetAt,
    customText
  });

  $("presenceModal").classList.add("hidden");
}

function setPlayerActivity(activity) {
  if (!me || !authenticated || !socket?.connected) {
    return;
  }

  socket.emit("set-player-activity", {
    player: me,
    activity
  });

  $("presenceModal").classList.add("hidden");
}

function playCallSound() {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) return;

  const ctx = new AudioCtx();
  const now = ctx.currentTime;

  [0, .20, .40, .60].forEach((offset, index) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = index % 2 ? "square" : "sine";
    osc.frequency.setValueAtTime(index % 2 ? 920 : 690, now + offset);

    gain.gain.setValueAtTime(.0001, now + offset);
    gain.gain.exponentialRampToValueAtTime(.20, now + offset + .02);
    gain.gain.exponentialRampToValueAtTime(.0001, now + offset + .16);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now + offset);
    osc.stop(now + offset + .18);
  });

  setTimeout(() => ctx.close(), 1400);
}

function showToast(from) {
  $("toastTitle").textContent = "Chat dos Pecinha";
  $("toastText").textContent = `${from} te chamou pro Arena.`;
  $("toast").classList.remove("hidden");

  // The urgent-call IPC owns the external top-right popup.
  // Do not also create a Windows notification in another corner.
  window.arenaDesktop?.urgentCall?.(
    from,
    me
  );

  playCallSound();

  setTimeout(() => {
    $("toast").classList.add("hidden");
  }, 8000);
}




function setGateServerState(connected, text) {
  $("authServerDot").className =
    `dot ${connected ? "online" : "offline"}`;

  $("authServerText").textContent = text;

  $("serverDot").className =
    `dot ${connected ? "online" : "offline"}`;

  $("serverText").textContent = text;

  if ($("configServerState")) {
    $("configServerState").textContent =
      connected
        ? `Conectado ao HOST · ${text}`
        : `Desconectado · ${text}`;
  }
  if ($("headerServerState")) {
    $("headerServerState").textContent = connected ? "Online" : "Offline";
    $("headerServerState").classList.toggle("online", connected);
  }
  if ($("footerServerState")) {
    $("footerServerState").textContent = connected ? "Online" : "Offline";
    $("footerServerState").classList.toggle("online", connected);
  }
}

function refreshLoginGateControls() {
  const select = $("loginPlayerSelect");
  const password = $("loginPassword");
  const passwordGroup = $("loginPasswordGroup");
  const submit = $("loginSubmit");
  const note = $("loginNote");
  const card = document.querySelector(".login-card");

  if (
    !select ||
    !password ||
    !passwordGroup ||
    !submit
  ) {
    return;
  }

  const selected = select.value;

  const rememberedReady =
    !!rememberedToken &&
    !!rememberedPlayer &&
    selected === rememberedPlayer;

  passwordGroup.classList.toggle(
    "hidden",
    rememberedReady
  );

  card?.classList.toggle(
    "remembered-mode",
    rememberedReady
  );

  submit.textContent = "Entrar";

  if (rememberedReady) {
    password.value = "";

    if (note) {
      note.innerHTML =
        `Sessão de <strong>${escapeHtml(rememberedPlayer)}</strong> lembrada neste PC. ` +
        `Clique em <strong>Entrar</strong> para abrir o Chat dos Pecinha.`;
    }
  } else if (note) {
    note.innerHTML =
      `Digite a senha para entrar. A conta pode ficar lembrada neste PC, ` +
      `mas o Chat dos Pecinha sempre espera você clicar em <strong>Entrar</strong>.`;
  }
}

function showLoginGate(message = "") {
  appEntered = false;

  $("authGate").classList.remove("hidden");
  $("appShell").classList.add("hidden");

  if (message) {
    $("loginError").textContent = message;
  }

  renderLoginPlayers();
  refreshLoginGateControls();
}

function showAppShell() {
  // The lobby can ONLY be opened by the explicit Enter action.
  appEntered = true;

  $("authGate").classList.add("hidden");
  $("appShell").classList.remove("hidden");
  $("loginError").textContent = "";

  renderAll();
}

function renderLoginPlayers() {
  const select = $("loginPlayerSelect");
  const changeSelect = $("changePasswordUser");

  if (!select || !changeSelect) return;

  const previousLogin =
    select.value ||
    rememberedPlayer ||
    lastProfile ||
    me ||
    "";

  const previousChange =
    changeSelect.value ||
    me ||
    rememberedPlayer ||
    lastProfile ||
    "";

  select.innerHTML =
    '<option value="">Escolha o usuário</option>';

  changeSelect.innerHTML =
    '<option value="">Escolha o usuário</option>';

  for (const player of PLAYERS) {
    const option = document.createElement("option");
    option.value = player;
    option.textContent = player;
    select.appendChild(option);

    const changeOption =
      document.createElement("option");
    changeOption.value = player;
    changeOption.textContent = player;
    changeSelect.appendChild(changeOption);
  }

  if (PLAYERS.includes(previousLogin)) {
    select.value = previousLogin;
  }

  if (PLAYERS.includes(previousChange)) {
    changeSelect.value = previousChange;
  }

  refreshLoginGateControls();
}


function isSorryeAdmin() {
  return (
    authenticated &&
    String(me || "").toLowerCase() === "sorrye"
  );
}

function renderDeleteUserOptions() {
  const select = $("deleteUserSelect");
  if (!select) return;

  const previous = select.value;

  select.innerHTML =
    '<option value="">Escolha um usuário</option>';

  const deletable = PLAYERS.filter(
    player =>
      String(player).toLowerCase() !== "sorrye"
  );

  for (const player of deletable) {
    const option = document.createElement("option");
    option.value = player;
    option.textContent = player;
    select.appendChild(option);
  }

  if (deletable.includes(previous)) {
    select.value = previous;
  }

  $("deleteUserSubmit").disabled =
    !isSorryeAdmin() ||
    !select.value;
}

function clearDeleteUserTimer() {
  if (deleteUserRequestTimer) {
    clearTimeout(deleteUserRequestTimer);
    deleteUserRequestTimer = null;
  }
}

function openManageUsersModal() {
  if (!isSorryeAdmin()) return;

  $("deleteUserError").textContent = "";
  $("manageUsersModal").classList.remove("hidden");

  renderDeleteUserOptions();
}

function closeManageUsersModal() {
  clearDeleteUserTimer();

  $("manageUsersModal").classList.add("hidden");
  $("deleteUserError").textContent = "";
  $("deleteUserSubmit").disabled = false;
}

function failDeleteUser(message) {
  clearDeleteUserTimer();
  $("deleteUserSubmit").disabled = false;
  $("deleteUserError").textContent = message;
}

function submitDeleteUser(player) {
  if (!isSorryeAdmin()) {
    failDeleteUser(
      "Apenas sorrye pode excluir usuários."
    );
    return;
  }

  if (!socket?.connected) {
    failDeleteUser(
      "Servidor desconectado."
    );
    return;
  }

  if (
    !player ||
    String(player).toLowerCase() === "sorrye"
  ) {
    failDeleteUser(
      "Escolha um usuário válido."
    );
    return;
  }

  $("deleteUserSubmit").disabled = true;
  $("deleteUserError").textContent =
    `Excluindo ${player}...`;

  clearDeleteUserTimer();

  deleteUserRequestTimer = setTimeout(() => {
    failDeleteUser(
      "O servidor não respondeu. Tente novamente."
    );
  }, 8000);

  socket.emit("delete-user", {
    player
  });
}

function clearChangePasswordTimer() {
  if (changePasswordRequestTimer) {
    clearTimeout(changePasswordRequestTimer);
    changePasswordRequestTimer = null;
  }
}

function openChangePasswordModal(player = "") {
  renderLoginPlayers();

  const selected =
    player && PLAYERS.includes(player)
      ? player
      : (
          $("loginPlayerSelect").value ||
          me ||
          lastProfile ||
          ""
        );

  $("changePasswordUser").value =
    PLAYERS.includes(selected)
      ? selected
      : "";

  $("oldPassword").value = "";
  $("newPassword").value = "";
  $("newPasswordConfirm").value = "";
  $("changePasswordError").textContent = "";
  $("changePasswordSubmit").disabled = false;

  $("changePasswordModal").classList.remove("hidden");

  setTimeout(() => {
    if ($("changePasswordUser").value) {
      $("oldPassword").focus();
    } else {
      $("changePasswordUser").focus();
    }
  }, 30);
}

function closeChangePasswordModal() {
  clearChangePasswordTimer();
  $("changePasswordModal").classList.add("hidden");
  $("changePasswordError").textContent = "";
  $("changePasswordSubmit").disabled = false;
}

function failChangePassword(message) {
  clearChangePasswordTimer();
  $("changePasswordSubmit").disabled = false;
  $("changePasswordError").textContent = message;
}

function submitPasswordChange(
  player,
  oldPassword,
  newPassword
) {
  if (!socket?.connected) {
    failChangePassword(
      "Servidor desconectado. O HOST precisa estar online."
    );
    return;
  }

  $("changePasswordSubmit").disabled = true;
  $("changePasswordError").textContent =
    "Alterando senha...";

  clearChangePasswordTimer();

  changePasswordRequestTimer =
    setTimeout(() => {
      failChangePassword(
        "O servidor não respondeu. Tente novamente."
      );
    }, 8000);

  socket.emit("change-password", {
    player,
    oldPassword,
    newPassword
  });
}

function clearAuthRequestTimer() {
  if (authRequestTimer) {
    clearTimeout(authRequestTimer);
    authRequestTimer = null;
  }
}

function failAuthRequest(message) {
  clearAuthRequestTimer();
  loginAuthRequested = false;

  $("authSubmitBtn").disabled = false;
  $("authError").textContent = message;

  $("loginSubmit").disabled = false;
  $("loginError").textContent = message;
}

function startAuthRequestTimer() {
  clearAuthRequestTimer();

  authRequestTimer = setTimeout(() => {
    const versionHint = serverAppVersion
      ? ` Host: ${serverAppVersion}.`
      : "";

    failAuthRequest(
      "O servidor não respondeu ao login." +
      versionHint +
      " Atualize/reinicie o Chat dos Pecinha HOST."
    );
  }, 7000);
}

function openAuthModal(player) {
  pendingAuthProfile = player;
  $("authProfileLabel").textContent = `Perfil: ${player}`;
  $("authPassword").value = "";
  $("authError").textContent = "";
  $("authSubmitBtn").disabled = false;
  $("authModal").classList.remove("hidden");
  setTimeout(() => $("authPassword").focus(), 30);
}
function closeAuthModal() {
  pendingAuthProfile = "";
  $("authPassword").value = "";
  $("authError").textContent = "";
  $("authModal").classList.add("hidden");
}
function sendProfileAuth(player, password) {
  if (!player || !password) return;

  if (!socket?.connected) {
    failAuthRequest(
      "Servidor desconectado. O HOST precisa estar online."
    );
    return;
  }

  $("authSubmitBtn").disabled = true;
  $("authError").textContent = "Verificando senha...";

  $("loginSubmit").disabled = true;
  $("loginError").textContent = "Verificando senha...";

  startAuthRequestTimer();

  socket.emit("auth-profile", {
    player,
    password
  });
}


function sendRememberedAuth(player, token) {
  if (!socket?.connected || !player || !token) return;

  setGateServerState(
    true,
    "Conectado · verificando sessão..."
  );

  $("loginSubmit").disabled = true;
  $("loginError").textContent = "Entrando...";

  startAuthRequestTimer();

  socket.emit("auth-token", {
    player,
    token
  });
}

function renderIdentity() {
  if ($("accountSummary")) {
    $("accountSummary").textContent =
      authenticated && me
        ? `Logado como ${me}.`
        : "Nenhum usuário autenticado.";
  }

  if ($("accountUserName")) {
    $("accountUserName").textContent =
      authenticated && me
        ? me
        : "—";
  }

  if ($("accountAvatarText")) {
    $("accountAvatarText").textContent =
      authenticated && me
        ? String(me)
            .trim()
            .charAt(0)
            .toUpperCase()
        : "?";
  }

  if ($("configCurrentUser")) {
    $("configCurrentUser").textContent = authenticated && me ? me : "—";
  }
  if ($("footerNetwork")) $("footerNetwork").textContent = myTailscaleIP ? `Tailscale: ${myTailscaleIP}` : "Tailscale: —";
  if ($("footerVersion")) {
    $("footerVersion").textContent = localAppVersion ? `Versão ${localAppVersion}` : "Versão —";
  }

  if ($("configManageUsersBtn")) {
    $("configManageUsersBtn").disabled =
      !(
        authenticated &&
        me === "sorrye"
      );
  }

  if ($("configSosoAlertBtn")) {
    $("configSosoAlertBtn").disabled =
      !(
        authenticated &&
        me === "sorrye"
      );
  }

  if ($("accountOnlineText")) {
    $("accountOnlineText").textContent =
      authenticated &&
      me &&
      socket?.connected
        ? "Online"
        : "Offline";

    $("accountOnlineText").classList.toggle(
      "online",
      !!(
        authenticated &&
        me &&
        socket?.connected
      )
    );
  }

  const canUseSorryeAdmin =
    authenticated &&
    String(me || "").toLowerCase() === "sorrye";

  const sosoButton = $("sosoHeadsetAlertBtn");

  if (sosoButton) {
    sosoButton.classList.toggle(
      "hidden",
      !canUseSorryeAdmin
    );

    sosoButton.disabled =
      !canUseSorryeAdmin ||
      !socket?.connected;
  }

  const manageUsersButton =
    $("manageUsersBtn");

  if (manageUsersButton) {
    manageUsersButton.classList.toggle(
      "hidden",
      !canUseSorryeAdmin
    );

    manageUsersButton.disabled =
      !canUseSorryeAdmin ||
      !socket?.connected;
  }
}


function sameCalendarDay(a, b) {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

function formatLastSeen(value) {
  const timestamp = Number(value);

  if (!Number.isFinite(timestamp) || timestamp <= 0) {
    return "Visto por último: nunca";
  }

  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) {
    return "Visto por último: desconhecido";
  }

  const now = new Date();
  const diffMs = Math.max(0, now.getTime() - date.getTime());

  if (diffMs < 60_000) {
    return "Visto por último: agora";
  }

  if (diffMs < 60 * 60_000) {
    const minutes = Math.max(1, Math.floor(diffMs / 60_000));
    return `Visto por último: há ${minutes} min`;
  }

  const time = date.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit"
  });

  if (sameCalendarDay(date, now)) {
    return `Visto por último: hoje ${time}`;
  }

  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);

  if (sameCalendarDay(date, yesterday)) {
    return `Visto por último: ontem ${time}`;
  }

  const datePart = date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year:
      date.getFullYear() === now.getFullYear()
        ? undefined
        : "numeric"
  });

  return `Visto por último: ${datePart} ${time}`;
}


function renderDashboardOverview() {
  const setText =
    (id, value) => {
      const element = $(id);

      if (element) {
        element.textContent =
          String(value);
      }
    };

  const playingCount =
    PLAYERS.filter(
      player =>
        (presence[player] || {})
          .status === "playing"
    ).length;

  const sharingCount =
    PLAYERS.filter(
      player =>
        !!sharing[player]
    ).length;

  const voiceCount =
    voiceMemberNames().length;

  setText(
    "overviewMembersCount",
    PLAYERS.length
  );

  setText(
    "overviewPlayingCount",
    playingCount
  );

  setText(
    "overviewSharingCount",
    sharingCount
  );

  setText(
    "overviewVoiceCount",
    voiceCount
  );


  const otherVoiceCount =
    Math.max(
      0,
      voiceCount -
      (
        isInVoiceCall()
          ? 1
          : 0
      )
    );


  const preset =
    getScreenQualityPreset();

}

function renderPlayers() {
  const holder = $("players");
  holder.innerHTML = "";

  for (const player of PLAYERS) {
    const card =
      document.createElement(
        "div"
      );

    card.className =
      `player-card${
        player === me
          ? " current-player"
          : ""
      }`;

    const status =
      presenceDisplay(player);

    const computerState =
      playerComputerPresenceDisplay(
        player
      );

    const manualActivity =
      playerManualActivityDisplay(
        player
      );

    const initial =
      String(player || "?")
        .trim()
        .charAt(0)
        .toUpperCase();

    card.innerHTML = `
      <div class="player-card-main">
        <div class="player-avatar">${escapeHtml(initial)}</div>

        <div class="player-card-copy">
          <div class="player-top">
            <span class="player-name">${escapeHtml(player)}</span>
            ${
              player === me
                ? '<span class="player-you-chip">você</span>'
                : ""
            }
          </div>

          <div class="player-line ${status.css}">
            <span class="tiny-dot ${
              status.css === "status-playing"
                ? "good"
                : status.css === "status-not-today"
                  ? "bad"
                  : ""
            }"></span>
            <span class="presence-countdown">${escapeHtml(status.text)}</span>
          </div>

          <div class="player-line ${computerState.css}">
            <span>${computerState.icon}</span>
            <span>${escapeHtml(computerState.text)}</span>
          </div>

          ${
            manualActivity
              ? `
                <div class="player-line manual-activity-line ${manualActivity.css}">
                  <span>${manualActivity.icon}</span>
                  <span>${escapeHtml(manualActivity.text)}</span>
                </div>
              `
              : ""
          }

          ${
            isSorryeAdmin()
              ? `
                <div class="player-line player-version-line ${playerVersionDisplay(player).css}">
                  <span>V</span>
                  <span>${escapeHtml(playerVersionDisplay(player).text)}</span>
                </div>
              `
              : ""
          }
        </div>

        <span class="status-badge">${status.icon}</span>
      </div>
    `;

    holder.appendChild(card);
  }

  renderDashboardOverview();
}

function renderCalls() {
  const holder = $("callButtons");
  holder.innerHTML = "";

  for (const player of PLAYERS) {
    const btn = document.createElement("button");
    btn.className = "call-btn";

    btn.textContent =
      player === me
        ? `🔊  Chamar ${player} (você)`
        : `🔊  Chamar ${player}`;

    btn.disabled =
      !me ||
      !authenticated ||
      !socket?.connected;

    btn.onclick = () => {
      socket.emit("call-player", {
        from: me,
        to: player
      });
    };

    holder.appendChild(btn);
  }
}

function getScreenQualityPreset() {
  return (
    SCREEN_QUALITY_PRESETS[
      screenQualityKey
    ] ||
    SCREEN_QUALITY_PRESETS.balanced
  );
}

function formatShareBitrate(
  bitsPerSecond
) {
  const mbps =
    Number(bitsPerSecond) /
    1_000_000;

  return (
    Number.isInteger(mbps)
      ? String(mbps)
      : mbps.toFixed(1)
  );
}

function renderScreenQualityControls() {
  const preset =
    getScreenQualityPreset();

  for (
    const card of
    document.querySelectorAll(
      "[data-quality-preset]"
    )
  ) {
    const selected =
      card.dataset
        .qualityPreset ===
      preset.key;

    card.classList.toggle(
      "selected",
      selected
    );

    card.disabled =
      !!localStream;

    card.setAttribute(
      "aria-pressed",
      selected
        ? "true"
        : "false"
    );
  }

  const select =
    $("shareQualitySelect");

  if (select) {
    select.value =
      preset.key;

    select.disabled =
      !!localStream;

    select.title =
      localStream
        ? "Pare a transmissão para trocar resolução/FPS."
        : preset.hint;
  }

  if ($("shareQualityHint")) {
    $("shareQualityHint").textContent =
      localStream
        ? (
            `${preset.resolutionLabel} · ${preset.fps} FPS · ` +
            `até ${formatShareBitrate(preset.maxBitrate)} Mbps · ` +
            "pare para trocar"
          )
        : preset.hint;
  }

  if ($("shareQualityState")) {
    $("shareQualityState").textContent =
      `${preset.resolutionLabel} · ${preset.fps} FPS · ` +
      `até ${formatShareBitrate(preset.maxBitrate)} Mbps`;
  }
}

function setScreenQualityPreset(
  key
) {
  if (
    !Object.prototype.hasOwnProperty.call(
      SCREEN_QUALITY_PRESETS,
      key
    )
  ) {
    return;
  }

  if (localStream) {
    renderScreenQualityControls();
    return;
  }

  screenQualityKey = key;

  localStorage.setItem(
    SCREEN_QUALITY_STORAGE_KEY,
    screenQualityKey
  );

  renderScreenQualityControls();
}

async function tuneScreenVideoTrack(
  track,
  preset
) {
  if (
    !track ||
    track.kind !== "video"
  ) {
    return;
  }

  try {
    if (
      "contentHint" in track
    ) {
      track.contentHint =
        preset.contentHint;
    }
  } catch {}

  // Chromium normally respects the desktop-capture max values
  // already, but applying constraints again makes the low presets
  // more reliable on high-resolution displays.
  try {
    await track.applyConstraints({
      width: {
        max: preset.width
      },
      height: {
        max: preset.height
      },
      frameRate: {
        max: preset.fps
      }
    });
  } catch (error) {
    console.warn(
      "Desktop capture constraints were not fully applied:",
      error
    );
  }

  try {
    const settings =
      track.getSettings();

    console.log(
      "Screen capture:",
      {
        preset:
          preset.key,
        width:
          settings.width,
        height:
          settings.height,
        fps:
          settings.frameRate,
        bitrate:
          preset.maxBitrate
      }
    );
  } catch {}
}

async function tuneScreenVideoSender(
  sender
) {
  if (
    !sender ||
    sender.track?.kind !== "video"
  ) {
    return false;
  }

  const preset =
    getScreenQualityPreset();

  try {
    const params =
      sender.getParameters();

    if (
      !Array.isArray(
        params.encodings
      ) ||
      params.encodings.length < 1
    ) {
      return false;
    }

    for (
      const encoding of
      params.encodings
    ) {
      encoding.maxBitrate =
        preset.maxBitrate;

      encoding.maxFramerate =
        preset.fps;
    }

    params.degradationPreference =
      preset.degradationPreference;

    await sender.setParameters(
      params
    );

    return true;
  } catch (error) {
    // Some Chromium builds are stricter about
    // degradationPreference. Retry with only encoding limits.
    try {
      const fallback =
        sender.getParameters();

      if (
        !Array.isArray(
          fallback.encodings
        ) ||
        fallback.encodings.length < 1
      ) {
        return false;
      }

      for (
        const encoding of
        fallback.encodings
      ) {
        encoding.maxBitrate =
          preset.maxBitrate;

        encoding.maxFramerate =
          preset.fps;
      }

      delete fallback
        .degradationPreference;

      await sender.setParameters(
        fallback
      );

      return true;
    } catch (fallbackError) {
      console.warn(
        "WebRTC video bitrate/FPS tuning unavailable:",
        fallbackError
      );

      return false;
    }
  }
}

function renderScreenShare() {
  const holder = $("shareCards");
  holder.innerHTML = "";

  const active = PLAYERS.filter(
    player => sharing[player]
  );

  $("screenStatus").textContent = active.length
    ? `${active.length} transmitindo`
    : "Ninguém transmitindo";

  // Live streams first, then everyone else.
  const orderedPlayers = [...PLAYERS].sort(
    (a, b) => Number(!!sharing[b]) - Number(!!sharing[a])
  );

  for (const player of orderedPlayers) {
    const live = !!sharing[player];
    const card = document.createElement("div");
    card.className =
      `share-card${live ? " live" : ""}`;

    const isMe = player === me;
    const watching = watchedSharers.has(player);

    card.innerHTML = `
      <div class="share-card-top">
        <strong>${escapeHtml(player)}</strong>
        ${
          live
            ? `<span class="live-badge"><span class="tiny-dot"></span> AO VIVO</span>`
            : `<span class="share-card-offline">sem transmissão</span>`
        }
      </div>
    `;

    const btn = document.createElement("button");
    btn.className =
      `watch-btn${watching ? " watching" : ""}`;

    if (isMe) {
      btn.textContent =
        localStream
          ? "Você está transmitindo"
          : "Sua tela";
      btn.disabled = true;
    } else if (!live) {
      btn.textContent = "Indisponível";
      btn.disabled = true;
    } else if (watching) {
      btn.textContent = "■ Fechar transmissão";
      btn.disabled = false;
      btn.onclick = () => stopWatching(player);
    } else {
      btn.textContent = "▶ Assistir";
      btn.disabled =
        !me ||
        !authenticated ||
        !socket?.connected;

      btn.onclick = () => watchPlayer(player);
    }

    card.appendChild(btn);
    holder.appendChild(card);
  }

  const shareBtn = $("shareScreenBtn");
  shareBtn.disabled =
    !me ||
    !authenticated ||
    !socket?.connected;

  shareBtn.textContent =
    localStream
      ? "■ Parar transmissão"
      : "▣ Iniciar transmissão";

  shareBtn.classList.toggle(
    "active",
    !!localStream
  );

  syncLocalPreviewPerformance();

  $("viewerCount").textContent =
    `${activeViewers.size} assistindo`;

  renderScreenQualityControls();
  renderDashboardOverview();
  renderMultiView();
}

function findStreamVideo(player) {
  return Array.from(
    document.querySelectorAll(".remote-stream-video")
  ).find(video => video.dataset.sharer === player) || null;
}

function setReceiverStatus(player, text) {
  receiverStatus.set(player, text);

  const status = Array.from(
    document.querySelectorAll(".stream-tile-status")
  ).find(item => item.dataset.sharer === player);

  if (status) {
    status.textContent = text;
  }
}

function applyStreamFullscreenState() {
  const activePlayer =
    fullscreenStreamPlayer;

  document.body.classList.toggle(
    "stream-fullscreen-open",
    !!activePlayer
  );

  for (
    const tile of
    document.querySelectorAll(
      ".stream-tile"
    )
  ) {
    tile.classList.toggle(
      "stream-fullscreen",
      !!activePlayer &&
      tile.dataset
        .sharer ===
        activePlayer
    );
  }
}

async function enterStreamFullscreen(
  player
) {
  const video =
    findStreamVideo(player);

  if (!video) {
    return;
  }

  fullscreenStreamPlayer =
    player;

  applyStreamFullscreenState();

  try {
    const nativeResult =
      await window.arenaDesktop
        ?.setAppFullscreen?.(
          true
        );

    if (nativeResult === false) {
      throw new Error(
        "Native fullscreen unavailable"
      );
    }

    return;
  } catch (error) {
    console.warn(
      "Electron fullscreen failed, trying HTML fullscreen:",
      error
    );
  }

  try {
    if (video.requestFullscreen) {
      await video.requestFullscreen();
      return;
    }
  } catch (error) {
    console.warn(
      "HTML fullscreen failed:",
      error
    );
  }
}

async function exitStreamFullscreen() {
  fullscreenStreamPlayer = "";

  applyStreamFullscreenState();

  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
    }
  } catch {}

  try {
    await window.arenaDesktop
      ?.setAppFullscreen?.(
        false
      );
  } catch {}
}

function renderMultiView() {
  const stage = $("videoStage");
  const grid = $("streamGrid");
  const players = [...watchedSharers];

  stage.classList.toggle(
    "hidden",
    players.length === 0
  );

  $("multiViewStatus").textContent =
    `${players.length} ${
      players.length === 1
        ? "transmissão aberta"
        : "transmissões abertas"
    }`;

  grid.innerHTML = "";

  if (!players.length) {
    stage.classList.remove("expanded");
    document.body.classList.remove("multiview-open");
    $("expandMultiviewBtn").textContent =
      "Expandir grade";

    if (fullscreenStreamPlayer) {
      exitStreamFullscreen();
    }

    return;
  }

  grid.classList.toggle(
    "compact",
    players.length >= 3
  );

  for (const player of players) {
    const stream = remoteStreams.get(player);
    const audioEnabled =
      remoteAudioEnabled.get(player) === true;

    const tile = document.createElement("article");
    tile.className =
      `stream-tile${stream ? " connected" : ""}`;
    tile.dataset.sharer =
      player;

    if (
      fullscreenStreamPlayer ===
      player
    ) {
      tile.classList.add(
        "stream-fullscreen"
      );
    }

    const head = document.createElement("div");
    head.className = "stream-tile-head";

    const info = document.createElement("div");
    info.className = "stream-tile-info";

    const title = document.createElement("strong");
    title.textContent = `Tela de ${player}`;

    const status = document.createElement("span");
    status.className = "stream-tile-status";
    status.dataset.sharer = player;
    status.textContent =
      receiverStatus.get(player) ||
      "Solicitando transmissão...";

    info.append(title, status);

    const actions = document.createElement("div");
    actions.className = "stream-tile-actions";

    const audioBtn = document.createElement("button");
    audioBtn.type = "button";
    audioBtn.className =
      audioEnabled ? "audio-on" : "";
    audioBtn.textContent =
      audioEnabled ? "🔊 Som ligado" : "🔇 Som";
    audioBtn.disabled = !stream;

    audioBtn.onclick = () => {
      const next =
        !(remoteAudioEnabled.get(player) === true);

      remoteAudioEnabled.set(player, next);

      const video = findStreamVideo(player);
      if (video) {
        video.muted = !next;
        video.volume = 1;
        video.play().catch(() => {});
      }

      renderMultiView();
    };

    const fullBtn = document.createElement("button");
    fullBtn.type = "button";
    fullBtn.textContent =
      fullscreenStreamPlayer ===
      player
        ? "↙ Sair da tela cheia"
        : "⛶ Tela cheia";
    fullBtn.disabled = !stream;

    fullBtn.onclick =
      async () => {
        if (
          fullscreenStreamPlayer ===
          player
        ) {
          await exitStreamFullscreen();
          renderMultiView();
        } else {
          await enterStreamFullscreen(
            player
          );
          renderMultiView();
        }
      };

    const closeBtn = document.createElement("button");
    closeBtn.type = "button";
    closeBtn.textContent = "✕ Fechar";
    closeBtn.onclick = () => stopWatching(player);

    actions.append(audioBtn, fullBtn, closeBtn);
    head.append(info, actions);

    const video = document.createElement("video");
    video.className = "remote-stream-video";
    video.dataset.sharer = player;
    video.autoplay = true;
    video.playsInline = true;
    video.muted = !audioEnabled;
    video.volume = 1;

    if (stream) {
      video.srcObject = stream;
      video.play().catch(() => {});
    }

    tile.append(head, video);
    grid.appendChild(tile);
  }

  applyStreamFullscreenState();
}

function getVoiceCueContext() {
  const AudioContextClass =
    window.AudioContext ||
    window.webkitAudioContext;

  if (!AudioContextClass) {
    return null;
  }

  if (
    !voiceCueContext ||
    voiceCueContext.state === "closed"
  ) {
    voiceCueContext =
      new AudioContextClass();
  }

  return voiceCueContext;
}

function scheduleVoiceCueTone(
  context,
  {
    frequency,
    start,
    duration,
    volume = 0.055,
    type = "sine"
  }
) {
  const oscillator =
    context.createOscillator();

  const gain =
    context.createGain();

  oscillator.type = type;
  oscillator.frequency.setValueAtTime(
    frequency,
    start
  );

  gain.gain.setValueAtTime(
    0.0001,
    start
  );

  gain.gain.exponentialRampToValueAtTime(
    volume,
    start + 0.012
  );

  gain.gain.exponentialRampToValueAtTime(
    0.0001,
    start + duration
  );

  oscillator.connect(gain);
  gain.connect(context.destination);

  oscillator.start(start);
  oscillator.stop(
    start + duration + 0.025
  );
}

async function playVoiceCue(kind) {
  try {
    const context =
      getVoiceCueContext();

    if (!context) return;

    if (context.state === "suspended") {
      await context.resume();
    }

    const now =
      context.currentTime + 0.012;

    const cues = {
      join: [
        {
          frequency: 520,
          start: now,
          duration: .11
        },
        {
          frequency: 760,
          start: now + .105,
          duration: .15
        }
      ],

      leave: [
        {
          frequency: 620,
          start: now,
          duration: .1
        },
        {
          frequency: 390,
          start: now + .09,
          duration: .16
        }
      ],

      mute: [
        {
          frequency: 290,
          start: now,
          duration: .075,
          volume: .05,
          type: "triangle"
        },
        {
          frequency: 205,
          start: now + .065,
          duration: .095,
          volume: .045,
          type: "triangle"
        }
      ],

      unmute: [
        {
          frequency: 205,
          start: now,
          duration: .075,
          volume: .05,
          type: "triangle"
        },
        {
          frequency: 350,
          start: now + .065,
          duration: .095,
          volume: .05,
          type: "triangle"
        }
      ],

      deafen: [
        {
          frequency: 430,
          start: now,
          duration: .085,
          volume: .05,
          type: "square"
        },
        {
          frequency: 260,
          start: now + .075,
          duration: .12,
          volume: .045,
          type: "square"
        },
        {
          frequency: 170,
          start: now + .175,
          duration: .12,
          volume: .04,
          type: "triangle"
        }
      ],

      undeafen: [
        {
          frequency: 170,
          start: now,
          duration: .08,
          volume: .04,
          type: "triangle"
        },
        {
          frequency: 310,
          start: now + .07,
          duration: .105,
          volume: .045,
          type: "triangle"
        },
        {
          frequency: 520,
          start: now + .16,
          duration: .13,
          volume: .05,
          type: "sine"
        }
      ],

      memberJoin: [
        {
          frequency: 660,
          start: now,
          duration: .09,
          volume: .04
        },
        {
          frequency: 880,
          start: now + .085,
          duration: .13,
          volume: .045
        }
      ],

      memberLeave: [
        {
          frequency: 520,
          start: now,
          duration: .085,
          volume: .035
        },
        {
          frequency: 360,
          start: now + .075,
          duration: .12,
          volume: .035
        }
      ],

      micTestDone: [
        {
          frequency: 440,
          start: now,
          duration: .075,
          volume: .035
        },
        {
          frequency: 660,
          start: now + .07,
          duration: .1,
          volume: .04
        }
      ]
    };

    for (
      const tone of
      cues[kind] || []
    ) {
      scheduleVoiceCueTone(
        context,
        tone
      );
    }
  } catch (error) {
    console.warn(
      "Voice cue failed:",
      error
    );
  }
}

function setVoiceMicMeter(level) {
  const normalized =
    Math.max(
      0,
      Math.min(
        100,
        Number(level) || 0
      )
    );

  if ($("voiceMicMeterFill")) {
    $("voiceMicMeterFill").style.width =
      `${normalized}%`;
  }

  const meter =
    document.querySelector(
      ".voice-mic-meter"
    );

  if (meter) {
    meter.setAttribute(
      "aria-valuenow",
      String(Math.round(normalized))
    );
  }
}

function setVoiceMicTestStatus(text) {
  if ($("voiceMicTestStatus")) {
    $("voiceMicTestStatus").textContent =
      text;
  }
}

function clearVoiceMicTestPlayback() {
  const playback =
    $("voiceMicTestPlayback");

  if (playback) {
    try {
      playback.pause();
      playback.removeAttribute("src");
      playback.load();
    } catch {}

    playback.classList.add("hidden");
  }

  if (voiceMicTestPlaybackUrl) {
    URL.revokeObjectURL(
      voiceMicTestPlaybackUrl
    );

    voiceMicTestPlaybackUrl = "";
  }
}

function stopVoiceMicMeter() {
  if (voiceMicTestAnimation) {
    cancelAnimationFrame(
      voiceMicTestAnimation
    );

    voiceMicTestAnimation = null;
  }

  setVoiceMicMeter(0);

  if (voiceMicTestSource) {
    try {
      voiceMicTestSource.disconnect();
    } catch {}

    voiceMicTestSource = null;
  }

  voiceMicTestAnalyser = null;

  if (voiceMicTestContext) {
    try {
      voiceMicTestContext.close();
    } catch {}

    voiceMicTestContext = null;
  }
}

function stopVoiceMicTestTracks() {
  for (
    const track of
    voiceMicTestStream?.getTracks() || []
  ) {
    try {
      track.stop();
    } catch {}
  }

  voiceMicTestStream = null;
}

function resetVoiceMicTestButton() {
  voiceMicTestActive = false;

  if ($("voiceMicTestBtn")) {
    $("voiceMicTestBtn").disabled =
      !(authenticated && me);

    $("voiceMicTestBtn").textContent =
      "🎤 Iniciar teste";
  }
}

function cancelVoiceMicTest() {
  if (voiceMicTestTimer) {
    clearTimeout(
      voiceMicTestTimer
    );

    voiceMicTestTimer = null;
  }

  if (
    voiceMicTestRecorder &&
    voiceMicTestRecorder.state !== "inactive"
  ) {
    try {
      voiceMicTestRecorder.ondataavailable = null;
      voiceMicTestRecorder.onstop = null;
      voiceMicTestRecorder.stop();
    } catch {}
  }

  voiceMicTestRecorder = null;
  voiceMicTestChunks = [];

  stopVoiceMicMeter();
  stopVoiceMicTestTracks();
  resetVoiceMicTestButton();
}

async function getVoiceMicTestStream() {
  const existingTracks =
    voiceLocalStream
      ?.getAudioTracks()
      ?.filter(
        track =>
          track.readyState === "live"
      ) || [];

  if (existingTracks.length) {
    const clones =
      existingTracks.map(
        track => {
          const clone =
            track.clone();

          // A mic test must still hear the mic even when the
          // user's call track is currently muted.
          clone.enabled = true;

          return clone;
        }
      );

    return new MediaStream(
      clones
    );
  }

  return navigator.mediaDevices
    .getUserMedia({
      video: false,
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1
      }
    });
}

function startVoiceMicMeter(stream) {
  const AudioContextClass =
    window.AudioContext ||
    window.webkitAudioContext;

  if (!AudioContextClass) {
    return;
  }

  const context =
    new AudioContextClass();

  const source =
    context.createMediaStreamSource(
      stream
    );

  const analyser =
    context.createAnalyser();

  analyser.fftSize = 512;
  analyser.smoothingTimeConstant = .7;

  source.connect(analyser);

  voiceMicTestContext = context;
  voiceMicTestSource = source;
  voiceMicTestAnalyser = analyser;

  const samples =
    new Uint8Array(
      analyser.fftSize
    );

  const tick = () => {
    if (
      !voiceMicTestActive ||
      !voiceMicTestAnalyser
    ) {
      return;
    }

    voiceMicTestAnalyser
      .getByteTimeDomainData(
        samples
      );

    let sum = 0;

    for (
      let i = 0;
      i < samples.length;
      i += 1
    ) {
      const value =
        (samples[i] - 128) / 128;

      sum +=
        value * value;
    }

    const rms =
      Math.sqrt(
        sum / samples.length
      );

    setVoiceMicMeter(
      Math.min(
        100,
        rms * 360
      )
    );

    voiceMicTestAnimation =
      requestAnimationFrame(
        tick
      );
  };

  context.resume().catch(() => {});
  tick();
}

async function startVoiceMicTest() {
  if (
    voiceMicTestActive ||
    !authenticated ||
    !me
  ) {
    return;
  }

  if (
    typeof MediaRecorder === "undefined"
  ) {
    setVoiceMicTestStatus(
      "Seu Electron não possui MediaRecorder disponível."
    );
    return;
  }

  voiceMicTestActive = true;
  clearVoiceMicTestPlayback();
  setVoiceMicMeter(0);

  $("voiceMicTestBtn").disabled =
    true;

  $("voiceMicTestBtn").textContent =
    "⏺ Gravando 5s...";

  setVoiceMicTestStatus(
    "Fale normalmente. Gravando 5 segundos..."
  );

  try {
    const stream =
      await getVoiceMicTestStream();

    voiceMicTestStream =
      stream;

    startVoiceMicMeter(
      stream
    );

    voiceMicTestChunks = [];

    const preferredType =
      "audio/webm;codecs=opus";

    const options =
      MediaRecorder.isTypeSupported(
        preferredType
      )
        ? {
            mimeType:
              preferredType
          }
        : undefined;

    const recorder =
      new MediaRecorder(
        stream,
        options
      );

    voiceMicTestRecorder =
      recorder;

    recorder.ondataavailable =
      event => {
        if (
          event.data &&
          event.data.size > 0
        ) {
          voiceMicTestChunks.push(
            event.data
          );
        }
      };

    recorder.onerror =
      error => {
        console.error(
          "Mic test recorder error:",
          error
        );
      };

    recorder.onstop =
      async () => {
        if (voiceMicTestTimer) {
          clearTimeout(
            voiceMicTestTimer
          );

          voiceMicTestTimer = null;
        }

        stopVoiceMicMeter();
        stopVoiceMicTestTracks();

        const chunks =
          voiceMicTestChunks;

        voiceMicTestChunks = [];
        voiceMicTestRecorder = null;

        if (!chunks.length) {
          setVoiceMicTestStatus(
            "Não consegui gravar áudio do microfone."
          );

          resetVoiceMicTestButton();
          return;
        }

        const blob =
          new Blob(
            chunks,
            {
              type:
                recorder.mimeType ||
                "audio/webm"
            }
          );

        clearVoiceMicTestPlayback();

        voiceMicTestPlaybackUrl =
          URL.createObjectURL(
            blob
          );

        const playback =
          $("voiceMicTestPlayback");

        playback.src =
          voiceMicTestPlaybackUrl;

        playback.classList.remove(
          "hidden"
        );

        setVoiceMicTestStatus(
          "Gravação pronta. Reproduzindo o teste localmente..."
        );

        resetVoiceMicTestButton();
        await playVoiceCue(
          "micTestDone"
        );

        playback.play().catch(() => {
          setVoiceMicTestStatus(
            "Gravação pronta. Aperte ▶ para ouvir."
          );
        });
      };

    recorder.start(
      150
    );

    voiceMicTestTimer =
      setTimeout(
        () => {
          if (
            recorder.state !==
            "inactive"
          ) {
            recorder.stop();
          }
        },
        5000
      );
  } catch (error) {
    console.error(
      "Mic test failed:",
      error
    );

    cancelVoiceMicTest();

    setVoiceMicTestStatus(
      error?.name === "NotAllowedError"
        ? "Microfone bloqueado. Libere o acesso no Windows."
        : "Não consegui iniciar o teste do microfone."
    );
  }
}

function voiceVolumeStorageKey() {
  const account =
    String(me || "anonymous")
      .toLowerCase();

  return `arena-squad:voice-volumes:${account}`;
}

function loadVoiceUserVolumes() {
  try {
    const parsed =
      JSON.parse(
        localStorage.getItem(
          voiceVolumeStorageKey()
        ) || "{}"
      );

    voiceUserVolumes =
      parsed &&
      typeof parsed === "object"
        ? parsed
        : {};
  } catch {
    voiceUserVolumes = {};
  }
}

function saveVoiceUserVolumes() {
  try {
    localStorage.setItem(
      voiceVolumeStorageKey(),
      JSON.stringify(
        voiceUserVolumes
      )
    );
  } catch {}
}

function voiceVolumeFor(player) {
  const raw =
    Number(
      voiceUserVolumes[player]
    );

  if (!Number.isFinite(raw)) {
    return 100;
  }

  return Math.max(
    0,
    Math.min(
      200,
      Math.round(raw)
    )
  );
}

function getVoiceOutputContext() {
  const AudioContextClass =
    window.AudioContext ||
    window.webkitAudioContext;

  if (!AudioContextClass) {
    return null;
  }

  if (
    !voiceOutputContext ||
    voiceOutputContext.state === "closed"
  ) {
    voiceOutputContext =
      new AudioContextClass();
  }

  if (
    voiceOutputContext.state === "suspended"
  ) {
    voiceOutputContext
      .resume()
      .catch(() => {});
  }

  return voiceOutputContext;
}

function applyVoiceUserVolume(player) {
  const percent =
    voiceVolumeFor(player);

  const gain =
    voiceRemoteGains.get(player);

  if (gain) {
    // 100% = unity gain, 200% = 2x amplitude.
    // Deafen still wins over the individual slider.
    gain.gain.value =
      voiceDeafened
        ? 0
        : percent / 100;
  }

  const audio =
    voiceAudioElements.get(player);

  if (audio) {
    // The hidden audio element is muted when Web Audio is active.
    // This fallback path keeps 0-100% working if AudioContext fails.
    if (!gain) {
      audio.muted =
        voiceDeafened;

      audio.volume =
        Math.min(
          1,
          percent / 100
        );
    }
  }
}

function setVoiceUserVolume(
  player,
  value
) {
  if (
    !player ||
    player === me
  ) {
    return;
  }

  const normalized =
    Math.max(
      0,
      Math.min(
        200,
        Math.round(
          Number(value) || 0
        )
      )
    );

  voiceUserVolumes[player] =
    normalized;

  saveVoiceUserVolumes();
  applyVoiceUserVolume(player);

  const label =
    document.querySelector(
      `[data-voice-volume-label="${CSS.escape(player)}"]`
    );

  if (label) {
    label.textContent =
      `${normalized}%`;
  }
}

function destroyVoiceAudioGraph(player) {
  const source =
    voiceRemoteSources.get(player);

  if (source) {
    try {
      source.disconnect();
    } catch {}
  }

  const gain =
    voiceRemoteGains.get(player);

  if (gain) {
    try {
      gain.disconnect();
    } catch {}
  }

  voiceRemoteSources.delete(player);
  voiceRemoteGains.delete(player);
}

function attachVoiceGainGraph(
  player,
  stream,
  audio
) {
  destroyVoiceAudioGraph(player);

  const context =
    getVoiceOutputContext();

  if (!context) {
    audio.muted =
      voiceDeafened;

    audio.volume =
      Math.min(
        1,
        voiceVolumeFor(player) / 100
      );

    audio.play().catch(() => {});
    return;
  }

  try {
    const source =
      context.createMediaStreamSource(
        stream
      );

    const gain =
      context.createGain();

    source.connect(gain);
    gain.connect(
      context.destination
    );

    voiceRemoteSources.set(
      player,
      source
    );

    voiceRemoteGains.set(
      player,
      gain
    );

    // Prevent duplicate playback from the <audio> element.
    audio.muted = true;

    applyVoiceUserVolume(player);
  } catch (error) {
    console.warn(
      "Voice gain graph failed:",
      error
    );

    audio.muted =
      voiceDeafened;

    audio.volume =
      Math.min(
        1,
        voiceVolumeFor(player) / 100
      );

    audio.play().catch(() => {});
  }
}

function isInVoiceCall() {
  return !!(
    me &&
    authenticated &&
    voiceMembers[me]
  );
}

function voiceMemberNames() {
  return Object.keys(
    voiceMembers || {}
  );
}

function renderVoice() {
  const currentVolumeOwner =
    String(me || "")
      .toLowerCase();

  if (
    currentVolumeOwner &&
    currentVolumeOwner !==
      voiceVolumeLoadedFor
  ) {
    voiceVolumeLoadedFor =
      currentVolumeOwner;

    loadVoiceUserVolumes();

    for (
      const player of
      voiceAudioElements.keys()
    ) {
      applyVoiceUserVolume(
        player
      );
    }
  }

  const holder =
    $("voiceMembers");

  if (!holder) return;

  holder.innerHTML = "";

  const members =
    voiceMemberNames();

  $("voiceStatus").textContent =
    members.length
      ? `${members.length} ${
          members.length === 1
            ? "pessoa na call"
            : "pessoas na call"
        }`
      : "Ninguém na call";

  if (!members.length) {
    const empty =
      document.createElement("div");

    empty.className = "voice-empty";
    empty.textContent =
      "Ninguém entrou na call ainda.";

    holder.appendChild(empty);
  } else {
    for (const player of members) {
      const state =
        voiceMembers[player] || {};

      const card =
        document.createElement("div");

      card.className =
        `voice-member${
          player === me ? " me" : ""
        }`;

      const avatar =
        document.createElement("div");

      avatar.className =
        "voice-member-avatar";
      avatar.textContent =
        player === me ? "👤" : "🎧";

      const copy =
        document.createElement("div");

      copy.className =
        "voice-member-copy";

      const name =
        document.createElement("strong");

      name.textContent =
        player === me
          ? `${player} (você)`
          : player;

      const subtitle =
        document.createElement("span");

      subtitle.className =
        "voice-member-state";

      subtitle.textContent =
        state.deafened
          ? "Ensurdecido"
          : state.muted
            ? "Microfone mutado"
            : "Conectado";

      copy.append(
        name,
        subtitle
      );

      const icons =
        document.createElement("div");

      icons.className =
        "voice-member-icons";

      if (state.muted) {
        const mutedIcon =
          document.createElement("span");
        mutedIcon.textContent = "🔇";
        mutedIcon.title =
          "Microfone mutado";
        icons.appendChild(mutedIcon);
      }

      if (state.deafened) {
        const deafIcon =
          document.createElement("span");
        deafIcon.textContent = "🎧";
        deafIcon.title =
          "Ensurdecido";
        icons.appendChild(deafIcon);
      }

      card.append(
        avatar,
        copy,
        icons
      );

      if (player !== me) {
        const volumeWrap =
          document.createElement("div");

        volumeWrap.className =
          "voice-member-volume";

        const volumeTop =
          document.createElement("div");

        volumeTop.className =
          "voice-member-volume-top";

        const volumeTitle =
          document.createElement("span");

        volumeTitle.textContent =
          "Volume";

        const volumeValue =
          document.createElement("span");

        volumeValue.dataset
          .voiceVolumeLabel =
            player;

        volumeValue.textContent =
          `${voiceVolumeFor(player)}%`;

        volumeTop.append(
          volumeTitle,
          volumeValue
        );

        const slider =
          document.createElement("input");

        slider.type = "range";
        slider.min = "0";
        slider.max = "200";
        slider.step = "5";
        slider.value =
          String(
            voiceVolumeFor(player)
          );

        slider.className =
          "voice-member-volume-slider";

        slider.setAttribute(
          "aria-label",
          `Volume de ${player}`
        );

        slider.addEventListener(
          "input",
          () => {
            setVoiceUserVolume(
              player,
              slider.value
            );
          }
        );

        volumeWrap.append(
          volumeTop,
          slider
        );

        card.appendChild(
          volumeWrap
        );
      }

      holder.appendChild(card);
    }
  }

  const enabled =
    !!me &&
    authenticated &&
    !!socket?.connected;

  const inCall =
    isInVoiceCall();

  $("voiceJoinBtn").disabled =
    !enabled ||
    voiceJoining;

  $("voiceJoinBtn").textContent =
    voiceJoining
      ? "Entrando..."
      : inCall
        ? "Sair da call"
        : "Entrar na call";

  $("voiceJoinBtn").classList.toggle(
    "in-call",
    inCall
  );

  $("voiceMuteBtn").disabled =
    !inCall;

  $("voiceDeafenBtn").disabled =
    !inCall;

  $("voiceMuteBtn").textContent =
    voiceMuted
      ? "🔇 Desmutar"
      : "🎙️ Mutar";

  $("voiceDeafenBtn").textContent =
    voiceDeafened
      ? "🔊 Tirar surdoncio"
      : "🎧 Surdoncio";

  $("voiceMuteBtn").classList.toggle(
    "active",
    voiceMuted
  );

  $("voiceDeafenBtn").classList.toggle(
    "active",
    voiceDeafened
  );

  if ($("voiceMicTestBtn")) {
    $("voiceMicTestBtn").disabled =
      !authenticated ||
      !me ||
      voiceMicTestActive;

    if (!voiceMicTestActive) {
      $("voiceMicTestBtn").textContent =
        "🎤 Iniciar teste";
    }
  }

  renderDashboardOverview();
}

function voiceIceKey(player) {
  return String(player || "");
}

function queueVoiceIce(player, candidate) {
  const key =
    voiceIceKey(player);

  if (!voicePendingIce.has(key)) {
    voicePendingIce.set(
      key,
      []
    );
  }

  voicePendingIce
    .get(key)
    .push(candidate);
}

async function flushVoiceIce(
  player,
  pc
) {
  const key =
    voiceIceKey(player);

  const pending =
    voicePendingIce.get(key) || [];

  voicePendingIce.delete(key);

  for (const candidate of pending) {
    try {
      await pc.addIceCandidate(
        candidate
      );
    } catch (error) {
      console.warn(
        "Voice pending ICE error:",
        error
      );
    }
  }
}

function emitVoiceIceCandidate(
  to,
  candidate
) {
  if (
    !candidate ||
    !socket?.connected ||
    !me
  ) {
    return;
  }

  const normal =
    candidateToObject(candidate);

  socket.emit(
    "voice-ice",
    {
      to,
      candidate: normal
    }
  );

  const tailscaleCandidate =
    makeTailscaleCandidate(
      candidate
    );

  if (tailscaleCandidate) {
    socket.emit(
      "voice-ice",
      {
        to,
        candidate:
          tailscaleCandidate
      }
    );
  }
}

function removeVoiceAudioElement(player) {
  destroyVoiceAudioGraph(
    player
  );

  const element =
    voiceAudioElements.get(player);

  if (element) {
    try {
      element.pause();
      element.srcObject = null;
      element.remove();
    } catch {}
  }

  voiceAudioElements.delete(player);
  voiceRemoteStreams.delete(player);
}

function applyVoiceDeafenState() {
  for (
    const player of
    voiceAudioElements.keys()
  ) {
    applyVoiceUserVolume(
      player
    );

    const audio =
      voiceAudioElements.get(player);

    if (
      audio &&
      !voiceRemoteGains.has(player) &&
      !voiceDeafened
    ) {
      audio.play().catch(() => {});
    }
  }
}

function attachVoiceRemoteStream(
  player,
  stream
) {
  voiceRemoteStreams.set(
    player,
    stream
  );

  let audio =
    voiceAudioElements.get(player);

  if (!audio) {
    audio =
      document.createElement("audio");

    audio.autoplay = true;
    audio.playsInline = true;
    audio.dataset.voicePlayer =
      player;

    $("voiceRemoteAudio")
      .appendChild(audio);

    voiceAudioElements.set(
      player,
      audio
    );
  }

  audio.srcObject = stream;

  attachVoiceGainGraph(
    player,
    stream,
    audio
  );
}

function closeVoicePeer(player) {
  const pc =
    voicePeers.get(player);

  if (pc) {
    try {
      pc.close();
    } catch {}
  }

  voicePeers.delete(player);
  voicePendingIce.delete(
    voiceIceKey(player)
  );

  removeVoiceAudioElement(
    player
  );
}

function createVoicePeer(player) {
  const existing =
    voicePeers.get(player);

  if (existing) {
    return existing;
  }

  const pc =
    new RTCPeerConnection(
      RTC_CONFIG
    );

  voicePeers.set(
    player,
    pc
  );

  for (
    const track of
    voiceLocalStream?.getAudioTracks() || []
  ) {
    pc.addTrack(
      track,
      voiceLocalStream
    );
  }

  pc.onicecandidate = event => {
    if (event.candidate) {
      emitVoiceIceCandidate(
        player,
        event.candidate
      );
    }
  };

  pc.ontrack = event => {
    const [stream] =
      event.streams;

    if (stream) {
      attachVoiceRemoteStream(
        player,
        stream
      );
    }
  };

  pc.onconnectionstatechange = () => {
    const state =
      pc.connectionState;

    if (
      state === "failed" ||
      state === "closed"
    ) {
      closeVoicePeer(player);
    }

    if (state === "disconnected") {
      $("voiceMessage").textContent =
        `Conexão de voz com ${player} interrompida.`;
    }
  };

  return pc;
}

async function createVoiceOffer(
  player
) {
  if (
    !voiceLocalStream ||
    player === me
  ) {
    return;
  }

  const pc =
    createVoicePeer(player);

  const offer =
    await pc.createOffer();

  await pc.setLocalDescription(
    offer
  );

  socket.emit(
    "voice-offer",
    {
      to: player,
      sdp: pc.localDescription
    }
  );
}

async function handleVoiceOffer(
  from,
  sdp
) {
  if (
    !isInVoiceCall() ||
    from === me
  ) {
    return;
  }

  // Replace a stale peer if necessary.
  const old =
    voicePeers.get(from);

  if (
    old &&
    old.signalingState === "closed"
  ) {
    closeVoicePeer(from);
  }

  const pc =
    createVoicePeer(from);

  await pc.setRemoteDescription(
    sdp
  );

  await flushVoiceIce(
    from,
    pc
  );

  const answer =
    await pc.createAnswer();

  await pc.setLocalDescription(
    answer
  );

  socket.emit(
    "voice-answer",
    {
      to: from,
      sdp: pc.localDescription
    }
  );
}

async function handleVoiceAnswer(
  from,
  sdp
) {
  const pc =
    voicePeers.get(from);

  if (!pc) return;

  await pc.setRemoteDescription(
    sdp
  );

  await flushVoiceIce(
    from,
    pc
  );
}

async function handleVoiceIce(
  from,
  candidate
) {
  const pc =
    voicePeers.get(from);

  if (
    pc &&
    pc.remoteDescription
  ) {
    try {
      await pc.addIceCandidate(
        candidate
      );
    } catch (error) {
      console.warn(
        "Voice ICE error:",
        error
      );
    }

    return;
  }

  queueVoiceIce(
    from,
    candidate
  );
}

function applyVoiceMicState() {
  for (
    const track of
    voiceLocalStream
      ?.getAudioTracks() || []
  ) {
    track.enabled =
      !voiceMuted;
  }
}

function emitVoiceState() {
  if (
    !socket?.connected ||
    !isInVoiceCall()
  ) {
    return;
  }

  socket.emit(
    "voice-state",
    {
      muted: voiceMuted,
      deafened: voiceDeafened
    }
  );
}

async function joinVoiceCall() {
  if (
    voiceJoining ||
    isInVoiceCall() ||
    !authenticated ||
    !me ||
    !socket?.connected
  ) {
    return;
  }

  voiceJoining = true;
  $("voiceMessage").textContent =
    "Pedindo acesso ao microfone...";
  renderVoice();

  try {
    const stream =
      await navigator.mediaDevices
        .getUserMedia({
          video: false,
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
            channelCount: 1
          }
        });

    voiceLocalStream = stream;
    voiceMuted = false;
    voiceDeafened = false;

    applyVoiceMicState();

    socket.emit(
      "voice-join"
    );

    $("voiceMessage").textContent =
      "Entrando na sala de voz...";
  } catch (error) {
    console.error(
      "Microphone access failed:",
      error
    );

    voiceJoining = false;
    voiceLocalStream = null;

    $("voiceMessage").textContent =
      error?.name === "NotAllowedError"
        ? "Microfone bloqueado. Libere o acesso no Windows."
        : "Não consegui abrir o microfone.";

    renderVoice();
  }
}

async function leaveVoiceCall(
  notifyServer = true
) {
  if (
    notifyServer &&
    isInVoiceCall()
  ) {
    await playVoiceCue(
      "leave"
    );
  }

  if (
    notifyServer &&
    socket?.connected &&
    me &&
    voiceMembers[me]
  ) {
    socket.emit(
      "voice-leave"
    );
  }

  for (
    const player of
    [...voicePeers.keys()]
  ) {
    closeVoicePeer(player);
  }

  for (
    const track of
    voiceLocalStream?.getTracks() || []
  ) {
    try {
      track.stop();
    } catch {}
  }

  voiceLocalStream = null;
  voiceMuted = false;
  voiceDeafened = false;
  voiceJoining = false;

  if (me && voiceMembers[me]) {
    const next = {
      ...voiceMembers
    };

    delete next[me];
    voiceMembers = next;
  }

  $("voiceMessage").textContent =
    "";

  renderVoice();
}

async function toggleVoiceMute() {
  if (!isInVoiceCall()) return;

  voiceMuted =
    !voiceMuted;

  applyVoiceMicState();
  emitVoiceState();
  renderVoice();

  await playVoiceCue(
    voiceMuted
      ? "mute"
      : "unmute"
  );
}

async function toggleVoiceDeafen() {
  if (!isInVoiceCall()) return;

  voiceDeafened =
    !voiceDeafened;

  applyVoiceDeafenState();
  emitVoiceState();
  renderVoice();

  await playVoiceCue(
    voiceDeafened
      ? "deafen"
      : "undeafen"
  );
}

function renderControls() {
  $("meLabel").textContent = authenticated && me
    ? `Você: ${me} 🔒`
    : "Você: não autenticado";

  const enabled = !!me && authenticated && !!socket?.connected;

  $("chatInput").disabled = !enabled;
  $("sendBtn").disabled = !enabled;
  $("presenceBtn").disabled = !enabled;

  const btn = $("presenceBtn");

  btn.classList.remove(
    "status-playing",
    "status-not-now",
    "status-not-today",
    "status-later",
    "status-custom"
  );

  if (!me) {
    btn.textContent = "Definir status";
    return;
  }

  const info = presenceInfo(me);
  const display = presenceDisplay(me);

  btn.textContent = info.status === "unset"
    ? "Definir status"
    : `${display.icon} ${display.text}`;

  if (info.status !== "unset") {
    btn.classList.add(
      `status-${info.status.replace("_", "-")}`
    );
  }
}

function scrollToDashboardSection(
  sectionId
) {
  const target =
    document.getElementById(
      sectionId
    );

  if (!target) {
    return;
  }

  target.scrollIntoView({
    behavior: "smooth",
    block: "start"
  });

  for (
    const button of
    document.querySelectorAll(
      ".top-nav-btn[data-section-target]"
    )
  ) {
    button.classList.toggle(
      "active",
      button.dataset
        .sectionTarget ===
        sectionId
    );
  }
}


function renderAll() {
  renderLoginPlayers();
  renderIdentity();
  renderPlayers();
  renderCalls();
  renderControls();
  renderVoice();
  renderScreenShare();
  renderDashboardOverview();
}

function appendMessage(msg) {
  const div = document.createElement("div");
  div.className = "message";

  div.innerHTML = `
    <div class="message-head">
      <span class="message-author">${escapeHtml(msg.from)}</span>
      <span class="message-time">${timeOf(msg.at)}</span>
    </div>
    <div class="message-body">${escapeHtml(msg.text)}</div>
  `;

  $("chat").appendChild(div);
  $("chat").scrollTop = $("chat").scrollHeight;
  if (msg?.from && msg.from !== me) addRecentActivity(`Nova mensagem de ${msg.from}`, "chat", msg.at);
}

// ---------------------------------------------------
// Screen source picker + capture
// ---------------------------------------------------

function resetIsolatedAudioQueue() {
  isolatedAudioQueue = [];
  isolatedAudioQueueSamples = 0;
  isolatedAudioCurrentChunk = null;
  isolatedAudioCurrentOffset = 0;
}

function bytesToInt16Pcm(bytes) {
  const raw =
    bytes instanceof Uint8Array
      ? bytes
      : new Uint8Array(bytes);

  const sampleCount =
    Math.floor(raw.byteLength / 2);

  const samples =
    new Int16Array(sampleCount);

  const view = new DataView(
    raw.buffer,
    raw.byteOffset,
    raw.byteLength
  );

  for (
    let i = 0;
    i < sampleCount;
    i += 1
  ) {
    samples[i] =
      view.getInt16(i * 2, true);
  }

  return samples;
}

function enqueueIsolatedAudio(bytes) {
  const samples =
    bytesToInt16Pcm(bytes);

  if (!samples.length) return;

  isolatedAudioQueue.push(samples);
  isolatedAudioQueueSamples +=
    samples.length;

  const maxSamples =
    48000 * 2;

  while (
    isolatedAudioQueueSamples > maxSamples &&
    isolatedAudioQueue.length > 1
  ) {
    const dropped =
      isolatedAudioQueue.shift();

    isolatedAudioQueueSamples -=
      dropped.length;
  }
}

function nextIsolatedStereoFrame() {
  while (
    !isolatedAudioCurrentChunk ||
    isolatedAudioCurrentOffset + 1 >=
      isolatedAudioCurrentChunk.length
  ) {
    isolatedAudioCurrentChunk =
      isolatedAudioQueue.shift() || null;

    isolatedAudioCurrentOffset = 0;

    if (!isolatedAudioCurrentChunk) {
      return [0, 0];
    }

    isolatedAudioQueueSamples -=
      isolatedAudioCurrentChunk.length;
  }

  const left =
    isolatedAudioCurrentChunk[
      isolatedAudioCurrentOffset
    ] / 32768;

  const right =
    isolatedAudioCurrentChunk[
      isolatedAudioCurrentOffset + 1
    ] / 32768;

  isolatedAudioCurrentOffset += 2;

  return [left, right];
}

async function destroyIsolatedAudioBridge() {
  if (isolatedAudioUnsubscribe) {
    isolatedAudioUnsubscribe();
    isolatedAudioUnsubscribe = null;
  }

  if (isolatedAudioProcessor) {
    try {
      isolatedAudioProcessor.disconnect();
    } catch {}

    isolatedAudioProcessor.onaudioprocess = null;
    isolatedAudioProcessor = null;
  }

  isolatedAudioDestination = null;

  if (isolatedAudioContext) {
    try {
      await isolatedAudioContext.close();
    } catch {}

    isolatedAudioContext = null;
  }

  resetIsolatedAudioQueue();
}

async function createIsolatedAudioTrack() {
  await destroyIsolatedAudioBridge();

  const AudioContextClass =
    window.AudioContext ||
    window.webkitAudioContext;

  if (!AudioContextClass) {
    throw new Error(
      "Web Audio API indisponível."
    );
  }

  const context =
    new AudioContextClass({
      sampleRate: 48000
    });

  const processor =
    context.createScriptProcessor(
      2048,
      0,
      2
    );

  const destination =
    context.createMediaStreamDestination();

  resetIsolatedAudioQueue();

  processor.onaudioprocess = event => {
    const left =
      event.outputBuffer.getChannelData(0);

    const right =
      event.outputBuffer.getChannelData(1);

    for (
      let i = 0;
      i < left.length;
      i += 1
    ) {
      const [l, r] =
        nextIsolatedStereoFrame();

      left[i] = l;
      right[i] = r;
    }
  };

  processor.connect(destination);

  isolatedAudioUnsubscribe =
    window.arenaDesktop
      ?.onIsolatedAudioData?.(
        enqueueIsolatedAudio
      ) || null;

  await context.resume();

  isolatedAudioContext = context;
  isolatedAudioProcessor = processor;
  isolatedAudioDestination = destination;

  const track =
    destination.stream
      .getAudioTracks()[0];

  if (!track) {
    throw new Error(
      "Não consegui criar a faixa de áudio isolado."
    );
  }

  return track;
}

async function stopIsolatedAudio() {
  try {
    await window.arenaDesktop
      ?.stopIsolatedAudio?.();
  } catch {}

  await destroyIsolatedAudioBridge();
}

async function openSourcePicker() {
  if (!window.arenaDesktop?.getScreenSources) {
    $("callStatus").textContent = "Captura de tela não está disponível.";
    return;
  }

  $("sourceModal").classList.remove("hidden");
  $("sourceGrid").innerHTML = "";
  $("sourceLoading").classList.remove("hidden");
  $("sourceLoading").textContent = "Carregando telas e janelas...";

  try {
    const sources = await window.arenaDesktop.getScreenSources();

    $("sourceLoading").classList.add("hidden");

    if (!sources.length) {
      $("sourceLoading").textContent = "Nenhuma tela ou janela encontrada.";
      $("sourceLoading").classList.remove("hidden");
      return;
    }

    for (const source of sources) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "source-item";
      button.title = source.name;

      const image = document.createElement("img");
      image.src = source.thumbnail;
      image.alt = "";

      const label = document.createElement("span");

      label.textContent =
        source.type === "window"
          ? `${source.name} · 🪟 janela direta + 🔊 áudio isolado`
          : `${source.name} · 🖥️ monitor + 🔊 áudio do sistema`;

      button.append(image, label);

      button.onclick = async () => {
        $("sourceModal").classList.add("hidden");
        await startSharingSource(source);
      };

      $("sourceGrid").appendChild(button);
    }
  } catch (error) {
    console.error(error);
    $("sourceLoading").textContent = "Não consegui listar suas telas.";
    $("sourceLoading").classList.remove("hidden");
  }
}

async function startSharingSource(source) {
  if (
    !me ||
    !authenticated ||
    !socket?.connected
  ) {
    return;
  }

  try {
    if (localStream) {
      await stopSharing();
    }

    await stopIsolatedAudio();

    const selected =
      await window.arenaDesktop
        .setSelectedScreenSource(
          source.id
        );

    if (!selected?.ok) {
      throw new Error(
        "Não foi possível selecionar a fonte."
      );
    }

    if (
      performanceSettings
        .forceLowQuality &&
      screenQualityKey !== "low"
    ) {
      setScreenQualityPreset(
        "low"
      );
    }

    const qualityPreset =
      getScreenQualityPreset();

    let stream = null;

    try {
      stream =
        await navigator.mediaDevices
          .getUserMedia({
            audio: false,
            video: {
              mandatory: {
                chromeMediaSource:
                  "desktop",
                chromeMediaSourceId:
                  source.id,
                maxWidth:
                  qualityPreset.width,
                maxHeight:
                  qualityPreset.height,
                maxFrameRate:
                  qualityPreset.fps
              }
            }
          });

      const videoTrack =
        stream
          .getVideoTracks()[0];

      await tuneScreenVideoTrack(
        videoTrack,
        qualityPreset
      );
    } finally {
      try {
        await window.arenaDesktop
          ?.consumeScreenCaptureGrant?.();
      } catch {}
    }

    let audioResult = null;

    // IMPORTANT:
    // The video capture is already alive at this point.
    // Audio is optional and must never prevent a window/screen
    // from being published. Native WASAPI process-loopback can
    // occasionally take too long on specific application windows.
    try {
      const audioTrack =
        await createIsolatedAudioTrack();

      let audioTimedOut = false;

      const nativeAudioPromise =
        Promise.resolve(
          window.arenaDesktop
            .startIsolatedAudio(
              source.id
            )
        );

      const audioTimeoutMs =
        source.type === "window"
          ? 2200
          : 3500;

      audioResult =
        await Promise.race([
          nativeAudioPromise,
          new Promise(resolve => {
            setTimeout(
              () => {
                audioTimedOut = true;

                resolve({
                  ok: false,
                  reason: "audio_timeout",
                  message:
                    source.type === "window"
                      ? "Janela transmitindo, mas o áudio isolado demorou demais para iniciar."
                      : "Tela transmitindo, mas o áudio do sistema demorou demais para iniciar."
                });
              },
              audioTimeoutMs
            );
          })
        ]);

      if (
        audioResult?.ok &&
        !audioTimedOut
      ) {
        stream.addTrack(
          audioTrack
        );
      } else {
        try {
          audioTrack.stop();
        } catch {}

        await destroyIsolatedAudioBridge();

        // If the native call finishes after our timeout, shut it
        // down immediately instead of leaving an orphan capture.
        if (audioTimedOut) {
          nativeAudioPromise
            .then(() => {
              window.arenaDesktop
                ?.stopIsolatedAudio?.()
                .catch?.(() => {});
            })
            .catch(() => {});
        }
      }
    } catch (error) {
      console.error(
        "Share audio setup failed:",
        error
      );

      audioResult = {
        ok: false,
        message:
          source.type === "window"
            ? "Janela transmitindo sem áudio isolado."
            : "Tela transmitindo sem áudio do sistema."
      };

      // Fire-and-forget cleanup. Do not block video publishing.
      window.arenaDesktop
        ?.stopIsolatedAudio?.()
        .catch?.(() => {});

      await destroyIsolatedAudioBridge();
    }

    localStream = stream;
    syncLocalPreviewPerformance();

    const audioTracks =
      localStream.getAudioTracks();

    if ($("audioShareState")) {
      $("audioShareState").textContent =
        source.type === "window"
          ? (
              audioTracks.length
                ? "🎧 Áudio isolado da janela: ligado"
                : "🔇 Áudio isolado: indisponível"
            )
          : (
              audioTracks.length
                ? "🔊 Áudio do sistema: ligado"
                : "🔇 Áudio do sistema: indisponível"
            );

      $("audioShareState")
        .classList.toggle(
          "audio-ok",
          audioTracks.length > 0
        );
    }

    if (!audioTracks.length) {
      $("callStatus").textContent =
        audioResult?.message ||
        (
          source.type === "window"
            ? "✅ Janela transmitindo em vídeo; áudio isolado indisponível."
            : "✅ Tela transmitindo em vídeo; áudio do sistema indisponível."
        );

      setTimeout(() => {
        $("callStatus").textContent = "";
      }, 7000);
    }

    for (
      const track of localStream.getTracks()
    ) {
      track.addEventListener(
        "ended",
        () => {
          if (localStream) {
            stopSharing();
          }
        }
      );
    }

    socket.emit(
      "screen-share-started",
      {
        player: me
      }
    );

    renderScreenShare();
  } catch (error) {
    console.error(
      "Screen capture failed:",
      error
    );

    await stopIsolatedAudio();

    const errorName =
      String(
        error?.name ||
        "ScreenCaptureError"
      )
        .replace(/\s+/g, " ")
        .slice(0, 60);

    const errorMessage =
      String(
        error?.message ||
        "sem detalhes"
      )
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 120);

    let runtimeSuffix = "";

    try {
      const runtime =
        await window.arenaDesktop
          ?.getRuntimeInfo?.();

      if (
        runtime?.electron ||
        runtime?.chromium
      ) {
        runtimeSuffix =
          ` · Electron ${runtime?.electron || "?"} / Chromium ${runtime?.chromium || "?"}`;
      }
    } catch {}

    $("callStatus").textContent =
      `Falha na captura: ${errorName} · ${errorMessage}${runtimeSuffix}`;

    setTimeout(() => {
      $("callStatus").textContent = "";
    }, 12000);
  }
}

async function stopSharing() {
  await stopIsolatedAudio();

  if (!localStream) return;

  const stream = localStream;
  localStream = null;

  for (const track of stream.getTracks()) {
    try { track.stop(); } catch {}
  }

  for (const [, pc] of senderPeers) {
    try { pc.close(); } catch {}
  }
  senderPeers.clear();
  activeViewers.clear();

  $("localVideo").srcObject = null;

  if ($("audioShareState")) {
    $("audioShareState").textContent = "Áudio: —";
    $("audioShareState").classList.remove("audio-ok");
  }

  if (me && socket?.connected) {
    socket.emit("screen-share-stopped", { player: me });
  }

  renderScreenShare();
}

// ---------------------------------------------------
// WebRTC
// ---------------------------------------------------

function iceKey(peer, direction) {
  return `${direction}:${peer}`;
}

function queueIce(peer, direction, candidate) {
  const key = iceKey(peer, direction);
  if (!pendingIce.has(key)) pendingIce.set(key, []);
  pendingIce.get(key).push(candidate);
}

async function flushIce(pc, peer, direction) {
  const key = iceKey(peer, direction);
  const list = pendingIce.get(key) || [];
  pendingIce.delete(key);

  for (const candidate of list) {
    try {
      await pc.addIceCandidate(candidate);
    } catch (error) {
      console.warn("ICE candidate rejected:", error);
    }
  }
}

function closeSenderPeer(viewer) {
  const old = senderPeers.get(viewer);
  if (old) {
    try { old.close(); } catch {}
    senderPeers.delete(viewer);
  }
  activeViewers.delete(viewer);
  renderScreenShare();
}

async function createSenderPeer(viewer) {
  if (!localStream || !me) return;

  closeSenderPeer(viewer);

  const pc = new RTCPeerConnection(RTC_CONFIG);
  senderPeers.set(viewer, pc);
  activeViewers.add(viewer);
  renderScreenShare();

  const videoSenders = [];

  for (
    const track of
    localStream.getTracks()
  ) {
    const sender =
      pc.addTrack(
        track,
        localStream
      );

    if (track.kind === "video") {
      videoSenders.push(
        sender
      );
    }
  }

  pc.onicecandidate = event => {
    if (event.candidate) {
      emitIceCandidate(viewer, event.candidate, "offerer");
    }
  };

  pc.onconnectionstatechange = () => {
    if (["failed", "closed", "disconnected"].includes(pc.connectionState)) {
      closeSenderPeer(viewer);
    }
  };

  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);

  // Apply caps after local description so Chromium has created
  // the encoding parameters for the video sender.
  for (
    const sender of
    videoSenders
  ) {
    await tuneScreenVideoSender(
      sender
    );
  }

  socket.emit("webrtc-offer", {
    from: me,
    to: viewer,
    sdp: pc.localDescription
  });

  await flushIce(pc, viewer, "sender");
}

function closeReceiverPeer(player) {
  const pc = receiverPeers.get(player);

  if (pc) {
    try {
      pc.close();
    } catch {}

    receiverPeers.delete(player);
  }

  remoteStreams.delete(player);
  receiverStatus.delete(player);
  remoteAudioEnabled.delete(player);

  pendingIce.delete(
    iceKey(player, "receiver")
  );
}

function stopWatching(player = "") {
  if (player) {
    if (
      watchedSharers.has(player) &&
      me &&
      socket?.connected
    ) {
      socket.emit("screen-stop-watching", {
        viewer: me,
        sharer: player
      });
    }

    watchedSharers.delete(player);
    closeReceiverPeer(player);
  } else {
    for (const sharer of [...watchedSharers]) {
      if (me && socket?.connected) {
        socket.emit("screen-stop-watching", {
          viewer: me,
          sharer
        });
      }

      closeReceiverPeer(sharer);
    }

    watchedSharers.clear();
  }

  renderScreenShare();
}

function watchPlayer(player) {
  if (
    !me ||
    !socket?.connected ||
    !sharing[player] ||
    player === me
  ) {
    return;
  }

  if (watchedSharers.has(player)) {
    return;
  }

  if (
    performanceSettings
      .limitOneStream &&
    watchedSharers.size > 0
  ) {
    for (
      const current of
      [...watchedSharers]
    ) {
      if (current !== player) {
        stopWatching(
          current
        );
      }
    }

    $("callStatus").textContent =
      "⚡ Modo econômico: mantendo apenas uma transmissão aberta.";

    setTimeout(() => {
      if (
        $("callStatus").textContent
          .startsWith("⚡ Modo econômico")
      ) {
        $("callStatus").textContent =
          "";
      }
    }, 3500);
  }

  watchedSharers.add(player);

  // Only the first opened stream gets audio automatically.
  // Additional streams start muted to avoid overlapping audio.
  const hasAudioStream = [...remoteAudioEnabled.values()]
    .some(Boolean);

  remoteAudioEnabled.set(
    player,
    !hasAudioStream && watchedSharers.size === 1
  );

  receiverStatus.set(
    player,
    "Solicitando transmissão..."
  );

  socket.emit("screen-watch-request", {
    viewer: me,
    sharer: player
  });

  renderScreenShare();
}

async function handleOffer(from, sdp) {
  if (!me || !watchedSharers.has(from)) return;

  // Replace only this sharer's receiver peer.
  const previous = receiverPeers.get(from);
  if (previous) {
    try {
      previous.close();
    } catch {}
  }

  const pc = new RTCPeerConnection(RTC_CONFIG);
  receiverPeers.set(from, pc);

  pc.onicecandidate = event => {
    if (event.candidate) {
      emitIceCandidate(
        from,
        event.candidate,
        "answerer"
      );
    }
  };

  pc.ontrack = event => {
    const [stream] = event.streams;

    if (stream) {
      remoteStreams.set(from, stream);

      const hasAudio =
        stream.getAudioTracks().length > 0;

      setReceiverStatus(
        from,
        hasAudio
          ? "Ao vivo · 🔊 áudio disponível"
          : "Ao vivo · sem áudio"
      );

      renderMultiView();
    }
  };

  pc.onconnectionstatechange = () => {
    const state = pc.connectionState;

    if (state === "connected") {
      setReceiverStatus(from, "Ao vivo");
    } else if (state === "connecting") {
      setReceiverStatus(from, "Conectando...");
    } else if (state === "failed") {
      setReceiverStatus(
        from,
        "Falha WebRTC/ICE"
      );
    } else if (state === "disconnected") {
      setReceiverStatus(
        from,
        "Conexão interrompida"
      );
    } else if (state === "closed") {
      receiverPeers.delete(from);
    }
  };

  await pc.setRemoteDescription(sdp);
  await flushIce(pc, from, "receiver");

  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);

  socket.emit("webrtc-answer", {
    from: me,
    to: from,
    sdp: pc.localDescription
  });
}

async function handleAnswer(from, sdp) {
  const pc = senderPeers.get(from);
  if (!pc) return;

  await pc.setRemoteDescription(sdp);
  await flushIce(pc, from, "sender");
}

async function handleIce(
  from,
  candidate,
  purpose = "offerer"
) {
  // ICE sent by the offerer (screen sharer) belongs to
  // our incoming receiver peer for that sharer.
  if (purpose === "offerer") {
    const receiverPc = receiverPeers.get(from);

    if (receiverPc) {
      if (receiverPc.remoteDescription) {
        try {
          await receiverPc.addIceCandidate(candidate);
        } catch (error) {
          console.warn("Receiver ICE error:", error);
        }
      } else {
        queueIce(from, "receiver", candidate);
      }

      return;
    }

    if (watchedSharers.has(from)) {
      queueIce(from, "receiver", candidate);
      return;
    }
  }

  // ICE sent by an answerer (viewer) belongs to our
  // outgoing sender peer for that viewer.
  const senderPc = senderPeers.get(from);

  if (senderPc) {
    if (senderPc.remoteDescription) {
      try {
        await senderPc.addIceCandidate(candidate);
      } catch (error) {
        console.warn("Sender ICE error:", error);
      }
    } else {
      queueIce(from, "sender", candidate);
    }
  } else if (purpose === "answerer") {
    queueIce(from, "sender", candidate);
  }
}


function versionParts(value) {
  const match = String(value || "").match(/\d+(?:\.\d+)*/);
  if (!match) return [];
  return match[0].split(".").map(part => Number.parseInt(part, 10) || 0);
}

function compareAppVersions(left, right) {
  const a = versionParts(left);
  const b = versionParts(right);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index += 1) {
    const av = a[index] || 0;
    const bv = b[index] || 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

function normalizedVersionPolicy(policy = {}) {
  return {
    currentVersion: String(policy.currentVersion || policy.appVersion || serverAppVersion || "").trim().slice(0,80),
    minimumVersion: String(policy.minimumVersion || policy.currentVersion || policy.appVersion || serverAppVersion || "").trim().slice(0,80),
    protocolVersion: Number(policy.protocolVersion || serverProtocolVersion || 0) || 0,
    message: String(policy.message || "coe pecinha, versão incompatível atualiza essa porra ai").trim().slice(0,180),
    updateRequired: policy.updateRequired === true
  };
}

function shouldRequireUpdate(policy) {
  const normalized = normalizedVersionPolicy(policy);
  if (normalized.updateRequired) return true;
  if (normalized.minimumVersion && compareAppVersions(localAppVersion, normalized.minimumVersion) < 0) return true;
  return normalized.protocolVersion > CLIENT_PROTOCOL_VERSION;
}

function showMandatoryUpdate(policy) {
  versionPolicy = normalizedVersionPolicy(policy);
  mandatoryUpdateRequired = shouldRequireUpdate(versionPolicy);
  if (!mandatoryUpdateRequired) {
    $("updateGate")?.classList.add("hidden");
    renderVersionMonitor();
    return;
  }
  if ($("updateGateTitle")) $("updateGateTitle").textContent = versionPolicy.message || "coe pecinha, versão incompatível atualiza essa porra ai";
  if ($("updateLocalVersion")) $("updateLocalVersion").textContent = localAppVersion || "desconhecida";
  if ($("updateRequiredVersion")) $("updateRequiredVersion").textContent = versionPolicy.currentVersion || versionPolicy.minimumVersion || "mais recente";
  if ($("updateGateDetail")) $("updateGateDetail").textContent = "O HOST bloqueou esta versão para evitar incompatibilidade entre os clientes.";
  $("updateGate")?.classList.remove("hidden");
  if ($("loginSubmit")) $("loginSubmit").disabled = true;
  if ($("createUserSubmit")) $("createUserSubmit").disabled = true;
  renderVersionMonitor();
}

function renderVersionMonitor() {
  const holder =
    $("clientVersionList");

  const monitorCard =
    holder?.closest(
      ".version-monitor-item"
    );

  const admin =
    isSorryeAdmin();

  if (monitorCard) {
    monitorCard.classList.toggle(
      "hidden",
      !admin
    );
  }

  if (!admin) {
    if (holder) {
      holder.innerHTML = "";
    }

    return;
  }

  if ($("currentVersionPolicyText")) {
    const current =
      versionPolicy?.currentVersion ||
      serverAppVersion ||
      "—";

    $("currentVersionPolicyText").textContent =
      `HOST exige ${current} · seu app ${localAppVersion || "—"}`;
  }

  if (!holder) {
    return;
  }

  holder.innerHTML = "";
  for (const player of PLAYERS) {
    const info = clientVersions[player] || {};
    const known = !!info.appVersion;
    const compatible = info.compatible === true;
    const row = document.createElement("div");
    row.className = `client-version-row ${known && compatible ? "version-ok" : known ? "version-old" : "version-unknown"}`;
    const versionText = known ? info.appVersion : "versão desconhecida";
    row.innerHTML = `<span>${escapeHtml(player)}</span><strong>${escapeHtml(versionText)}</strong><em>${known ? (compatible ? "Atualizado" : "Atualizar") : "Sem info"}</em>`;
    holder.appendChild(row);
  }
}

function playerVersionDisplay(player) {
  const info = clientVersions[player] || {};
  if (!info.appVersion) return { text: "Versão: desconhecida", css: "player-version-unknown" };
  return { text: `Versão: ${info.appVersion}`, css: info.compatible === true ? "player-version-ok" : "player-version-old" };
}

async function launchAutomaticUpdate() {
  if (updateLaunching) return;
  updateLaunching = true;
  if ($("updateNowBtn")) {
    $("updateNowBtn").disabled = true;
    $("updateNowBtn").textContent = "Abrindo atualizador...";
  }
  if ($("updateLaunchStatus")) $("updateLaunchStatus").textContent = "Preparando o instalador. Aceite o aviso do Windows se ele aparecer.";
  try {
    const result = await window.arenaDesktop?.launchUpdater?.();
    if (!result?.ok) throw new Error(result?.error || "Não foi possível abrir o atualizador.");
    if ($("updateLaunchStatus")) $("updateLaunchStatus").textContent = "Atualizador iniciado. O app vai fechar.";
  } catch (error) {
    updateLaunching = false;
    if ($("updateNowBtn")) {
      $("updateNowBtn").disabled = false;
      $("updateNowBtn").textContent = "Atualizar automaticamente";
    }
    if ($("updateLaunchStatus")) $("updateLaunchStatus").textContent = `Falha ao iniciar: ${String(error?.message || error)}`;
  }
}

// ---------------------------------------------------
// App boot
// ---------------------------------------------------

function validatedServerUrl(value) {
  let url;

  try {
    url =
      new URL(
        String(value || "")
      );
  } catch {
    throw new Error(
      "serverUrl inválida em config.json"
    );
  }

  if (
    url.protocol !== "http:" ||
    url.port !== "3000" ||
    url.username ||
    url.password
  ) {
    throw new Error(
      "serverUrl deve usar http:// e porta 3000."
    );
  }

  const host =
    url.hostname.toLowerCase();

  const local =
    host === "localhost" ||
    host === "127.0.0.1";

  const tailscaleMatch =
    /^100\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(
      host
    );

  let tailscale = false;

  if (tailscaleMatch) {
    const second =
      Number(tailscaleMatch[1]);

    const third =
      Number(tailscaleMatch[2]);

    const fourth =
      Number(tailscaleMatch[3]);

    tailscale =
      second >= 64 &&
      second <= 127 &&
      third >= 0 &&
      third <= 255 &&
      fourth >= 0 &&
      fourth <= 255;
  }

  if (!local && !tailscale) {
    throw new Error(
      "serverUrl precisa ser localhost ou um IP Tailscale 100.64.0.0/10."
    );
  }

  return url.origin;
}

async function start() {
  if (
    !window.arenaDesktop
      ?.getServerUrl
  ) {
    throw new Error(
      "Bridge de configuração indisponível."
    );
  }

  const serverUrl =
    validatedServerUrl(
      await window.arenaDesktop
        .getServerUrl()
    );

  activeServerUrl = serverUrl;
  startLatencyMonitor();

  try {
    const runtimeInfo = await window.arenaDesktop?.getRuntimeInfo?.();
    localAppVersion = String(runtimeInfo?.appVersion || "").trim().slice(0,80);
  } catch (error) {
    console.warn("Não foi possível descobrir a versão local:", error);
    localAppVersion = "";
  }

  try {
    const savedLogin =
      await window.arenaDesktop?.loadRememberedLogin?.();

    if (
      savedLogin &&
      typeof savedLogin.player === "string" &&
      savedLogin.player.trim() &&
      savedLogin.token
    ) {
      rememberedPlayer = savedLogin.player;
      lastProfile = savedLogin.player;
      rememberedToken = savedLogin.token;
    }
  } catch (error) {
    console.warn("Não foi possível restaurar login:", error);
  }

  try {
    myTailscaleIP = await window.arenaDesktop?.getTailscaleIP?.() || "";
    console.log("IP Tailscale para WebRTC:", myTailscaleIP || "(nao encontrado)");
  } catch (error) {
    console.warn("Falha ao obter IP Tailscale:", error);
    myTailscaleIP = "";
  }

  try {
    const initialIdle =
      await window.arenaDesktop
        ?.getSystemIdleState?.();

    if (initialIdle) {
      localSystemIdleState =
        normalizeSystemIdleSnapshot(
          initialIdle
        );
    }
  } catch (error) {
    console.warn(
      "Falha ao obter estado ocioso inicial:",
      error
    );
  }

  window.arenaDesktop
    ?.onSystemIdleState?.(
      handleSystemIdleSnapshot
    );

  socket = io(serverUrl, {
    transports: [
      "websocket"
    ],
    upgrade: false,
    reconnection: true,
    reconnectionDelay: 800,
    reconnectionDelayMax: 2500,
    timeout: 10_000,
    auth: {
      appVersion: localAppVersion,
      protocolVersion: CLIENT_PROTOCOL_VERSION
    }
  });

  socket.on(
    "connect_error",
    error => {
      loginAuthRequested = false;
      appEntered = false;
      authenticated = false;

      const detail =
        String(
          error?.message ||
          "falha no WebSocket"
        )
          .replace(/\s+/g, " ")
          .trim()
          .slice(0, 140);

      setGateServerState(
        false,
        "Falha ao conectar ao HOST"
      );

      showLoginGate(
        `Não conectou ao HOST: ${detail}`
      );

      if ($("loginSubmit")) {
        $("loginSubmit").disabled =
          false;
      }

      if ($("createUserSubmit")) {
        $("createUserSubmit").disabled =
          false;
      }

      console.error(
        "Socket.IO connect_error:",
        error
      );

      renderAll();
    }
  );

  socket.on("connect", () => {
    socket.emit("client-version", {
      appVersion: localAppVersion,
      protocolVersion: CLIENT_PROTOCOL_VERSION
    });

    setGateServerState(
      true,
      "Conectado · autenticação necessária"
    );

    authenticated = false;
    me = "";

    setGateServerState(
      true,
      rememberedToken && rememberedPlayer
        ? `Conectado · ${rememberedPlayer} lembrado`
        : "Conectado · pronto para entrar"
    );

    // Never authenticate a remembered token in the background.
    // The login screen remains visible until the user clicks Entrar.
    showLoginGate();
    renderAll();
  });

  socket.on("disconnect", () => {
    loginAuthRequested = false;
    appEntered = false;
    clearAuthRequestTimer();
    clearCreateUserTimer();
    clearDeleteUserTimer();

    if (
      $("manageUsersModal") &&
      !$("manageUsersModal").classList.contains("hidden")
    ) {
      $("deleteUserError").textContent =
        "Servidor desconectado.";
      $("deleteUserSubmit").disabled = true;
    }

    if ($("createUserSubmit")) {
      $("createUserSubmit").disabled = false;
    }

    if (
      $("createUserModal") &&
      !$("createUserModal").classList.contains("hidden")
    ) {
      $("createUserError").textContent =
        "Servidor desconectado. Verifique o HOST.";
    }
    authenticated = false;
    lastIdleStateSent = "";
    lastIdleHeartbeatAt = 0;

    if ($("authSubmitBtn")) {
      $("authSubmitBtn").disabled = false;
    }

    if ($("loginSubmit")) {
      $("loginSubmit").disabled = false;
    }

    if (
      $("authModal") &&
      !$("authModal").classList.contains("hidden")
    ) {
      $("authError").textContent =
        "Servidor desconectado. Verifique o Chat dos Pecinha HOST.";
    }
    setGateServerState(
      false,
      "Desconectado"
    );

    if (!authenticated) {
      showLoginGate(
        "Servidor desconectado. Verifique o HOST."
      );
    }

    online = Object.fromEntries(PLAYERS.map(p => [p, false]));
    sharing = Object.fromEntries(PLAYERS.map(p => [p, false]));

    stopWatching();
    cancelVoiceMicTest();
    leaveVoiceCall(false);

    for (const viewer of [...senderPeers.keys()]) {
      closeSenderPeer(viewer);
    }

    renderAll();
  });

  socket.on("state", state => {
    serverProtocolVersion = Number(
      state.protocolVersion || 0
    );

    serverAppVersion = String(
      state.appVersion || ""
    );

    showMandatoryUpdate(
      state.versionPolicy || {
        currentVersion: serverAppVersion,
        minimumVersion: serverAppVersion,
        protocolVersion: serverProtocolVersion
      }
    );

    clientVersions = state.clientVersions || clientVersions;

    setPlayers(state.players);

    presence = state.presence || presence;
    online = state.online || online;
    computerPresence =
      state.computerPresence || computerPresence;
    lastSeen = state.lastSeen || lastSeen;
    sharing = state.sharing || sharing;
    voiceMembers =
      state.voiceMembers || {};

    previousComputerPresence = structuredClone(computerPresence || {});
    previousSharingState = { ...(sharing || {}) };
    previousVoiceMembers = structuredClone(voiceMembers || {});

    $("chat").innerHTML = "";
    for (const msg of state.chatHistory || []) {
      appendMessage(msg);
    }

    renderAll();
    renderVersionMonitor();
    if (!recentActivities.length) addRecentActivity("Conectado ao squad", "online");
  });

  socket.on("version-policy", policy => {
    showMandatoryUpdate(policy || {});
  });

  socket.on("force-update", policy => {
    showMandatoryUpdate({
      ...(policy || {}),
      updateRequired: true
    });
  });

  socket.on("client-versions", next => {
    if (!isSorryeAdmin()) {
      clientVersions = {};
      renderPlayers();
      renderVersionMonitor();
      return;
    }

    clientVersions =
      next || {};

    renderPlayers();
    renderVersionMonitor();
  });

  socket.on("create-user-result", result => {
    clearCreateUserTimer();

    if (result?.ok) {
      $("createUserError").textContent =
        "Usuário criado. Entrando...";
      return;
    }

    failCreateUser(
      result?.error ||
      "Não foi possível criar o usuário."
    );
  });

  socket.on(
    "change-password-result",
    result => {
      clearChangePasswordTimer();

      if (result?.ok) {
        $("changePasswordError").textContent =
          "Senha alterada. Entrando...";
        return;
      }

      failChangePassword(
        result?.error ||
        "Não foi possível alterar a senha."
      );
    }
  );

  socket.on("auth-result", async result => {
    clearAuthRequestTimer();

    if (result?.ok) {
      me = result.player;
      lastProfile = result.player;
      authenticated = true;
      rememberedPlayer = result.player;

      $("loginSubmit").disabled = false;
      $("loginError").textContent = "";

      if (result.rememberToken) {
        rememberedToken = result.rememberToken;

        await window.arenaDesktop?.saveRememberedLogin?.({
          player: me,
          token: rememberedToken
        });
      }

      localStorage.setItem("arena-player", me);

      if (!$("authModal").classList.contains("hidden")) {
        closeAuthModal();
      }

      if (
        result.created &&
        !$("createUserModal").classList.contains("hidden")
      ) {
        closeCreateUserModal();
      }

      if (
        result.passwordChanged &&
        !$("changePasswordModal").classList.contains("hidden")
      ) {
        closeChangePasswordModal();
      }

      setGateServerState(
        true,
        result.remembered
          ? `Conectado · ${me} · login lembrado`
          : `Conectado · ${me}`
      );

      $("loginPassword").value = "";

      const shouldEnterNow =
        loginAuthRequested === true;

      loginAuthRequested = false;

      if (shouldEnterNow) {
        showAppShell();

        $("callStatus").textContent =
          `Autenticado como ${me}.`;

        setTimeout(() => {
          $("callStatus").textContent = "";
        }, 2500);
      } else {
        // Remembered login, newly-created user or password change:
        // authentication may be valid, but the gate stays visible.
        const gateMessage =
          result.created
            ? `Usuário ${me} criado. Clique em Entrar para abrir o app.`
            : result.passwordChanged
              ? "Senha alterada. Clique em Entrar para abrir o app."
              : result.remembered
                ? `Sessão de ${me} lembrada. Clique em Entrar.`
                : `Conta ${me} pronta. Clique em Entrar.`;

        showLoginGate(gateMessage);
      }

      refreshLoginGateControls();
      sendLocalComputerPresence(true);
      renderAll();
      return;
    }

    $("authSubmitBtn").disabled = false;

    if (result?.reason === "update_required") {
      showMandatoryUpdate({
        currentVersion: result.requiredVersion || serverAppVersion,
        minimumVersion: result.requiredVersion || serverAppVersion,
        protocolVersion: serverProtocolVersion,
        message: result.error || "coe pecinha, versão incompatível atualiza essa porra ai",
        updateRequired: true
      });
      return;
    }

    if (result?.reason === "invalid_token") {
      loginAuthRequested = false;
      rememberedToken = "";
      rememberedPlayer = "";
      authenticated = false;
      me = "";
      voiceVolumeLoadedFor = "";
      voiceUserVolumes = {};

      await window.arenaDesktop?.clearRememberedLogin?.();

      setGateServerState(
        true,
        "Conectado · senha necessária"
      );

      showLoginGate(
        "Seu login salvo expirou. Digite sua senha novamente."
      );

      renderAll();
      refreshLoginGateControls();
      return;
    }

    loginAuthRequested = false;

    const authMessage =
      result?.error || "Falha na autenticação.";

    $("authError").textContent = authMessage;
    $("authSubmitBtn").disabled = false;
    $("loginSubmit").disabled = false;

    if (!authenticated) {
      setGateServerState(
        true,
        "Conectado · autenticação necessária"
      );

      showLoginGate(authMessage);
    }

    renderAll();
  });

  socket.on("session-replaced", async ({ message }) => {
    cancelVoiceMicTest();
    await leaveVoiceCall(false);

    loginAuthRequested = false;
    appEntered = false;
    authenticated = false;
    rememberedToken = "";
    rememberedPlayer = "";
    me = "";
    voiceVolumeLoadedFor = "";
    voiceUserVolumes = {};

    await window.arenaDesktop?.clearRememberedLogin?.();

    $("callStatus").textContent =
      message || "Este perfil entrou em outro PC.";

    setGateServerState(
      true,
      "Conectado · autenticação necessária"
    );

    showLoginGate(
      message || "Este perfil entrou em outro PC."
    );

    renderAll();
  });

  socket.on(
    "delete-user-result",
    ({ ok, player, error }) => {
      clearDeleteUserTimer();

      if (!ok) {
        failDeleteUser(
          error ||
          "Não foi possível excluir o usuário."
        );
        return;
      }

      closeManageUsersModal();

      $("callStatus").textContent =
        `Usuário ${player} excluído permanentemente.`;

      setTimeout(() => {
        $("callStatus").textContent = "";
      }, 3500);
    }
  );

  socket.on(
    "user-deleted",
    async ({ player, message }) => {
      const affected =
        player === me ||
        player === rememberedPlayer;

      if (!affected) return;

      // Stop local media immediately. The server has already
      // revoked the account, so any follow-up emits are ignored.
      if (localStream) {
        try {
          await stopSharing();
        } catch {}
      }

      stopWatching();
      cancelVoiceMicTest();
      await leaveVoiceCall(false);

      loginAuthRequested = false;
      appEntered = false;
      authenticated = false;
      rememberedToken = "";
      rememberedPlayer = "";
      lastProfile = "";
      me = "";

      await window.arenaDesktop
        ?.clearRememberedLogin?.();

      setGateServerState(
        true,
        "Conectado · conta excluída"
      );

      showLoginGate(
        message ||
        "Sua conta foi excluída pelo administrador."
      );

      renderAll();
    }
  );

  socket.on("logout-result", async result => {
    if (!result?.ok) return;

    cancelVoiceMicTest();
    await leaveVoiceCall(false);

    loginAuthRequested = false;
    appEntered = false;
    authenticated = false;
    rememberedToken = "";
    rememberedPlayer = "";
    me = "";

    await window.arenaDesktop?.clearRememberedLogin?.();

    setGateServerState(
      true,
      "Conectado · autenticação necessária"
    );

    showLoginGate();
    renderAll();
  });

  socket.on("presence", next => {
    presence = next;
    renderAll();
  });

  socket.on("online", next => {
    online = next;
    renderAll();
  });

  socket.on("computer-presence", next => {
    diffComputerPresence(next || {});
    computerPresence = next || computerPresence;
    renderPlayers();
  });

  socket.on("activity", next => {
    lastSeen = next || lastSeen;
    renderPlayers();
  });

  socket.on("players", next => {
    setPlayers(next);
    renderAll();
  });

  socket.on(
    "voice-members",
    next => {
      diffVoiceMembers(next || {});
      voiceMembers =
        next || {};

      if (
        me &&
        voiceMembers[me]
      ) {
        voiceJoining = false;

        const myState =
          voiceMembers[me];

        voiceMuted =
          !!myState.muted;

        voiceDeafened =
          !!myState.deafened;

        applyVoiceMicState();
        applyVoiceDeafenState();

        $("voiceMessage").textContent =
          "Conectado à sala de voz.";
      } else if (voiceLocalStream) {
        // Server removed us from the room.
        leaveVoiceCall(false);
      }

      renderVoice();
    }
  );

  socket.on(
    "voice-existing-peers",
    async ({ players }) => {
      voiceJoining = false;

      await playVoiceCue(
        "join"
      );

      for (
        const player of
        players || []
      ) {
        try {
          await createVoiceOffer(
            player
          );
        } catch (error) {
          console.error(
            "Voice offer failed:",
            player,
            error
          );

          closeVoicePeer(player);
        }
      }

      renderVoice();
    }
  );

  socket.on(
    "voice-peer-joined",
    async ({ player }) => {
      if (
        !player ||
        player === me ||
        !isInVoiceCall()
      ) {
        return;
      }

      await playVoiceCue(
        "memberJoin"
      );

      $("voiceMessage").textContent =
        `${player} entrou na call.`;

      setTimeout(() => {
        if (
          $("voiceMessage").textContent ===
          `${player} entrou na call.`
        ) {
          $("voiceMessage").textContent =
            "Conectado à sala de voz.";
        }
      }, 2200);
    }
  );

  socket.on(
    "voice-peer-left",
    async ({ player }) => {
      const shouldNotify =
        !!player &&
        player !== me &&
        isInVoiceCall();

      closeVoicePeer(player);

      if (shouldNotify) {
        await playVoiceCue(
          "memberLeave"
        );

        $("voiceMessage").textContent =
          `${player} saiu da call.`;

        setTimeout(() => {
          if (
            $("voiceMessage").textContent ===
            `${player} saiu da call.`
          ) {
            $("voiceMessage").textContent =
              "Conectado à sala de voz.";
          }
        }, 2200);
      }

      renderVoice();
    }
  );

  socket.on(
    "voice-offer",
    async ({ from, sdp }) => {
      try {
        await handleVoiceOffer(
          from,
          sdp
        );
      } catch (error) {
        console.error(
          "Voice offer handling failed:",
          error
        );

        closeVoicePeer(from);
      }
    }
  );

  socket.on(
    "voice-answer",
    async ({ from, sdp }) => {
      try {
        await handleVoiceAnswer(
          from,
          sdp
        );
      } catch (error) {
        console.error(
          "Voice answer handling failed:",
          error
        );

        closeVoicePeer(from);
      }
    }
  );

  socket.on(
    "voice-ice",
    async ({ from, candidate }) => {
      await handleVoiceIce(
        from,
        candidate
      );
    }
  );

  socket.on("screen-sharing", next => {
    diffSharingState(next || {});
    sharing = next;

    for (const player of [...watchedSharers]) {
      if (!sharing[player]) {
        stopWatching(player);
      }
    }

    renderScreenShare();
  });

  socket.on("screen-share-ended", ({ player }) => {
    if (watchedSharers.has(player)) {
      receiverStatus.set(
        player,
        "Transmissão encerrada"
      );

      stopWatching(player);
    }
  });

  socket.on("screen-watch-request", async ({ viewer }) => {
    try {
      await createSenderPeer(viewer);
    } catch (error) {
      console.error("Could not create screen offer:", error);
      closeSenderPeer(viewer);
    }
  });

  socket.on("screen-viewer-left", ({ viewer }) => {
    closeSenderPeer(viewer);
  });

  socket.on("webrtc-offer", async ({ from, sdp }) => {
    try {
      await handleOffer(from, sdp);
    } catch (error) {
      console.error("Offer failed:", error);
      setReceiverStatus(
        from,
        "Erro ao abrir transmissão"
      );
    }
  });

  socket.on("webrtc-answer", async ({ from, sdp }) => {
    try {
      await handleAnswer(from, sdp);
    } catch (error) {
      console.error("Answer failed:", error);
      closeSenderPeer(from);
    }
  });

  socket.on(
    "webrtc-ice",
    async ({ from, candidate, purpose }) => {
      await handleIce(
        from,
        candidate,
        purpose
      );
    }
  );

  socket.on("chat-message", appendMessage);

  socket.on("incoming-call", ({ from }) => {
    showToast(from);
  });

  socket.on("soso-headset-alert", () => {
    window.arenaDesktop?.sosoHeadsetAlert?.();
  });

  socket.on(
    "soso-headset-alert-result",
    ({ ok, delivered, error }) => {
      if (ok) {
        $("callStatus").textContent =
          `Alerta do fone enviado para ${delivered} usuário(s).`;
      } else {
        $("callStatus").textContent =
          error || "Não foi possível enviar o alerta.";
      }

      setTimeout(() => {
        $("callStatus").textContent = "";
      }, 3000);
    }
  );

  socket.on("call-result", ({ to, delivered }) => {
    $("callStatus").textContent = delivered
      ? `Chamado enviado para ${to}.`
      : `${to} está offline agora.`;

    setTimeout(() => {
      $("callStatus").textContent = "";
    }, 3500);
  });

  socket.on("identity-taken", ({ message }) => {
    $("callStatus").textContent = message;
  });

  $("loginCreateUserBtn").onclick = () => {
    openCreateUserModal();
  };

  $("loginPlayerSelect").addEventListener(
    "change",
    () => {
      $("loginError").textContent = "";
      $("loginPassword").value = "";
      refreshLoginGateControls();
    }
  );

  $("loginForm").addEventListener(
    "submit",
    event => {
      event.preventDefault();

      const player =
        $("loginPlayerSelect").value;

      const password =
        $("loginPassword").value;

      $("loginError").textContent = "";

      if (!player) {
        $("loginError").textContent =
          "Escolha seu usuário.";
        return;
      }

      const rememberedReady =
        !!rememberedToken &&
        !!rememberedPlayer &&
        player === rememberedPlayer;

      // Remembered session: still no automatic login.
      // Only this explicit click sends the saved token to the HOST.
      if (rememberedReady) {
        loginAuthRequested = true;
        $("loginSubmit").disabled = true;
        $("loginError").textContent =
          "Entrando...";

        sendRememberedAuth(
          rememberedPlayer,
          rememberedToken
        );

        return;
      }

      if (!password) {
        $("loginError").textContent =
          "Digite sua senha.";
        return;
      }

      loginAuthRequested = true;
      $("loginSubmit").disabled = true;
      $("loginError").textContent =
        "Verificando senha...";

      pendingAuthProfile = player;

      sendProfileAuth(player, password);
    }
  );

  $("loginChangePasswordBtn").onclick = () => {
    openChangePasswordModal(
      $("loginPlayerSelect").value
    );
  };

  $("manageUsersBtn").onclick = () => {
    openManageUsersModal();
  };

  $("manageUsersClose").onclick =
    closeManageUsersModal;

  $("manageUsersCancel").onclick =
    closeManageUsersModal;

  $("manageUsersModal").addEventListener(
    "click",
    event => {
      if (event.target === $("manageUsersModal")) {
        closeManageUsersModal();
      }
    }
  );

  $("deleteUserSelect").addEventListener(
    "change",
    () => {
      $("deleteUserError").textContent = "";
      renderDeleteUserOptions();
    }
  );

  $("deleteUserSubmit").onclick = () => {
    submitDeleteUser(
      $("deleteUserSelect").value
    );
  };

  $("sosoHeadsetAlertBtn").onclick = () => {
    if (
      !authenticated ||
      String(me || "").toLowerCase() !== "sorrye" ||
      !socket?.connected
    ) {
      return;
    }

    $("callStatus").textContent =
      "Enviando alerta do fone...";

    socket.emit("soso-headset-alert");
  };

  $("mainChangePasswordBtn").onclick = () => {
    openChangePasswordModal(me);
  };

  $("logoutBtn").onclick = async () => {
    if (localStream) {
      await stopSharing();
    }

    stopWatching();

    rememberedToken = "";
    rememberedPlayer = "";
    await window.arenaDesktop?.clearRememberedLogin?.();

    if (socket?.connected && authenticated) {
      socket.emit("logout");
    } else {
      authenticated = false;
      me = "";
      showLoginGate();
      renderAll();
    }
  };

  $("changePasswordClose").onclick =
    closeChangePasswordModal;

  $("changePasswordCancel").onclick =
    closeChangePasswordModal;

  $("changePasswordModal").addEventListener(
    "click",
    event => {
      if (event.target === $("changePasswordModal")) {
        closeChangePasswordModal();
      }
    }
  );

  $("changePasswordForm").addEventListener(
    "submit",
    event => {
      event.preventDefault();

      const player =
        $("changePasswordUser").value;

      const oldPassword =
        $("oldPassword").value;

      const newPassword =
        $("newPassword").value;

      const confirm =
        $("newPasswordConfirm").value;

      if (!player) {
        failChangePassword(
          "Escolha o usuário."
        );
        return;
      }

      if (!oldPassword) {
        failChangePassword(
          "Digite sua senha atual."
        );
        return;
      }

      if (newPassword.length < 6) {
        failChangePassword(
          "A nova senha precisa ter pelo menos 6 caracteres."
        );
        return;
      }

      if (newPassword !== confirm) {
        failChangePassword(
          "As duas novas senhas não são iguais."
        );
        return;
      }

      if (oldPassword === newPassword) {
        failChangePassword(
          "A nova senha precisa ser diferente da atual."
        );
        return;
      }

      submitPasswordChange(
        player,
        oldPassword,
        newPassword
      );
    }
  );

  $("createUserClose").onclick = closeCreateUserModal;
  $("createUserCancel").onclick = closeCreateUserModal;

  $("createUserModal").addEventListener(
    "click",
    event => {
      if (event.target === $("createUserModal")) {
        closeCreateUserModal();
      }
    }
  );

  $("createUserForm").addEventListener(
    "submit",
    event => {
      event.preventDefault();

      const username =
        $("createUsername").value
          .trim()
          .replace(/\s+/g, " ");

      const password =
        $("createPassword").value;

      const confirm =
        $("createPasswordConfirm").value;

      if (username.length < 3) {
        failCreateUser(
          "O nome precisa ter pelo menos 3 caracteres."
        );
        return;
      }

      if (password.length < 6) {
        failCreateUser(
          "A senha precisa ter pelo menos 6 caracteres."
        );
        return;
      }

      if (password !== confirm) {
        failCreateUser(
          "As duas senhas não são iguais."
        );
        return;
      }

      submitCreateUser(username, password);
    }
  );

  $("authForm").addEventListener("submit", event => {
    event.preventDefault();
    const password = $("authPassword").value;
    if (!pendingAuthProfile) return $("authError").textContent = "Escolha um perfil.";
    if (!password) return $("authError").textContent = "Digite a senha.";
    sendProfileAuth(pendingAuthProfile, password);
  });
  $("authCancelBtn").onclick = closeAuthModal;
  $("authModalClose").onclick = closeAuthModal;
  $("authModal").addEventListener("click", event => {
    if (event.target === $("authModal")) closeAuthModal();
  });

  $("presenceBtn").onclick = () => {
    if (!me || !authenticated || !socket?.connected) return;

    const info = presenceInfo(me);

    if (info.status === "later" && info.targetAt) {
      const date = new Date(info.targetAt);

      $("presenceTimeInput").value =
        `${String(date.getHours()).padStart(2, "0")}:` +
        `${String(date.getMinutes()).padStart(2, "0")}`;
    }

    $("presenceTimeHint").textContent = "";
    $("presenceCustomHint").textContent = "";

    $("presenceCustomInput").value =
      info.status === "custom"
        ? info.customText
        : "";

    const takaExtras =
      $("takaActivityExtras");

    if (takaExtras) {
      takaExtras.classList.toggle(
        "hidden",
        String(me || "").toLowerCase() !== "taka"
      );
    }

    $("presenceModal").classList.remove("hidden");
  };

  for (const btn of document.querySelectorAll("[data-presence-status]")) {
    btn.addEventListener("click", () => {
      setPresenceStatus(btn.dataset.presenceStatus);
    });
  }

  for (
    const btn of document.querySelectorAll(
      "[data-player-activity]"
    )
  ) {
    btn.addEventListener("click", () => {
      setPlayerActivity(
        btn.dataset.playerActivity
      );
    });
  }

  $("presenceCustomBtn").onclick = () => {
    const text =
      $("presenceCustomInput").value
        .trim()
        .replace(/\s+/g, " ");

    if (!text) {
      $("presenceCustomHint").textContent =
        "Digite alguma coisa pro seu status.";
      return;
    }

    if (text.length > 80) {
      $("presenceCustomHint").textContent =
        "Use no máximo 80 caracteres.";
      return;
    }

    setPresenceStatus(
      "custom",
      null,
      text
    );
  };

  $("presenceClearBtn").onclick = () => {
    setPresenceStatus("unset");
  };

  $("activityClearBtn").onclick = () => {
    setPlayerActivity("unset");
  };

  $("presenceLaterBtn").onclick = () => {
    const value = $("presenceTimeInput").value;
    const targetAt = nextTargetFromTime(value);

    if (!targetAt) {
      $("presenceTimeHint").textContent =
        "Escolha um horário válido.";
      return;
    }

    setPresenceStatus("later", targetAt);
  };

  $("presenceModalClose").onclick = () => {
    $("presenceModal").classList.add("hidden");
  };

  $("presenceModal").addEventListener("click", event => {
    if (event.target === $("presenceModal")) {
      $("presenceModal").classList.add("hidden");
    }
  });

  $("chatForm").addEventListener("submit", event => {
    event.preventDefault();

    const input = $("chatInput");
    const text = input.value.trim();

    if (!text || !me || !socket?.connected) return;

    socket.emit("chat-message", {
      from: me,
      text
    });

    input.value = "";
    input.focus();
  });

  $("voiceJoinBtn").onclick = async () => {
    if (isInVoiceCall()) {
      await leaveVoiceCall(true);
    } else {
      await joinVoiceCall();
    }
  };

  $("voiceMuteBtn").onclick = async () => {
    await toggleVoiceMute();
  };

  $("voiceDeafenBtn").onclick = async () => {
    await toggleVoiceDeafen();
  };

  $("voiceMicTestBtn").onclick = async () => {
    await startVoiceMicTest();
  };

  $("voiceMicTestPlayback").addEventListener(
    "ended",
    () => {
      clearVoiceMicTestPlayback();
      setVoiceMicMeter(0);

      setVoiceMicTestStatus(
        "Grave 5 segundos e ouça como seu microfone está saindo."
      );
    }
  );

  for (
    const presetCard of
    document.querySelectorAll(
      "[data-quality-preset]"
    )
  ) {
    presetCard.onclick = () => {
      setScreenQualityPreset(
        presetCard.dataset
          .qualityPreset
      );
    };
  }

  for (
    const navButton of
    document.querySelectorAll(
      "[data-section-target]"
    )
  ) {
    navButton.onclick = () => {
      const sectionId =
        navButton.dataset
          .sectionTarget;

      if (sectionId) {
        scrollToDashboardSection(
          sectionId
        );
      }
    };
  }

  if ($("configChangePasswordBtn")) {
    $("configChangePasswordBtn").onclick =
      () => {
        openChangePasswordModal(me);
      };
  }

  if ($("configLogoutBtn")) {
    $("configLogoutBtn").onclick =
      () => {
        $("logoutBtn").click();
      };
  }

  if ($("configManageUsersBtn")) {
    $("configManageUsersBtn").onclick =
      () => {
        openManageUsersModal();
      };
  }

  if ($("configSosoAlertBtn")) {
    $("configSosoAlertBtn").onclick =
      () => {
        $("sosoHeadsetAlertBtn").click();
      };
  }


  if ($("updateNowBtn")) {
    $("updateNowBtn").onclick = launchAutomaticUpdate;
  }

  if ($("quickVoiceBtn")) $("quickVoiceBtn").onclick = async () => {
    $("voiceTab").scrollIntoView({ behavior: "smooth", block: "start" });
    if (!isInVoiceCall() && !$("voiceJoinBtn").disabled) await joinVoiceCall();
  };
  if ($("quickStreamBtn")) $("quickStreamBtn").onclick = () => {
    $("screenTab").scrollIntoView({ behavior: "smooth", block: "start" });
    if (!localStream && !$("shareScreenBtn").disabled) openSourcePicker();
  };
  if ($("quickChatBtn")) $("quickChatBtn").onclick = () => {
    setCollapsiblePanel("chatPanel", true);
    setTimeout(() => $("chatInput")?.focus(), 350);
  };
  if ($("quickCallsBtn")) $("quickCallsBtn").onclick = () => {
    setCollapsiblePanel("chatPanel", true);
    setTimeout(() => $("callButtons")?.scrollIntoView({ behavior: "smooth", block: "center" }), 350);
  };
  if ($("closeChatPanelBtn")) $("closeChatPanelBtn").onclick = () => setCollapsiblePanel("chatPanel", false);
  if ($("openAdvancedSettingsBtn")) $("openAdvancedSettingsBtn").onclick = () => setCollapsiblePanel("advancedSettingsPanel", true);
  if ($("closeAdvancedSettingsBtn")) $("closeAdvancedSettingsBtn").onclick = () => setCollapsiblePanel("advancedSettingsPanel", false);
  if ($("clearActivityBtn")) $("clearActivityBtn").onclick = () => { recentActivities.length = 0; renderActivityFeed(); };
  renderActivityFeed();

  const perfToggleMap = {
    perfReduceEffects:
      "reduceEffects",
    perfHideLocalPreview:
      "hideLocalPreview",
    perfLimitOneStream:
      "limitOneStream",
    perfSlowUiUpdates:
      "slowUiUpdates",
    perfForceLowQuality:
      "forceLowQuality"
  };

  if ($("perfLowEndMode")) {
    $("perfLowEndMode").onchange =
      event => {
        setLowEndMode(
          event.target.checked
        );
      };
  }

  for (
    const [id, key] of
    Object.entries(
      perfToggleMap
    )
  ) {
    const control =
      $(id);

    if (!control) {
      continue;
    }

    control.onchange =
      event => {
        updatePerformanceSetting(
          key,
          event.target.checked
        );
      };
  }

  renderPerformanceSettings();

  const shareQualitySelect =
    $("shareQualitySelect");

  if (shareQualitySelect) {
    shareQualitySelect.value =
      getScreenQualityPreset().key;

    shareQualitySelect.onchange =
      () => {
        setScreenQualityPreset(
          shareQualitySelect.value
        );
      };
  }

  renderScreenQualityControls();

  $("shareScreenBtn").onclick = () => {
    if (localStream) {
      stopSharing();
    } else {
      openSourcePicker();
    }
  };

  $("sourceModalClose").onclick = () => {
    $("sourceModal").classList.add("hidden");
  };

  $("sourceModal").addEventListener("click", event => {
    if (event.target === $("sourceModal")) {
      $("sourceModal").classList.add("hidden");
    }
  });

  $("stopWatchingBtn").onclick = () => {
    stopWatching();
  };

  $("expandMultiviewBtn").onclick = () => {
    const stage = $("videoStage");
    const expanded =
      !stage.classList.contains("expanded");

    stage.classList.toggle(
      "expanded",
      expanded
    );

    document.body.classList.toggle(
      "multiview-open",
      expanded
    );

    $("expandMultiviewBtn").textContent =
      expanded
        ? "Restaurar grade"
        : "Expandir grade";
  };

  $("toastClose").onclick = () => {
    $("toast").classList.add("hidden");
  };

  window.arenaDesktop
    ?.onAppFullscreenChanged?.(
      enabled => {
        if (
          !enabled &&
          fullscreenStreamPlayer
        ) {
          fullscreenStreamPlayer =
            "";

          applyStreamFullscreenState();
          renderMultiView();
        }
      }
    );

  document.addEventListener(
    "keydown",
    event => {
      if (
        event.key === "Escape" &&
        fullscreenStreamPlayer
      ) {
        exitStreamFullscreen()
          .then(
            () => renderMultiView()
          )
          .catch(() => {});
      }
    }
  );

  window.addEventListener("beforeunload", () => {
    if (latencyTimer) { clearInterval(latencyTimer); latencyTimer = null; }
    cancelVoiceMicTest();
    clearVoiceMicTestPlayback();

    if (
      me &&
      authenticated &&
      socket?.connected &&
      voiceMembers[me]
    ) {
      socket.emit("voice-leave");
    }

    for (
      const track of
      voiceLocalStream?.getTracks() || []
    ) {
      try {
        track.stop();
      } catch {}
    }

    window.arenaDesktop
      ?.stopIsolatedAudio?.()
      .catch?.(() => {});

    if (localStream && me && authenticated && socket?.connected) {
      socket.emit("screen-share-stopped", { player: me });
    }

    for (const sharer of [...watchedSharers]) {
      if (me && authenticated && socket?.connected) {
        socket.emit("screen-stop-watching", {
          viewer: me,
          sharer
        });
      }
    }

    for (const track of localStream?.getTracks() || []) {
      try { track.stop(); } catch {}
    }
  });

  renderAll();

  // The login page is intentionally always the first visible screen.
  // Even a valid remembered session must click "Entrar".
  showLoginGate();

  startPresenceTicker();
}

start().catch(error => {
  console.error(
    "Chat dos Pecinha startup error:",
    error
  );

  const detail =
    String(
      error?.message ||
      "erro desconhecido"
    )
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 160);

  setGateServerState(
    false,
    "Erro ao iniciar conexão"
  );

  showLoginGate(
    `Falha ao iniciar: ${detail}`
  );

  if ($("serverText")) {
    $("serverText").textContent =
      "Erro de configuração";
  }
});
