const {
  app,
  BrowserWindow,
  desktopCapturer,
  ipcMain,
  session,
  safeStorage,
  Tray,
  Menu,
  nativeImage,
  screen,
  powerMonitor
} = require("electron");
const path = require("path");
const fs = require("fs");
const { execFileSync, spawn } = require("child_process");
const net = require("net");
const { pathToFileURL } = require("url");

// We want WebRTC to see private interfaces too, including the Tailscale adapter.
// This keeps the media connection peer-to-peer inside the private network.
// Keep Tailscale/private interfaces visible to WebRTC.
// On Windows, Chromium's WGC window capturer can fail with
// E_ACCESSDENIED (0x80070005) for otherwise capturable app windows.
// Disable only the WGC WINDOW backend so WebRTC falls back to the
// legacy/DXGI-GDI window capturer. Screen/monitor WGC stays untouched.
app.commandLine.appendSwitch(
  "disable-features",
  [
    "WebRtcHideLocalIpsWithMdns",
    "AllowWgcWindowCapturer",
    "AllowWgcWindowZeroHz"
  ].join(",")
);

// Voice calls should keep playing remote participants even when
// another person joins after our initial click.
app.commandLine.appendSwitch(
  "autoplay-policy",
  "no-user-gesture-required"
);


const hasSingleInstanceLock = app.requestSingleInstanceLock();

if (!hasSingleInstanceLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    showMainWindow();
  });
}

let mainWindow;
let tray;
let quitting = false;
let hostServerProcess = null;
let selectedScreenSourceId = "";
let screenCaptureGrantUntil = 0;
let screenCaptureGrantNonce = 0;
let isolatedAudioCapture = null;
let isolatedAudioProcessId = null;
let urgentCallWindows = new Set();
let compactOverlayWindows = new Set();
let systemIdleMonitorTimer = null;
const SYSTEM_AWAY_SECONDS = 5 * 60;

const isBackgroundLaunch =
  process.argv.includes("--background");

if (process.platform === "win32") {
  console.log(
    "Window capture backend: direct window / WGC disabled"
  );

  console.log(
    `Runtime: Electron ${process.versions.electron} / Chromium ${process.versions.chrome}`
  );
}

app.setAppUserModelId("com.arenasquad.desktop");

function isTrustedMainWebContents(webContents) {
  return !!(
    mainWindow &&
    !mainWindow.isDestroyed() &&
    webContents === mainWindow.webContents
  );
}

function isTrustedMainIpcEvent(event) {
  return !!(
    event &&
    isTrustedMainWebContents(event.sender) &&
    event.senderFrame ===
      mainWindow.webContents.mainFrame
  );
}

function trustedIpcHandle(
  channel,
  handler
) {
  ipcMain.handle(
    channel,
    async (event, ...args) => {
      if (!isTrustedMainIpcEvent(event)) {
        console.warn(
          `IPC bloqueado de renderer não confiável: ${channel}`
        );

        throw new Error(
          "IPC sender not allowed"
        );
      }

      return handler(
        event,
        ...args
      );
    }
  );
}

function cleanShortText(
  value,
  maxLength
) {
  return String(value || "")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .trim()
    .slice(0, maxLength);
}


function hasActiveScreenCaptureGrant() {
  return !!(
    selectedScreenSourceId &&
    screenCaptureGrantUntil > Date.now()
  );
}

function clearScreenCaptureGrant() {
  screenCaptureGrantUntil = 0;
}

function framesReferToSameFrame(
  frameA,
  frameB
) {
  return !!(
    frameA &&
    frameB &&
    frameA.processId ===
      frameB.processId &&
    frameA.routingId ===
      frameB.routingId
  );
}

function isTrustedPermissionContext(
  webContents,
  requestingOrigin,
  details
) {
  if (
    isTrustedMainWebContents(
      webContents
    )
  ) {
    return true;
  }

  // Some permission checks can arrive with a null webContents.
  // The temporary grant can only be armed by trusted main-renderer
  // IPC, so allow only a main-frame file:// check during that grant.
  if (
    !webContents &&
    hasActiveScreenCaptureGrant() &&
    details?.isMainFrame === true
  ) {
    const origin =
      String(
        requestingOrigin ||
        details?.securityOrigin ||
        ""
      ).toLowerCase();

    return (
      origin === "file://" ||
      origin === "null" ||
      origin.startsWith("file:")
    );
  }

  return false;
}

function systemIdleSnapshot() {
  let idleSeconds = 0;

  try {
    idleSeconds = Math.max(
      0,
      Math.floor(
        powerMonitor.getSystemIdleTime()
      )
    );
  } catch {}

  return {
    state:
      idleSeconds >= SYSTEM_AWAY_SECONDS
        ? "away"
        : "online",
    idleSeconds,
    thresholdSeconds: SYSTEM_AWAY_SECONDS,
    at: Date.now()
  };
}

function sendSystemIdleSnapshot() {
  if (
    !mainWindow ||
    mainWindow.isDestroyed()
  ) {
    return;
  }

  mainWindow.webContents.send(
    "system:idle-state",
    systemIdleSnapshot()
  );
}

function startSystemIdleMonitor() {
  if (systemIdleMonitorTimer) {
    clearInterval(
      systemIdleMonitorTimer
    );
  }

  sendSystemIdleSnapshot();

  systemIdleMonitorTimer =
    setInterval(
      sendSystemIdleSnapshot,
      5000
    );
}

trustedIpcHandle(
  "system:get-idle-state",
  async () =>
    systemIdleSnapshot()
);

trustedIpcHandle(
  "window:set-fullscreen",
  async (_event, enabled) => {
    if (
      !mainWindow ||
      mainWindow.isDestroyed()
    ) {
      return false;
    }

    mainWindow.setFullScreen(
      enabled === true
    );

    return true;
  }
);

const PUBLIC_UPDATE_BOOTSTRAP_URL =
  "https://raw.githubusercontent.com/sorryeeee/chat-dos-pecinha-download/main/bootstrap.ps1";

trustedIpcHandle(
  "update:launch",
  async () => {
    if (process.platform !== "win32") {
      return { ok: false, error: "Atualização automática disponível apenas no Windows." };
    }

    const cacheBust = Date.now();
    const command = [
      '$ErrorActionPreference = "Stop"',
      '$ProgressPreference = "SilentlyContinue"',
      `irm "${PUBLIC_UPDATE_BOOTSTRAP_URL}?x=${cacheBust}" | iex`
    ].join("; ");

    try {
      const child = spawn(
        "powershell.exe",
        ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
        { detached: true, windowsHide: false, stdio: "ignore" }
      );
      child.unref();
      setTimeout(() => { quitting = true; app.quit(); }, 700);
      return { ok: true };
    } catch (error) {
      console.error("Falha ao iniciar updater:", error);
      return { ok: false, error: String(error?.message || "Falha ao iniciar o updater.") };
    }
  }
);

trustedIpcHandle(
  "runtime:get-info",
  async () => {
    return {
      electron:
        String(
          process.versions.electron ||
          ""
        ),
      chromium:
        String(
          process.versions.chrome ||
          ""
        ),
      node:
        String(
          process.versions.node ||
          ""
        ),
      platform:
        process.platform,
      appVersion:
        app.getVersion()
    };
  }
);

trustedIpcHandle("screen:get-sources", async () => {
  const sources = await desktopCapturer.getSources({
    types: ["screen", "window"],
    thumbnailSize: { width: 320, height: 180 },
    fetchWindowIcons: false
  });

  return sources.map(source => ({
    id: source.id,
    name: source.name,
    type:
      String(source.id).startsWith("window:")
        ? "window"
        : "screen",
    thumbnail: source.thumbnail.toDataURL()
  }));
});


function windowHandleFromSourceId(sourceId) {
  const match =
    /^window:(\d+):/i.exec(
      String(sourceId || "")
    );

  return match ? match[1] : "";
}

function resolveWindowProcessIdSync(sourceId) {
  if (process.platform !== "win32") {
    return null;
  }

  const hwnd =
    windowHandleFromSourceId(sourceId);

  if (!hwnd) {
    return null;
  }

  const script = `
$ErrorActionPreference = "Stop"

$code = @'
using System;
using System.Runtime.InteropServices;

public static class ArenaWindowPid
{
    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(
        IntPtr hWnd,
        out uint processId
    );
}
'@

Add-Type -TypeDefinition $code

$pidValue = [uint32]0
$handle = [IntPtr]([Int64]${hwnd})

[ArenaWindowPid]::GetWindowThreadProcessId(
    $handle,
    [ref]$pidValue
) | Out-Null

Write-Output $pidValue
`;

  try {
    const output = execFileSync(
      "powershell.exe",
      [
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        script
      ],
      {
        encoding: "utf8",
        windowsHide: true,
        timeout: 5000
      }
    ).trim();

    const pid =
      Number.parseInt(output, 10);

    return (
      Number.isInteger(pid) &&
      pid > 0
    )
      ? pid
      : null;
  } catch (error) {
    console.error(
      "Falha ao descobrir PID da janela:",
      error.message
    );

    return null;
  }
}

function loadLoopbackCaptureModule() {
  try {
    // Keep the optional native audio package isolated from the
    // app's core Electron/socket.io node_modules. Installing it
    // in the main node_modules previously allowed npm to prune
    // Electron itself.
    const modulePath = path.join(
      __dirname,
      "audio-deps",
      "node_modules",
      "loopback-capture"
    );

    const loaded =
      require(modulePath);

    return loaded?.default || loaded;
  } catch (error) {
    console.error(
      "loopback-capture não disponível:",
      error.message
    );

    return null;
  }
}

function stopIsolatedAudioCapture() {
  if (isolatedAudioCapture) {
    try {
      isolatedAudioCapture.stop();
    } catch (error) {
      console.warn(
        "Falha ao parar áudio isolado:",
        error.message
      );
    }
  }

  isolatedAudioCapture = null;
  isolatedAudioProcessId = null;
}

function startShareAudioCapture(
  sourceId,
  sourceType
) {
  stopIsolatedAudioCapture();

  if (process.platform !== "win32") {
    return {
      ok: false,
      reason: "windows_only",
      message:
        "Áudio compartilhado está disponível somente no Windows."
    };
  }

  const loopback =
    loadLoopbackCaptureModule();

  if (
    !loopback ||
    typeof loopback.LoopbackCapture !== "function"
  ) {
    return {
      ok: false,
      reason: "dependency_missing",
      message:
        "Módulo de áudio não está instalado. Rode o updater novamente."
    };
  }

  try {
    const capture =
      new loopback.LoopbackCapture();

    isolatedAudioCapture = capture;
    isolatedAudioProcessId = null;

    const onChunk = chunk => {
      if (
        isolatedAudioCapture !== capture ||
        !mainWindow ||
        mainWindow.isDestroyed()
      ) {
        return;
      }

      mainWindow.webContents.send(
        "screen:isolated-audio-data",
        Uint8Array.from(chunk)
      );
    };

    if (sourceType === "screen") {
      if (
        typeof capture.startSystemAudio !==
        "function"
      ) {
        throw new Error(
          "startSystemAudio indisponível no módulo instalado."
        );
      }

      capture.startSystemAudio(
        onChunk
      );

      return {
        ok: true,
        mode: "system",
        sampleRate: 48000,
        channels: 2,
        sampleFormat: "s16le"
      };
    }

    const pid =
      resolveWindowProcessIdSync(
        sourceId
      );

    if (!pid) {
      stopIsolatedAudioCapture();

      return {
        ok: false,
        reason: "pid_not_found",
        message:
          "Não consegui identificar o processo da janela escolhida."
      };
    }

    isolatedAudioProcessId = pid;

    capture.start(
      pid,
      true,
      onChunk
    );

    return {
      ok: true,
      mode: "process",
      processId: pid,
      sampleRate: 48000,
      channels: 2,
      sampleFormat: "s16le"
    };
  } catch (error) {
    stopIsolatedAudioCapture();

    console.error(
      "Falha no áudio compartilhado:",
      error
    );

    return {
      ok: false,
      reason: "capture_failed",
      message:
        sourceType === "screen"
          ? "Não consegui capturar o áudio do sistema."
          : "Não consegui capturar o áudio dessa janela."
    };
  }
}


trustedIpcHandle(
  "screen:set-selected-source",
  async (_event, sourceId) => {
    if (
      typeof sourceId !== "string" ||
      !sourceId ||
      sourceId.length > 256
    ) {
      return {
        ok: false,
        reason: "invalid_source"
      };
    }

    const sources =
      await desktopCapturer.getSources({
        types: ["screen", "window"],
        thumbnailSize: {
          width: 0,
          height: 0
        },
        fetchWindowIcons: false
      });

    const selected =
      sources.find(
        source =>
          source.id === sourceId
      );

    if (!selected) {
      selectedScreenSourceId = "";
      clearScreenCaptureGrant();

      return {
        ok: false,
        reason: "source_not_found"
      };
    }

    selectedScreenSourceId =
      selected.id;

    screenCaptureGrantNonce += 1;
    screenCaptureGrantUntil =
      Date.now() + 10000;

    return {
      ok: true,
      grantNonce:
        screenCaptureGrantNonce,
      type:
        sourceId.startsWith("window:")
          ? "window"
          : "screen"
    };
  }
);

trustedIpcHandle(
  "screen:consume-capture-grant",
  async () => {
    const hadGrant =
      hasActiveScreenCaptureGrant();

    clearScreenCaptureGrant();

    return {
      ok: hadGrant
    };
  }
);

trustedIpcHandle(
  "screen:start-isolated-audio",
  async (_event, sourceId) => {
    if (
      typeof sourceId !== "string" ||
      sourceId.length < 1 ||
      sourceId.length > 256
    ) {
      return {
        ok: false,
        reason: "invalid_source"
      };
    }

    const sources =
      await desktopCapturer.getSources({
        types: ["screen", "window"],
        thumbnailSize: {
          width: 0,
          height: 0
        },
        fetchWindowIcons: false
      });

    const selected =
      sources.find(
        source =>
          source.id === sourceId
      );

    if (!selected) {
      return {
        ok: false,
        reason: "source_not_found",
        message:
          "A fonte escolhida não existe mais."
      };
    }

    const sourceType =
      sourceId.startsWith("window:")
        ? "window"
        : "screen";

    return startShareAudioCapture(
      sourceId,
      sourceType
    );
  }
);

trustedIpcHandle(
  "screen:stop-isolated-audio",
  async () => {
    stopIsolatedAudioCapture();
    return true;
  }
);

function installDisplayMediaHandler() {
  session.defaultSession
    .setPermissionCheckHandler(
      (
        webContents,
        permission,
        requestingOrigin,
        details
      ) => {
        const trusted =
          isTrustedPermissionContext(
            webContents,
            requestingOrigin,
            details
          );

        if (!trusted) {
          return false;
        }

        // Chromium can check generic media/video before Electron
        // reaches the dedicated display-capture handler.
        // Video permission exists only during a fresh one-shot
        // screen-share intent created by the trusted renderer.
        if (
          permission === "media" &&
          (
            details?.mediaType === "video" ||
            details?.mediaType === "unknown"
          )
        ) {
          return hasActiveScreenCaptureGrant();
        }

        // Voice-call microphone remains audio-only.
        if (
          permission === "media" &&
          details?.mediaType === "audio"
        ) {
          return isTrustedMainWebContents(
            webContents
          );
        }

        if (
          permission ===
          "display-capture"
        ) {
          return hasActiveScreenCaptureGrant();
        }

        return false;
      }
    );

  session.defaultSession
    .setPermissionRequestHandler(
      (
        webContents,
        permission,
        callback,
        details
      ) => {
        const mediaTypes =
          Array.isArray(
            details?.mediaTypes
          )
            ? details.mediaTypes
            : [];

        const audioOnly =
          isTrustedMainWebContents(
            webContents
          ) &&
          permission === "media" &&
          mediaTypes.length > 0 &&
          mediaTypes.every(
            type =>
              type === "audio"
          );

        const screenVideoOnly =
          permission === "media" &&
          hasActiveScreenCaptureGrant() &&
          (
            mediaTypes.length === 0 ||
            mediaTypes.every(
              type =>
                type === "video"
            )
          );

        const displayCapture =
          permission ===
            "display-capture" &&
          hasActiveScreenCaptureGrant();

        callback(
          audioOnly ||
          screenVideoOnly ||
          displayCapture
        );
      }
    );

  session.defaultSession
    .setDisplayMediaRequestHandler(
      async (
        request,
        callback
      ) => {
        try {
          const mainFrame =
            mainWindow &&
            !mainWindow.isDestroyed()
              ? mainWindow
                  .webContents
                  .mainFrame
              : null;

          const trustedFrame =
            framesReferToSameFrame(
              request?.frame,
              mainFrame
            );

          if (
            !trustedFrame ||
            !request?.videoRequested
          ) {
            console.warn(
              "Display capture bloqueado: frame/request inválido.",
              {
                trustedFrame,
                videoRequested:
                  !!request?.videoRequested
              }
            );

            clearScreenCaptureGrant();
            callback({});
            return;
          }

          if (
            !hasActiveScreenCaptureGrant()
          ) {
            console.warn(
              "Display capture bloqueado: autorização ausente ou expirada."
            );

            callback({});
            return;
          }

          const sources =
            await desktopCapturer.getSources({
              types: [
                "screen",
                "window"
              ],
              thumbnailSize: {
                width: 0,
                height: 0
              },
              fetchWindowIcons: false
            });

          const selected =
            sources.find(
              source =>
                source.id ===
                selectedScreenSourceId
            );

          if (!selected) {
            console.warn(
              "Display capture bloqueado: fonte selecionada não existe mais."
            );

            selectedScreenSourceId = "";
            clearScreenCaptureGrant();
            callback({});
            return;
          }

          // One-shot: consume authorization before granting.
          clearScreenCaptureGrant();

          callback({
            video: selected
          });
        } catch (error) {
          clearScreenCaptureGrant();

          console.error(
            "Display media request failed:",
            error
          );

          callback({});
        }
      }
    );
}

function findTailscaleExe() {
  const candidates = [
    path.join(process.env.ProgramFiles || "", "Tailscale", "tailscale.exe"),
    path.join(process.env["ProgramFiles(x86)"] || "", "Tailscale", "tailscale.exe")
  ].filter(Boolean);

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) return candidate;
  }

  return "tailscale.exe";
}

trustedIpcHandle("tailscale:get-ip", async () => {
  try {
    const exe = findTailscaleExe();
    const output = execFileSync(exe, ["ip", "-4"], {
      encoding: "utf8",
      windowsHide: true,
      timeout: 4000
    });

    const ip = String(output || "")
      .trim()
      .split(/\s+/)
      .find(value => /^100\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(value));

    return ip || "";
  } catch (error) {
    console.warn("Nao foi possivel obter IP do Tailscale:", error.message);
    return "";
  }
});


function rememberedLoginPath() {
  return path.join(
    app.getPath("userData"),
    "arena-remembered-login.bin"
  );
}

trustedIpcHandle("auth:save-remembered", async (_event, login) => {
  try {
    if (
      !safeStorage.isEncryptionAvailable() ||
      !login ||
      typeof login.player !== "string" ||
      typeof login.token !== "string" ||
      !login.player ||
      !login.token ||
      login.player.length > 24 ||
      login.token.length > 256
    ) {
      return false;
    }

    const encrypted = safeStorage.encryptString(
      JSON.stringify({
        player: login.player,
        token: login.token
      })
    );

    fs.writeFileSync(
      rememberedLoginPath(),
      encrypted.toString("base64"),
      "utf8"
    );

    return true;
  } catch (error) {
    console.error("Falha ao salvar login lembrado:", error);
    return false;
  }
});

trustedIpcHandle("auth:load-remembered", async () => {
  try {
    const file = rememberedLoginPath();

    if (
      !safeStorage.isEncryptionAvailable() ||
      !fs.existsSync(file)
    ) {
      return null;
    }

    const encrypted = Buffer.from(
      fs.readFileSync(file, "utf8"),
      "base64"
    );

    const decrypted = safeStorage.decryptString(encrypted);
    const parsed = JSON.parse(decrypted);

    if (
      !parsed ||
      typeof parsed.player !== "string" ||
      typeof parsed.token !== "string"
    ) {
      return null;
    }

    return {
      player: parsed.player,
      token: parsed.token
    };
  } catch (error) {
    console.warn("Login lembrado indisponivel:", error.message);
    return null;
  }
});

trustedIpcHandle("auth:clear-remembered", async () => {
  try {
    const file = rememberedLoginPath();

    if (fs.existsSync(file)) {
      fs.unlinkSync(file);
    }

    return true;
  } catch (error) {
    console.error("Falha ao apagar login lembrado:", error);
    return false;
  }
});


function appConfig() {
  try {
    const configPath = path.join(__dirname, "config.json");

    const raw = fs
      .readFileSync(configPath, "utf8")
      .replace(/^\uFEFF/, "")
      .trim();

    return JSON.parse(raw);
  } catch (error) {
    console.error(
      "Falha ao ler desktop/config.json:",
      error.message
    );

    return {};
  }
}

function parseTrustedServerUrl() {
  const config =
    appConfig();

  try {
    const url =
      new URL(
        String(
          config.serverUrl || ""
        )
      );

    if (
      url.protocol !== "http:" ||
      url.port !== "3000" ||
      url.username ||
      url.password
    ) {
      return null;
    }

    const host =
      url.hostname.toLowerCase();

    const local =
      host === "localhost" ||
      host === "127.0.0.1";

    const tailscaleMatch =
      /^100\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(
        host
      );

    let tailscale = false;

    if (tailscaleMatch) {
      const second =
        Number(tailscaleMatch[1]);

      tailscale =
        second >= 64 &&
        second <= 127;
    }

    if (!local && !tailscale) {
      return null;
    }

    return {
      host,
      port: url.port,
      origin: url.origin
    };
  } catch {
    return null;
  }
}

trustedIpcHandle(
  "config:get-server-url",
  async () => {
    const trusted =
      parseTrustedServerUrl();

    if (!trusted?.origin) {
      throw new Error(
        "desktop/config.json possui serverUrl inválida."
      );
    }

    return trusted.origin;
  }
);

function installNetworkRequestGuard() {
  const trusted =
    parseTrustedServerUrl();

  session.defaultSession.webRequest.onBeforeRequest(
    {
      urls: [
        "http://*/*",
        "https://*/*",
        "ws://*/*",
        "wss://*/*"
      ]
    },
    (details, callback) => {
      try {
        const requestUrl =
          new URL(details.url);

        const sameServer =
          trusted &&
          requestUrl.hostname
            .toLowerCase() ===
              trusted.host &&
          requestUrl.port ===
            trusted.port &&
          (
            requestUrl.protocol ===
              "http:" ||
            requestUrl.protocol ===
              "ws:"
          );

        callback({
          cancel: !sameServer
        });
      } catch {
        callback({
          cancel: true
        });
      }
    }
  );
}

function hostModeFlagPath() {
  return path.join(__dirname, "host-mode.flag");
}

function hasHostModeFlag() {
  try {
    return fs.existsSync(hostModeFlagPath());
  } catch {
    return false;
  }
}

function getLocalTailscaleIPSync() {
  try {
    const exe = findTailscaleExe();

    const output = execFileSync(
      exe,
      ["ip", "-4"],
      {
        encoding: "utf8",
        windowsHide: true,
        timeout: 4000
      }
    );

    return String(output || "")
      .trim()
      .split(/\s+/)
      .find(value =>
        /^100\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(value)
      ) || "";
  } catch {
    return "";
  }
}

function configuredServerHost() {
  const serverUrl = String(
    appConfig().serverUrl || ""
  );

  try {
    return new URL(serverUrl).hostname;
  } catch {
    return "";
  }
}

function isHostInstall() {
  // The online updater writes this marker only on the HOST.
  // This avoids relying on config.json parsing for server startup.
  if (hasHostModeFlag()) {
    return true;
  }

  const serverUrl = String(
    appConfig().serverUrl || ""
  );

  if (
    /localhost/i.test(serverUrl) ||
    /127\.0\.0\.1/.test(serverUrl)
  ) {
    return true;
  }

  const configuredHost = configuredServerHost();
  const localTailscaleIP = getLocalTailscaleIPSync();

  return !!(
    configuredHost &&
    localTailscaleIP &&
    configuredHost === localTailscaleIP
  );
}

function isPortOpen(port, host = "127.0.0.1") {
  return new Promise(resolve => {
    const socket = new net.Socket();
    let settled = false;

    const finish = value => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(value);
    };

    socket.setTimeout(600);

    socket.once("connect", () => finish(true));
    socket.once("timeout", () => finish(false));
    socket.once("error", () => finish(false));

    socket.connect(port, host);
  });
}

function findNodeExe() {
  const candidates = [
    path.join(
      process.env.ProgramFiles || "",
      "nodejs",
      "node.exe"
    ),
    path.join(
      process.env.LOCALAPPDATA || "",
      "Programs",
      "nodejs",
      "node.exe"
    )
  ].filter(Boolean);

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return candidate;
    }
  }

  try {
    const result = execFileSync(
      "where.exe",
      ["node.exe"],
      {
        encoding: "utf8",
        windowsHide: true,
        timeout: 3000
      }
    );

    const first = String(result || "")
      .split(/\r?\n/)
      .map(value => value.trim())
      .find(Boolean);

    if (first && fs.existsSync(first)) {
      return first;
    }
  } catch {}

  return "";
}

async function ensureHostServer() {
  const hostMode = isHostInstall();

  console.log(
    "Arena host detection:",
    {
      hostMode,
      hostModeFlag: hasHostModeFlag(),
      configuredServerHost: configuredServerHost(),
      localTailscaleIP: getLocalTailscaleIPSync()
    }
  );

  if (!hostMode) return;

  if (await isPortOpen(3000)) {
    console.log("Arena server already running.");
    return;
  }

  const serverDir = path.join(__dirname, "..", "server");
  const serverScript = path.join(serverDir, "index.js");

  if (!fs.existsSync(serverScript)) {
    console.error("HOST server script not found:", serverScript);
    return;
  }

  const nodeExe = findNodeExe();

  try {
    if (nodeExe) {
      const logPath = path.join(
        serverDir,
        "arena-server.log"
      );

      const logFd = fs.openSync(logPath, "a");

      hostServerProcess = spawn(
        nodeExe,
        [serverScript],
        {
          cwd: serverDir,
          windowsHide: true,
          stdio: ["ignore", logFd, logFd]
        }
      );

      hostServerProcess.once("spawn", () => {
        try {
          fs.closeSync(logFd);
        } catch {}
      });
    } else {
      // Fallback: Electron itself can execute Node code without opening
      // a console window.
      const logPath = path.join(
        serverDir,
        "arena-server.log"
      );

      const logFd = fs.openSync(logPath, "a");

      hostServerProcess = spawn(
        process.execPath,
        [serverScript],
        {
          cwd: serverDir,
          windowsHide: true,
          stdio: ["ignore", logFd, logFd],
          env: {
            ...process.env,
            ELECTRON_RUN_AS_NODE: "1"
          }
        }
      );

      hostServerProcess.once("spawn", () => {
        try {
          fs.closeSync(logFd);
        } catch {}
      });
    }

    hostServerProcess.on("error", error => {
      console.error("Hidden HOST server failed:", error);
      hostServerProcess = null;
    });

    hostServerProcess.on("exit", () => {
      hostServerProcess = null;
    });

    // Give the server a moment to bind before the renderer connects.
    for (let attempt = 0; attempt < 30; attempt += 1) {
      if (await isPortOpen(3000)) {
        console.log("Hidden HOST server ready.");
        return;
      }

      await new Promise(resolve => setTimeout(resolve, 150));
    }

    console.warn("HOST server did not become ready in time.");

    showSystemNotification(
      "Chat dos Pecinha HOST",
      "O servidor não iniciou. Veja server\\arena-server.log."
    );
  } catch (error) {
    console.error("Could not start hidden HOST server:", error);
  }
}

function stopHostServer() {
  if (!hostServerProcess) return;

  try {
    hostServerProcess.kill();
  } catch {}

  hostServerProcess = null;
}

function showMainWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    createWindow();
    return;
  }

  if (mainWindow.isMinimized()) {
    mainWindow.restore();
  }

  mainWindow.show();
  mainWindow.focus();
}

function setOpenAtLogin(enabled) {
  app.setLoginItemSettings({
    openAtLogin: !!enabled,
    path: process.execPath,
    args: [
      __dirname,
      "--background"
    ]
  });
}

function rebuildTrayMenu() {
  if (!tray) return;

  const settings = app.getLoginItemSettings();

  tray.setContextMenu(
    Menu.buildFromTemplate([
      {
        label: "Abrir Chat dos Pecinha",
        click: showMainWindow
      },
      {
        label: "Iniciar com o Windows",
        type: "checkbox",
        checked: !!settings.openAtLogin,
        click: item => {
          setOpenAtLogin(item.checked);
          rebuildTrayMenu();
        }
      },
      { type: "separator" },
      {
        label: "Sair do Chat dos Pecinha",
        click: () => {
          quitting = true;
          app.quit();
        }
      }
    ])
  );
}

function createTray() {
  if (tray) return;

  const iconPath = path.join(__dirname, "tray-icon.png");

  const icon = fs.existsSync(iconPath)
    ? nativeImage.createFromPath(iconPath)
    : nativeImage.createEmpty();

  tray = new Tray(icon);
  tray.setToolTip("Chat dos Pecinha");

  tray.on("click", showMainWindow);
  tray.on("double-click", showMainWindow);

  rebuildTrayMenu();
}

trustedIpcHandle("system:notify", async (_event, payload) => {
  try {
    showCompactOverlay({
      icon: "🔔",
      title:
        cleanShortText(
          payload?.title,
          80
        ) || "Chat dos Pecinha",
      text:
        cleanShortText(
          payload?.body,
          220
        ),
      lifetimeMs: 5000
    });

    return true;
  } catch {
    return false;
  }
});


function safeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function compactOverlayPosition(
  width = 360,
  height = 88
) {
  let display = null;

  try {
    display =
      screen.getDisplayNearestPoint(
        screen.getCursorScreenPoint()
      );
  } catch {}

  if (!display) {
    try {
      display =
        mainWindow &&
        !mainWindow.isDestroyed()
          ? screen.getDisplayMatching(
              mainWindow.getBounds()
            )
          : screen.getPrimaryDisplay();
    } catch {
      display =
        screen.getPrimaryDisplay();
    }
  }

  const workArea =
    display.workArea;

  const slot =
    compactOverlayWindows.size;

  const gap = 10;
  const margin = 16;

  const maxSlots =
    Math.max(
      1,
      Math.floor(
        (
          workArea.height -
          (margin * 2)
        ) /
        (height + gap)
      )
    );

  const normalizedSlot =
    slot % maxSlots;

  return {
    x:
      workArea.x +
      workArea.width -
      width -
      margin,
    y:
      workArea.y +
      margin +
      normalizedSlot *
        (height + gap)
  };
}

function repositionCompactOverlays() {
  let index = 0;

  for (
    const overlay of
    compactOverlayWindows
  ) {
    if (
      !overlay ||
      overlay.isDestroyed()
    ) {
      continue;
    }

    let display = null;

    try {
      display =
        screen.getDisplayNearestPoint(
          screen.getCursorScreenPoint()
        );
    } catch {
      display =
        screen.getPrimaryDisplay();
    }

    const workArea =
      display.workArea;

    const width = 360;
    const height = 88;
    const gap = 10;
    const margin = 16;

    overlay.setPosition(
      workArea.x +
        workArea.width -
        width -
        margin,
      workArea.y +
        margin +
        index *
          (height + gap),
      false
    );

    index += 1;
  }
}

function showCompactOverlay({
  icon = "🔔",
  title = "Chat dos Pecinha",
  text = "",
  lifetimeMs = 4500
}) {
  const width = 360;
  const height = 88;

  const position =
    compactOverlayPosition(
      width,
      height
    );

  const overlay = new BrowserWindow({
    width,
    height,
    x: position.x,
    y: position.y,
    frame: false,
    transparent: true,
    resizable: false,
    maximizable: false,
    minimizable: false,
    fullscreenable: false,
    movable: false,
    focusable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    show: false,
    hasShadow: true,
    backgroundColor: "#00000000",
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false
    }
  });

  urgentCallWindows.add(
    overlay
  );

  compactOverlayWindows.add(
    overlay
  );

  overlay.setAlwaysOnTop(
    true,
    "screen-saver"
  );

  overlay.setVisibleOnAllWorkspaces(
    true,
    {
      visibleOnFullScreen: true
    }
  );

  const safeIcon =
    safeHtml(icon);

  const safeTitle =
    safeHtml(title);

  const safeText =
    safeHtml(text);

  const html = `
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Chat dos Pecinha</title>
<style>
  * { box-sizing:border-box; }
  html,body {
    margin:0;
    width:100%;
    height:100%;
    overflow:hidden;
    background:transparent;
    font-family:"Segoe UI",Arial,sans-serif;
  }
  body {
    display:flex;
    align-items:center;
    justify-content:center;
    padding:5px;
  }
  .toast {
    width:100%;
    height:100%;
    display:grid;
    grid-template-columns:34px 1fr;
    gap:10px;
    align-items:center;
    padding:11px 14px 11px 12px;
    border:1px solid rgba(255,122,24,.55);
    border-left:3px solid #ff7a18;
    border-radius:13px;
    background:rgba(14,20,29,.96);
    color:#f5f7fb;
    box-shadow:0 9px 28px rgba(0,0,0,.38);
    animation:enter .18s ease-out;
  }
  .icon {
    width:32px;
    height:32px;
    display:grid;
    place-items:center;
    border-radius:9px;
    background:rgba(255,122,24,.12);
    font-size:18px;
  }
  .content { min-width:0; }
  .title {
    margin:0 0 3px;
    color:#ff9a4c;
    font-size:10px;
    font-weight:800;
    letter-spacing:.08em;
    text-transform:uppercase;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  .text {
    margin:0;
    color:#e8edf4;
    font-size:13px;
    font-weight:600;
    line-height:1.25;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  @keyframes enter {
    from { opacity:0; transform:translateX(18px); }
    to { opacity:1; transform:translateX(0); }
  }
</style>
</head>
<body>
  <div class="toast">
    <div class="icon">${safeIcon}</div>
    <div class="content">
      <div class="title">${safeTitle}</div>
      <div class="text">${safeText}</div>
    </div>
  </div>
</body>
</html>`;

  overlay.loadURL(
    `data:text/html;charset=UTF-8,${encodeURIComponent(html)}`
  );

  overlay.once(
    "ready-to-show",
    () => {
      overlay.showInactive();
      overlay.setAlwaysOnTop(
        true,
        "screen-saver"
      );
      overlay.moveTop();
    }
  );

  const timer =
    setTimeout(
      () => {
        if (!overlay.isDestroyed()) {
          overlay.close();
        }
      },
      Math.max(
        1000,
        Number(lifetimeMs) ||
        4500
      )
    );

  overlay.on(
    "closed",
    () => {
      clearTimeout(timer);
      urgentCallWindows.delete(
        overlay
      );
      compactOverlayWindows.delete(
        overlay
      );
      repositionCompactOverlays();
    }
  );

  return overlay;
}

function showUrgentCallOverlay({
  from,
  recipient,
  specialSage = false
}) {
  if (!specialSage) {
    return showCompactOverlay({
      icon: "📢",
      title: "Chat dos Pecinha",
      text:
        `${cleanShortText(from, 24) || "Alguém"} te chamou pro Arena.`,
      lifetimeMs: 4500
    });
  }

  const overlay = new BrowserWindow({
    width: 520,
    height: 210,
    frame: false,
    transparent: false,
    resizable: false,
    maximizable: false,
    minimizable: false,
    fullscreenable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    show: false,
    center: true,
    backgroundColor: "#0e141d",
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false
    }
  });

  urgentCallWindows.add(overlay);

  overlay.setAlwaysOnTop(true, "screen-saver");
  overlay.setVisibleOnAllWorkspaces(true, {
    visibleOnFullScreen: true
  });

  const caller = safeHtml(from || "Alguém");

  const html = `
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Chat dos Pecinha</title>
<style>
  html,body {
    margin:0;
    width:100%;
    height:100%;
    overflow:hidden;
    background:#0e141d;
    color:#f5f7fb;
    font-family:Segoe UI,Arial,sans-serif;
  }

  body {
    display:grid;
    place-items:center;
    box-sizing:border-box;
    border:3px solid #ff7a18;
  }

  .card {
    width:100%;
    height:100%;
    display:grid;
    place-items:center;
    text-align:center;
    padding:24px;
    box-sizing:border-box;
  }

  .eyebrow {
    color:#ff7a18;
    font-weight:900;
    letter-spacing:.16em;
    font-size:12px;
    margin-bottom:10px;
  }

  #message {
    font-size:29px;
    font-weight:900;
    line-height:1.08;
    margin:0;
  }

  #sub {
    margin-top:12px;
    color:#aab5c5;
    font-size:14px;
  }

  .flash {
    animation:flash .28s linear 8;
  }

  @keyframes flash {
    0%,100% {
      background:#0e141d;
      color:#f5f7fb;
    }
    50% {
      background:#ff7a18;
      color:#111;
    }
  }

  .sage-final {
    background:#ff7a18 !important;
    color:#111 !important;
  }

  .sage-final #sub,
  .sage-final .eyebrow {
    color:#111 !important;
  }
</style>
</head>
<body id="body">
  <div class="card">
    <div>
      <div class="eyebrow">CHAT DOS PECINHA</div>
      <h1 id="message">${caller} ESTÁ TE CHAMANDO</h1>
      <div id="sub">abre o Chat dos Pecinha aí</div>
    </div>
  </div>

<script>
(() => {
  const specialSage = ${specialSage ? "true" : "false"};
  const body = document.getElementById("body");
  const message = document.getElementById("message");
  const sub = document.getElementById("sub");

  if (specialSage) {
    body.classList.add("flash");

    setTimeout(() => {
      body.classList.remove("flash");
      body.classList.add("sage-final");
      message.textContent = "RESPONDE LOGO SEARCH DO KRL";
      sub.textContent = "os mlk tão te chamando";
    }, 2450);
  }
})();
</script>
</body>
</html>`;

  overlay.loadURL(
    `data:text/html;charset=UTF-8,${encodeURIComponent(html)}`
  );

  overlay.once("ready-to-show", () => {
    overlay.showInactive();

    // Raise it above ordinary windows without stealing permanent focus.
    overlay.setAlwaysOnTop(true, "screen-saver");
    overlay.moveTop();
  });

  const closeAfterMs = specialSage ? 8500 : 5000;

  const timer = setTimeout(() => {
    if (!overlay.isDestroyed()) {
      overlay.close();
    }
  }, closeAfterMs);

  overlay.on("closed", () => {
    clearTimeout(timer);
    urgentCallWindows.delete(overlay);
  });
}

trustedIpcHandle("system:urgent-call", async (_event, payload) => {
  try {
    const recipient =
      cleanShortText(
        payload?.recipient,
        24
      );

    const from =
      cleanShortText(
        payload?.from,
        24
      );

    showUrgentCallOverlay({
      from,
      recipient,
      specialSage:
        recipient.trim().toLowerCase() === "sage"
    });

    return true;
  } catch (error) {
    console.error("Urgent call overlay failed:", error);
    return false;
  }
});


function showSosoHeadsetOverlay() {
  return showCompactOverlay({
    icon: "🎧",
    title: "Chat dos Pecinha",
    text: "Fone do soso descarregou.",
    lifetimeMs: 2000
  });
}

trustedIpcHandle("system:soso-headset-alert", async () => {
  try {
    showSosoHeadsetOverlay();
    return true;
  } catch (error) {
    console.error("Soso headset overlay failed:", error);
    return false;
  }
});

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1180,
    height: 900,
    minWidth: 920,
    minHeight: 700,
    backgroundColor: "#0b0f14",
    title: "Chat dos Pecinha",
    show: !isBackgroundLaunch,
    icon: path.join(__dirname, "tray-icon.png"),
    autoHideMenuBar: true,
    fullscreenable: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      backgroundThrottling: false
    }
  });

  mainWindow.on(
    "enter-full-screen",
    () => {
      if (
        mainWindow &&
        !mainWindow.isDestroyed()
      ) {
        mainWindow.webContents.send(
          "window:fullscreen-changed",
          true
        );
      }
    }
  );

  mainWindow.on(
    "leave-full-screen",
    () => {
      if (
        mainWindow &&
        !mainWindow.isDestroyed()
      ) {
        mainWindow.webContents.send(
          "window:fullscreen-changed",
          false
        );
      }
    }
  );

  // Explicitly allow WebRTC to enumerate local/private interfaces.
  mainWindow.webContents.setWebRTCIPHandlingPolicy("default");
  console.log("WebRTC IP policy:", mainWindow.webContents.getWebRTCIPHandlingPolicy());

  const trustedIndexUrl =
    pathToFileURL(
      path.join(
        __dirname,
        "index.html"
      )
    ).href;

  mainWindow.webContents.setWindowOpenHandler(
    () => ({
      action: "deny"
    })
  );

  mainWindow.webContents.on(
    "will-navigate",
    (event, url) => {
      if (url !== trustedIndexUrl) {
        event.preventDefault();
      }
    }
  );

  mainWindow.webContents.on(
    "will-redirect",
    event => {
      event.preventDefault();
    }
  );

  mainWindow.webContents.on(
    "will-attach-webview",
    event => {
      event.preventDefault();
    }
  );

  mainWindow.loadFile("index.html");

  mainWindow.on("close", event => {
    if (quitting) return;

    event.preventDefault();
    mainWindow.hide();

    if (tray && process.platform === "win32") {
      tray.displayBalloon({
        title: "Chat dos Pecinha",
        content:
          "Continuo rodando em segundo plano. Clique no ícone perto do relógio para abrir.",
        iconType: "info"
      });
    }
  });
}

app.whenReady().then(async () => {
  installDisplayMediaHandler();
  installNetworkRequestGuard();
  createTray();

  console.log(
    "Arena host detection:",
    {
      hostMode: isHostInstall(),
      hostModeFlag: hasHostModeFlag(),
      configuredServerHost: configuredServerHost(),
      localTailscaleIP: getLocalTailscaleIPSync(),
      serverManager: "Windows Task Scheduler"
    }
  );

  createWindow();
  startSystemIdleMonitor();

  powerMonitor.on(
    "resume",
    sendSystemIdleSnapshot
  );

  powerMonitor.on(
    "unlock-screen",
    sendSystemIdleSnapshot
  );

  app.on("activate", showMainWindow);
});

app.on("before-quit", () => {
  quitting = true;

  if (systemIdleMonitorTimer) {
    clearInterval(
      systemIdleMonitorTimer
    );
    systemIdleMonitorTimer = null;
  }

  stopIsolatedAudioCapture();
});

app.on("window-all-closed", () => {
  // Intentionally keep the app alive in the system tray.
});
