const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const APP_VERSION = "1.3.25.6.8.6.11-online-1";
const PROTOCOL_VERSION = 14;

// Cloud deployment stays backwards-compatible with the old Windows/Tailscale
// host. On the VPS, BIND_HOST=127.0.0.1 and TRUST_PROXY=1 keep Node private
// behind Caddy while rate limits still see the real client IP.
const BIND_HOST = String(process.env.BIND_HOST || "0.0.0.0").trim() || "0.0.0.0";
const TRUST_PROXY = String(process.env.TRUST_PROXY || "0") === "1";
const TURN_HOST = String(process.env.TURN_HOST || "").trim();
const TURN_SECRET = String(process.env.TURN_SECRET || "").trim();
const TURN_PORT = Math.max(1, Math.min(65535, Number(process.env.TURN_PORT || 3478) || 3478));
const TURN_TTL_SECONDS = Math.max(600, Math.min(86400, Number(process.env.TURN_TTL_SECONDS || 43200) || 43200));
const ICE_REFRESH_INTERVAL_MS = 6 * 60 * 60_000;

const UPDATE_REQUIRED_MESSAGE =
  "coe pecinha, versão incompatível atualiza essa porra ai";

const UPDATE_MANIFEST_URL =
  "https://raw.githubusercontent.com/sorryeeee/chat-dos-pecinha-download/main/release/version.json";

const UPDATE_CHECK_INTERVAL_MS = 10_000;

let updatePolicy = {
  currentVersion: APP_VERSION,
  minimumVersion: APP_VERSION,
  protocolVersion: PROTOCOL_VERSION,
  message: UPDATE_REQUIRED_MESSAGE,
  publishedAt: null,
  source: "host"
};

function iceServersForClient() {
  const iceServers = [
    { urls: "stun:stun.l.google.com:19302" }
  ];

  if (TURN_HOST && TURN_SECRET) {
    const expiresAt = Math.floor(Date.now() / 1000) + TURN_TTL_SECONDS;
    const username = `${expiresAt}:pecinha`;
    const credential = crypto
      .createHmac("sha1", TURN_SECRET)
      .update(username)
      .digest("base64");

    iceServers.push({
      urls: [
        `turn:${TURN_HOST}:${TURN_PORT}?transport=udp`,
        `turn:${TURN_HOST}:${TURN_PORT}?transport=tcp`
      ],
      username,
      credential
    });
  }

  return iceServers;
}

const AUTH_FILE = path.join(__dirname, "profile-auth.json");

function loadAuthDatabase() {
  const raw = fs.readFileSync(AUTH_FILE, "utf8");
  const parsed = JSON.parse(raw);
  if (!parsed || parsed.algorithm !== "scrypt" || !parsed.profiles) {
    throw new Error("profile-auth.json invalido.");
  }
  return parsed;
}

const AUTH_DB = loadAuthDatabase();

// The auth database is the source of truth for the player list.
// This means an account deleted by the admin stays deleted even
// after the HOST/server restarts.
const PLAYERS = Object.keys(AUTH_DB.profiles || {});


const clientVersions = Object.fromEntries(
  PLAYERS.map(player => [
    player,
    {
      appVersion: "",
      protocolVersion: 0,
      compatible: false,
      online: false,
      updatedAt: null
    }
  ])
);

function versionParts(value) {
  const match = String(value || "").match(/\d+(?:\.\d+)*/);
  if (!match) return [];
  return match[0].split(".").map(part => Number.parseInt(part, 10) || 0);
}

function compareAppVersions(left, right) {
  const a = versionParts(left);
  const b = versionParts(right);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index += 1) {
    const av = a[index] || 0;
    const bv = b[index] || 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

function newestAppVersion(...values) {
  let newest = "";
  for (const value of values) {
    const clean = cleanClientVersion(value);
    if (!clean) continue;
    if (!newest || compareAppVersions(clean, newest) > 0) {
      newest = clean;
    }
  }
  return newest;
}

function cleanClientVersion(value) {
  return String(value || "").trim().slice(0, 80);
}

function cleanClientProtocol(value) {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) ? Math.max(0, Math.min(10000, parsed)) : 0;
}

function compatibilityForClient(appVersion, protocolVersion) {
  const cleanVersion = cleanClientVersion(appVersion);
  const cleanProtocol = cleanClientProtocol(protocolVersion);
  const versionTooOld = !cleanVersion || compareAppVersions(cleanVersion, updatePolicy.minimumVersion) < 0;
  const protocolTooOld = cleanProtocol < updatePolicy.protocolVersion;
  return {
    compatible: !versionTooOld && !protocolTooOld,
    versionTooOld,
    protocolTooOld
  };
}

function socketVersionInfo(socket) {
  const appVersion = cleanClientVersion(socket?.data?.clientAppVersion);
  const protocolVersion = cleanClientProtocol(socket?.data?.clientProtocolVersion);
  return { appVersion, protocolVersion, ...compatibilityForClient(appVersion, protocolVersion) };
}

function versionPolicyForSocket(socket) {
  const info = socketVersionInfo(socket);
  return {
    ...updatePolicy,
    clientVersion: info.appVersion,
    clientProtocolVersion: info.protocolVersion,
    updateRequired: !info.compatible,
    reason: info.versionTooOld ? "app_version" : info.protocolTooOld ? "protocol_version" : null
  };
}

function clientVersionsState() {
  return Object.fromEntries(PLAYERS.map(player => {
    const current = clientVersions[player] || {};
    return [player, {
      appVersion: cleanClientVersion(current.appVersion),
      protocolVersion: cleanClientProtocol(current.protocolVersion),
      compatible: current.compatible === true,
      online: socketsByPlayer.has(player),
      updatedAt: Number(current.updatedAt) || null
    }];
  }));
}

function isVersionAdminSocket(socket) {
  return (
    socket?.data?.authenticated === true &&
    String(socket?.data?.player || "")
      .toLocaleLowerCase("pt-BR") ===
      "sorrye"
  );
}

function emitClientVersions() {
  const payload =
    clientVersionsState();

  for (
    const socket of
    io.sockets.sockets.values()
  ) {
    if (
      isVersionAdminSocket(socket)
    ) {
      socket.emit(
        "client-versions",
        payload
      );
    }
  }
}

function scheduleIncompatibleClientDisconnect(socket, policy) {
  if (!policy?.updateRequired || socket?.disconnected) return;
  if (socket.data.versionKickTimer) return;

  socket.data.versionKickTimer = setTimeout(() => {
    socket.data.versionKickTimer = null;
    if (socket.disconnected) return;

    const latestPolicy = versionPolicyForSocket(socket);
    if (!latestPolicy.updateRequired) return;

    // Keep the update gate visible long enough for clients that already
    // understand version-policy/force-update, then hard-block the session.
    socket.disconnect(true);
  }, 2500);
}

function emitVersionPolicyToSocket(socket, { enforce = false } = {}) {
  const policy = versionPolicyForSocket(socket);
  socket.emit("version-policy", policy);

  if (policy.updateRequired) {
    socket.emit("force-update", policy);
    if (enforce) {
      scheduleIncompatibleClientDisconnect(socket, policy);
    }
  } else if (socket.data.versionKickTimer) {
    clearTimeout(socket.data.versionKickTimer);
    socket.data.versionKickTimer = null;
  }

  return policy;
}

function emitVersionPolicyToAll({ enforce = false } = {}) {
  for (const socket of io.sockets.sockets.values()) {
    emitVersionPolicyToSocket(socket, { enforce });
  }
}

function updateSocketVersion(socket, payload = {}) {
  socket.data.clientAppVersion = cleanClientVersion(payload.appVersion);
  socket.data.clientProtocolVersion = cleanClientProtocol(payload.protocolVersion);
  const player = socket.data.player;
  if (player && PLAYERS.includes(player)) {
    const info = socketVersionInfo(socket);
    clientVersions[player] = {
      appVersion: info.appVersion,
      protocolVersion: info.protocolVersion,
      compatible: info.compatible,
      online: true,
      updatedAt: Date.now()
    };
    emitClientVersions();
  }
  emitVersionPolicyToSocket(socket, { enforce: true });
}

function rejectIfUpdateRequired(socket, resultEvent = "auth-result") {
  const policy = versionPolicyForSocket(socket);
  if (!policy.updateRequired) return false;
  socket.emit("version-policy", policy);
  socket.emit(resultEvent, {
    ok: false,
    reason: "update_required",
    error: UPDATE_REQUIRED_MESSAGE,
    requiredVersion: policy.currentVersion
  });
  return true;
}

async function refreshUpdatePolicy() {
  try {
    const response = await fetch(`${UPDATE_MANIFEST_URL}?x=${Date.now()}`, {
      headers: { "Cache-Control": "no-cache" },
      signal: AbortSignal.timeout(7000)
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const manifest = await response.json();
    const manifestCurrentVersion = cleanClientVersion(manifest?.currentVersion);
    const manifestMinimumVersion = cleanClientVersion(
      manifest?.minimumVersion || manifestCurrentVersion
    );
    const manifestProtocol = cleanClientProtocol(manifest?.protocolVersion);
    if (!manifestCurrentVersion || !manifestMinimumVersion || !manifestProtocol) {
      throw new Error("manifesto de versão inválido");
    }

    // The installed HOST is an immutable compatibility floor. A stale
    // version.json must NEVER downgrade the version/protocol requirement.
    // We also keep updates strict: the newest version known by HOST/Git is
    // the minimum accepted version.
    const currentVersion = newestAppVersion(
      APP_VERSION,
      manifestCurrentVersion
    );
    const minimumVersion = currentVersion;
    const protocolVersion = Math.max(
      PROTOCOL_VERSION,
      manifestProtocol
    );
    const manifestIsStale =
      compareAppVersions(manifestCurrentVersion, APP_VERSION) < 0 ||
      manifestProtocol < PROTOCOL_VERSION;

    const nextPolicy = {
      currentVersion,
      minimumVersion,
      protocolVersion,
      message: String(manifest?.message || UPDATE_REQUIRED_MESSAGE).trim().slice(0,180),
      publishedAt: String(manifest?.publishedAt || "").trim().slice(0,64) || null,
      source: manifestIsStale ? "host-floor" : "github"
    };
    const changed = JSON.stringify(updatePolicy) !== JSON.stringify(nextPolicy);
    updatePolicy = nextPolicy;
    if (changed) {
      for (const player of PLAYERS) {
        const current = clientVersions[player];
        if (!current) continue;
        current.compatible = compatibilityForClient(current.appVersion, current.protocolVersion).compatible;
      }
      emitVersionPolicyToAll({ enforce: true });
      emitClientVersions();
      console.log("Política de versão atualizada:", updatePolicy.currentVersion);
    } else {
      // Even without a policy change, re-enforce it against clients that
      // connected while a previous check was in progress.
      emitVersionPolicyToAll({ enforce: true });
    }

    if (manifestIsStale) {
      console.warn(
        "version.json está atrás do HOST; mantendo piso local:",
        APP_VERSION
      );
    }
  } catch (error) {
    console.warn("Não foi possível consultar version.json:", error?.message || error);
  }
}

function saveAuthDatabase() {
  const tempFile = `${AUTH_FILE}.tmp`;

  fs.writeFileSync(
    tempFile,
    JSON.stringify(AUTH_DB, null, 2),
    "utf8"
  );

  fs.renameSync(tempFile, AUTH_FILE);
}

function normalizedPlayerName(value) {
  return String(value || "")
    .trim()
    .replace(/\s+/g, " ");
}

function playerNameKey(value) {
  return normalizedPlayerName(value).toLocaleLowerCase("pt-BR");
}

function playerExistsCaseInsensitive(value) {
  const key = playerNameKey(value);

  return PLAYERS.some(
    player => playerNameKey(player) === key
  );
}

function validNewPlayerName(value) {
  const name = normalizedPlayerName(value);

  if (name.length < 3 || name.length > 24) {
    return false;
  }

  // Letters/numbers from any language plus space, _, -, .
  return /^[\p{L}\p{N} _.-]+$/u.test(name);
}

function validNewPassword(value) {
  const password = String(value || "");

  return password.length >= 8 && password.length <= 128;
}

const SCRYPT_PARAMS = Object.freeze({
  N: 32768,
  r: 8,
  p: 1,
  maxmem: 128 * 1024 * 1024
});

function createPasswordEntry(password) {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16);

    crypto.scrypt(
      String(password),
      salt,
      64,
      SCRYPT_PARAMS,
      (error, derived) => {
        if (error) {
          reject(error);
          return;
        }

        resolve({
          salt: salt.toString("hex"),
          hash: derived.toString("hex"),
          params: {
            N: SCRYPT_PARAMS.N,
            r: SCRYPT_PARAMS.r,
            p: SCRYPT_PARAMS.p
          }
        });
      }
    );
  });
}

function scryptOptionsForProfile(profile) {
  const params = profile?.params;

  if (
    params &&
    Number(params.N) >= 16384 &&
    Number(params.N) <= 131072 &&
    (
      Number(params.N) &
      (Number(params.N) - 1)
    ) === 0 &&
    Number(params.r) > 0 &&
    Number(params.r) <= 32 &&
    Number(params.p) > 0 &&
    Number(params.p) <= 16
  ) {
    return {
      N: Number(params.N),
      r: Number(params.r),
      p: Number(params.p),
      maxmem: 128 * 1024 * 1024
    };
  }

  // Legacy profiles used Node's defaults. They are upgraded
  // transparently after the next successful password login.
  return undefined;
}

function verifyPassword(player, password) {
  return new Promise((resolve) => {
    const profile = AUTH_DB.profiles[player];

    if (
      !profile ||
      typeof password !== "string" ||
      password.length > 128
    ) {
      resolve(false);
      return;
    }

    let salt;
    let expected;

    try {
      salt = Buffer.from(profile.salt, "hex");
      expected = Buffer.from(profile.hash, "hex");
    } catch {
      resolve(false);
      return;
    }

    if (
      salt.length < 16 ||
      expected.length !== 64
    ) {
      resolve(false);
      return;
    }

    const options =
      scryptOptionsForProfile(profile);

    const callback = async (error, derived) => {
      if (
        error ||
        derived.length !== expected.length ||
        !crypto.timingSafeEqual(derived, expected)
      ) {
        resolve(false);
        return;
      }

      if (!profile.params) {
        try {
          AUTH_DB.profiles[player] =
            await createPasswordEntry(password);

          saveAuthDatabase();

          console.log(
            `Hash scrypt atualizado para: ${player}`
          );
        } catch (upgradeError) {
          console.warn(
            "Falha ao atualizar hash scrypt legado:",
            upgradeError.message
          );
        }
      }

      resolve(true);
    };

    if (options) {
      crypto.scrypt(
        password,
        salt,
        expected.length,
        options,
        callback
      );
    } else {
      crypto.scrypt(
        password,
        salt,
        expected.length,
        callback
      );
    }
  });
}


const ACTIVITY_FILE = path.join(__dirname, "profile-activity.json");

function emptyActivityDatabase() {
  return {
    version: 1,
    lastSeen: Object.fromEntries(
      PLAYERS.map(player => [player, null])
    )
  };
}

function loadActivityDatabase() {
  try {
    if (!fs.existsSync(ACTIVITY_FILE)) {
      return emptyActivityDatabase();
    }

    const parsed = JSON.parse(
      fs.readFileSync(ACTIVITY_FILE, "utf8")
    );

    if (!parsed || !parsed.lastSeen) {
      return emptyActivityDatabase();
    }

    for (const player of PLAYERS) {
      const value = Number(parsed.lastSeen[player]);

      parsed.lastSeen[player] =
        Number.isFinite(value) && value > 0
          ? value
          : null;
    }

    return parsed;
  } catch (error) {
    console.error(
      "Falha ao carregar profile-activity.json:",
      error
    );

    return emptyActivityDatabase();
  }
}

let ACTIVITY_DB = loadActivityDatabase();

function saveActivityDatabase() {
  try {
    const tempFile = `${ACTIVITY_FILE}.tmp`;

    fs.writeFileSync(
      tempFile,
      JSON.stringify(ACTIVITY_DB, null, 2),
      "utf8"
    );

    fs.renameSync(tempFile, ACTIVITY_FILE);
  } catch (error) {
    console.error(
      "Falha ao salvar profile-activity.json:",
      error
    );
  }
}

function lastSeenState() {
  return Object.fromEntries(
    PLAYERS.map(player => [
      player,
      ACTIVITY_DB.lastSeen[player] || null
    ])
  );
}

function touchLastSeen(player, when = Date.now()) {
  if (!PLAYERS.includes(player)) return;

  ACTIVITY_DB.lastSeen[player] = Number(when);
  saveActivityDatabase();
}

function emitActivity() {
  emitAuthenticated("activity", lastSeenState());
}

const authAttempts = new Map();
const registrationAttempts = new Map();

function normalizeRemoteAddress(value) {
  let ip = String(value || "").trim();

  if (ip.startsWith("::ffff:")) {
    ip = ip.slice(7);
  }

  if (ip === "::1") {
    return "127.0.0.1";
  }

  return ip;
}

function directRequestIp(req) {
  return normalizeRemoteAddress(req?.socket?.remoteAddress);
}

function forwardedClientIp(req) {
  if (!TRUST_PROXY || directRequestIp(req) !== "127.0.0.1") {
    return "";
  }

  const value = String(req?.headers?.["x-forwarded-for"] || "");
  const first = value.split(",")[0]?.trim() || "";
  return normalizeRemoteAddress(first);
}

function remoteClientIp(socket) {
  return (
    forwardedClientIp(socket?.request) ||
    normalizeRemoteAddress(
      socket?.handshake?.address ||
      socket?.conn?.remoteAddress ||
      socket?.request?.socket?.remoteAddress
    )
  );
}

function consumeRateLimit(
  store,
  key,
  maxAttempts,
  windowMs
) {
  const now = Date.now();
  let item = store.get(key);

  if (
    !item ||
    now - item.startedAt >= windowMs
  ) {
    item = {
      startedAt: now,
      count: 0
    };

    store.set(key, item);
  }

  if (item.count >= maxAttempts) {
    return false;
  }

  item.count += 1;
  return true;
}

function clearRateLimit(store, key) {
  store.delete(key);
}

function authAttemptKey(socket, player) {
  return (
    remoteClientIp(socket) +
    "|" +
    playerNameKey(player)
  );
}

function canAttemptAuth(socket, player) {
  return consumeRateLimit(
    authAttempts,
    authAttemptKey(socket, player),
    8,
    60_000
  );
}

function clearAuthAttempts(socket, player) {
  clearRateLimit(
    authAttempts,
    authAttemptKey(socket, player)
  );
}

function canAttemptRegistration(socket) {
  return consumeRateLimit(
    registrationAttempts,
    remoteClientIp(socket),
    4,
    60_000
  );
}

function clearRegistrationAttempts(socket) {
  clearRateLimit(
    registrationAttempts,
    remoteClientIp(socket)
  );
}

function allowSocketEvent(
  socket,
  key,
  maxAttempts,
  windowMs
) {
  if (!socket.data.rateLimits) {
    socket.data.rateLimits = new Map();
  }

  return consumeRateLimit(
    socket.data.rateLimits,
    key,
    maxAttempts,
    windowMs
  );
}

function validSessionDescription(
  value,
  allowedTypes
) {
  return !!(
    value &&
    typeof value === "object" &&
    allowedTypes.includes(value.type) &&
    typeof value.sdp === "string" &&
    value.sdp.length > 0 &&
    value.sdp.length <= 65536
  );
}

const rateLimitCleanupTimer =
  setInterval(
    () => {
      const cutoff =
        Date.now() - 5 * 60_000;

      for (const store of [
        authAttempts,
        registrationAttempts
      ]) {
        for (
          const [key, item] of
          store.entries()
        ) {
          if (
            !item ||
            item.startedAt < cutoff
          ) {
            store.delete(key);
          }
        }
      }
    },
    5 * 60_000
  );

rateLimitCleanupTimer.unref?.();

function normalizedIceCandidate(value) {
  if (
    !value ||
    typeof value !== "object" ||
    typeof value.candidate !== "string" ||
    value.candidate.length < 1 ||
    value.candidate.length > 4096
  ) {
    return null;
  }

  const result = {
    candidate: value.candidate
  };

  if (
    value.sdpMid === null ||
    typeof value.sdpMid === "string"
  ) {
    if (
      typeof value.sdpMid === "string" &&
      value.sdpMid.length > 256
    ) {
      return null;
    }

    result.sdpMid = value.sdpMid;
  }

  if (
    value.sdpMLineIndex === null ||
    Number.isInteger(value.sdpMLineIndex)
  ) {
    if (
      Number.isInteger(value.sdpMLineIndex) &&
      (
        value.sdpMLineIndex < 0 ||
        value.sdpMLineIndex > 1024
      )
    ) {
      return null;
    }

    result.sdpMLineIndex =
      value.sdpMLineIndex;
  }

  if (
    value.usernameFragment === null ||
    typeof value.usernameFragment === "string"
  ) {
    if (
      typeof value.usernameFragment === "string" &&
      value.usernameFragment.length > 256
    ) {
      return null;
    }

    result.usernameFragment =
      value.usernameFragment;
  }

  return result;
}


const SESSION_FILE = path.join(__dirname, "profile-sessions.json");
const SESSION_TTL_MS = 90 * 24 * 60 * 60 * 1000;
const MAX_SESSIONS_PER_PROFILE = 8;

function emptySessionDatabase() {
  return {
    version: 1,
    profiles: Object.fromEntries(PLAYERS.map(player => [player, []]))
  };
}

function loadSessionDatabase() {
  try {
    if (!fs.existsSync(SESSION_FILE)) {
      return emptySessionDatabase();
    }

    const parsed = JSON.parse(fs.readFileSync(SESSION_FILE, "utf8"));

    if (!parsed || !parsed.profiles) {
      return emptySessionDatabase();
    }

    for (const player of PLAYERS) {
      if (!Array.isArray(parsed.profiles[player])) {
        parsed.profiles[player] = [];
      }
    }

    return parsed;
  } catch (error) {
    console.error("Falha ao carregar profile-sessions.json:", error);
    return emptySessionDatabase();
  }
}

let SESSION_DB = loadSessionDatabase();

function saveSessionDatabase() {
  try {
    const tempFile = `${SESSION_FILE}.tmp`;

    fs.writeFileSync(
      tempFile,
      JSON.stringify(SESSION_DB, null, 2),
      "utf8"
    );

    fs.renameSync(tempFile, SESSION_FILE);
  } catch (error) {
    console.error("Falha ao salvar profile-sessions.json:", error);
  }
}

function tokenHash(token) {
  return crypto
    .createHash("sha256")
    .update(String(token || ""), "utf8")
    .digest("hex");
}

function timingSafeHexEqual(a, b) {
  if (
    typeof a !== "string" ||
    typeof b !== "string" ||
    a.length !== b.length
  ) {
    return false;
  }

  try {
    return crypto.timingSafeEqual(
      Buffer.from(a, "hex"),
      Buffer.from(b, "hex")
    );
  } catch {
    return false;
  }
}

function pruneSessions(player) {
  const now = Date.now();

  SESSION_DB.profiles[player] = (
    SESSION_DB.profiles[player] || []
  )
    .filter(session =>
      session &&
      typeof session.hash === "string" &&
      Number(session.expiresAt) > now
    )
    .slice(-MAX_SESSIONS_PER_PROFILE);
}

function issueRememberToken(player) {
  pruneSessions(player);

  const token = crypto.randomBytes(32).toString("base64url");
  const now = Date.now();

  SESSION_DB.profiles[player].push({
    hash: tokenHash(token),
    createdAt: now,
    lastUsedAt: now,
    expiresAt: now + SESSION_TTL_MS
  });

  SESSION_DB.profiles[player] =
    SESSION_DB.profiles[player].slice(-MAX_SESSIONS_PER_PROFILE);

  saveSessionDatabase();

  return token;
}

function verifyRememberToken(player, token) {
  if (
    !PLAYERS.includes(player) ||
    typeof token !== "string" ||
    token.length < 32
  ) {
    return false;
  }

  pruneSessions(player);

  const candidateHash = tokenHash(token);
  const sessions = SESSION_DB.profiles[player] || [];

  const found = sessions.find(session =>
    timingSafeHexEqual(session.hash, candidateHash)
  );

  if (!found) {
    saveSessionDatabase();
    return false;
  }

  found.lastUsedAt = Date.now();
  found.expiresAt = Date.now() + SESSION_TTL_MS;
  saveSessionDatabase();

  return true;
}



const AUTH_ROOM = "authenticated";

function isAllowedPrivateAddress(value) {
  const ip = normalizeRemoteAddress(value);

  if (
    ip === "127.0.0.1" ||
    ip === "localhost"
  ) {
    return true;
  }

  const match =
    /^100\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(ip);

  if (!match) {
    return false;
  }

  const second = Number(match[1]);
  const third = Number(match[2]);
  const fourth = Number(match[3]);

  return (
    second >= 64 &&
    second <= 127 &&
    third >= 0 &&
    third <= 255 &&
    fourth >= 0 &&
    fourth <= 255
  );
}

function requestRemoteAddress(req) {
  return forwardedClientIp(req) || directRequestIp(req);
}

function isAllowedTransportRequest(req) {
  // In Cloud mode Caddy is the only process that can reach the Node listener.
  // In legacy mode keep localhost/Tailscale access working exactly as before.
  return isAllowedPrivateAddress(directRequestIp(req));
}

function isAllowedRendererOrigin(req) {
  const origin = String(req?.headers?.origin || "").trim().toLowerCase();
  return (
    !origin ||
    origin === "null" ||
    origin === "file://" ||
    origin.startsWith("file:")
  );
}

function writeJsonResponse(
  res,
  statusCode,
  payload
) {
  const body =
    JSON.stringify(payload);

  res.writeHead(
    statusCode,
    {
      "Content-Type":
        "application/json; charset=utf-8",
      "Content-Length":
        Buffer.byteLength(body),
      "Cache-Control":
        "no-store",
      "X-Content-Type-Options":
        "nosniff",
      "Cross-Origin-Resource-Policy":
        "same-origin"
    }
  );

  res.end(body);
}

const server = http.createServer(
  (req, res) => {
    const remote =
      requestRemoteAddress(req);

    if (!isAllowedTransportRequest(req)) {
      writeJsonResponse(
        res,
        403,
        {
          ok: false,
          error: "forbidden"
        }
      );
      return;
    }

    const method =
      String(req.method || "GET")
        .toUpperCase();

    if (
      method !== "GET" &&
      method !== "HEAD"
    ) {
      writeJsonResponse(
        res,
        405,
        {
          ok: false,
          error: "method_not_allowed"
        }
      );
      return;
    }

    let pathname = "/";

    try {
      pathname =
        new URL(
          req.url || "/",
          "http://arena.local"
        ).pathname;
    } catch {}

    if (pathname === "/health") {
      writeJsonResponse(
        res,
        200,
        {
          ok: true,
          appVersion: APP_VERSION,
          protocolVersion: PROTOCOL_VERSION,
          currentVersion: updatePolicy.currentVersion,
          minimumVersion: updatePolicy.minimumVersion
        }
      );
      return;
    }

    if (pathname === "/") {
      writeJsonResponse(
        res,
        200,
        {
          ok: true,
          service: "Chat dos Pecinha Server"
        }
      );
      return;
    }

    writeJsonResponse(
      res,
      404,
      {
        ok: false,
        error: "not_found"
      }
    );
  }
);

server.requestTimeout = 10_000;
server.headersTimeout = 12_000;
server.keepAliveTimeout = 5_000;
server.maxHeadersCount = 64;

const io = new Server(
  server,
  {
    transports: ["websocket"],
    allowUpgrades: false,
    maxHttpBufferSize: 256 * 1024,
    pingTimeout: 20000,
    pingInterval: 10000,

    allowRequest: (req, callback) => {
      const remote =
        requestRemoteAddress(req);

      const allowed =
        isAllowedTransportRequest(req) &&
        isAllowedRendererOrigin(req);

      if (!allowed) {
        console.warn(
          "Socket.IO handshake bloqueado de:",
          remote || "(endereço desconhecido)"
        );
      }

      // The app renderer is loaded from file://, whose serialized
      // Origin can be opaque/null depending on Chromium context.
      // Cloud requests are accepted only from the local Caddy proxy and
      // legacy requests only from localhost/Tailscale. Browser HTTP origins
      // are rejected; authentication is still mandatory before squad state.
      callback(
        null,
        allowed
      );
    }
  }
);

function emitAuthenticated(
  event,
  payload
) {
  io.to(AUTH_ROOM).emit(
    event,
    payload
  );
}

function fullState(socket) {
  return {
    appVersion: APP_VERSION,
    protocolVersion: PROTOCOL_VERSION,
    players: [...PLAYERS],
    presence,
    online: onlineState(),
    computerPresence:
      computerPresenceState(),
    lastSeen: lastSeenState(),
    sharing,
    voiceMembers:
      voiceMembersState(),
    clientVersions:
      isVersionAdminSocket(socket)
        ? clientVersionsState()
        : {},
    versionPolicy:
      updatePolicy,
    iceServers: iceServersForClient(),
    chatHistory
  };
}

const PRESENCE_FILE = path.join(
  __dirname,
  "profile-presence.json"
);

const PRESENCE_STATUSES = new Set([
  "unset",
  "playing",
  "not_now",
  "not_today",
  "later",
  "custom"
]);

const PLAYER_ACTIVITY_STATES = new Set([
  "unset",
  "online",
  "away",
  "giving_butt",
  "delivery",
  "ana",
  "poop"
]);

const TAKA_ONLY_ACTIVITY_STATES = new Set([
  "delivery",
  "ana",
  "poop"
]);

function emptyPresenceValue() {
  return {
    status: "unset",
    targetAt: null,
    customText: "",
    activity: "unset"
  };
}

function normalizeStoredPresence(value) {
  const next = emptyPresenceValue();

  if (!value || typeof value !== "object") {
    return next;
  }

  if (PRESENCE_STATUSES.has(value.status)) {
    next.status = value.status;
  }

  const target = Number(value.targetAt);

  next.targetAt =
    Number.isFinite(target) && target > 0
      ? target
      : null;

  next.customText =
    typeof value.customText === "string"
      ? value.customText.trim().slice(0, 80)
      : "";

  if (PLAYER_ACTIVITY_STATES.has(value.activity)) {
    next.activity = value.activity;
  }

  if (
    next.status !== "later"
  ) {
    next.targetAt = null;
  }

  if (
    next.status !== "custom"
  ) {
    next.customText = "";
  }

  return next;
}

function emptyPresenceDatabase() {
  return Object.fromEntries(
    PLAYERS.map(player => [
      player,
      emptyPresenceValue()
    ])
  );
}

function loadPresenceDatabase() {
  try {
    if (!fs.existsSync(PRESENCE_FILE)) {
      return emptyPresenceDatabase();
    }

    const parsed = JSON.parse(
      fs.readFileSync(PRESENCE_FILE, "utf8")
    );

    const profiles =
      parsed && parsed.profiles &&
      typeof parsed.profiles === "object"
        ? parsed.profiles
        : {};

    return Object.fromEntries(
      PLAYERS.map(player => [
        player,
        normalizeStoredPresence(
          profiles[player]
        )
      ])
    );
  } catch (error) {
    console.error(
      "Falha ao carregar profile-presence.json:",
      error
    );

    return emptyPresenceDatabase();
  }
}

const presence = loadPresenceDatabase();

function savePresenceDatabase() {
  try {
    const tempFile = `${PRESENCE_FILE}.tmp`;

    fs.writeFileSync(
      tempFile,
      JSON.stringify(
        {
          version: 1,
          profiles: presence
        },
        null,
        2
      ),
      "utf8"
    );

    fs.renameSync(tempFile, PRESENCE_FILE);
  } catch (error) {
    console.error(
      "Falha ao salvar profile-presence.json:",
      error
    );
  }
}
const sharing = Object.fromEntries(PLAYERS.map(p => [p, false]));
const socketsByPlayer = new Map();
const computerPresence = Object.fromEntries(
  PLAYERS.map(player => [
    player,
    {
      state: "offline",
      idleSeconds: 0,
      updatedAt: null
    }
  ])
);
const watchersBySharer = new Map(PLAYERS.map(p => [p, new Set()]));
const chatHistory = [];

// Ephemeral voice room state. Voice membership intentionally does
// not survive app/server restarts.
const voiceMembers = new Map();

function voiceMembersState() {
  return Object.fromEntries(
    [...voiceMembers.entries()].map(
      ([player, state]) => [
        player,
        {
          muted: !!state?.muted,
          deafened: !!state?.deafened
        }
      ]
    )
  );
}

function emitVoiceMembers() {
  emitAuthenticated(
    "voice-members",
    voiceMembersState()
  );
}

function leaveVoiceRoom(player) {
  if (!player || !voiceMembers.has(player)) {
    return;
  }

  voiceMembers.delete(player);

  emitAuthenticated(
    "voice-peer-left",
    {
      player
    }
  );

  emitVoiceMembers();
}


function ensurePlayerRuntimeState(player) {
  if (!PLAYERS.includes(player)) {
    PLAYERS.push(player);
  }

  if (!presence[player]) {
    presence[player] = emptyPresenceValue();
  }

  if (typeof sharing[player] !== "boolean") {
    sharing[player] = false;
  }

  if (!watchersBySharer.has(player)) {
    watchersBySharer.set(player, new Set());
  }

  if (!Object.prototype.hasOwnProperty.call(
    ACTIVITY_DB.lastSeen,
    player
  )) {
    ACTIVITY_DB.lastSeen[player] = null;
  }

  if (!Object.prototype.hasOwnProperty.call(
    computerPresence,
    player
  )) {
    computerPresence[player] = {
      state: "offline",
      idleSeconds: 0,
      updatedAt: null
    };
  }

  if (!Array.isArray(SESSION_DB.profiles[player])) {
    SESSION_DB.profiles[player] = [];
  }

  if (!clientVersions[player]) {
    clientVersions[player] = {
      appVersion: "",
      protocolVersion: 0,
      compatible: false,
      online: false,
      updatedAt: null
    };
  }
}

function emitPlayers() {
  io.emit("players", [...PLAYERS]);
}

function onlineState() {
  return Object.fromEntries(PLAYERS.map(p => [p, socketsByPlayer.has(p)]));
}

function computerPresenceState() {
  return Object.fromEntries(
    PLAYERS.map(player => {
      const isOnline =
        socketsByPlayer.has(player);

      const current =
        computerPresence[player] || {};

      return [
        player,
        {
          state:
            isOnline
              ? (
                  current.state === "away"
                    ? "away"
                    : "online"
                )
              : "offline",
          idleSeconds:
            isOnline
              ? Math.max(
                  0,
                  Math.min(
                    7 * 24 * 60 * 60,
                    Number(
                      current.idleSeconds
                    ) || 0
                  )
                )
              : 0,
          updatedAt:
            Number(
              current.updatedAt
            ) || null
        }
      ];
    })
  );
}

function emitComputerPresence() {
  emitAuthenticated(
    "computer-presence",
    computerPresenceState()
  );
}


function socketFor(player) {
  const id = socketsByPlayer.get(player);
  return id || null;
}

function emitOnline() {
  emitAuthenticated("online", onlineState());
}

function stopShare(player) {
  if (!PLAYERS.includes(player)) return;

  sharing[player] = false;

  const viewers = watchersBySharer.get(player) || new Set();
  for (const viewer of viewers) {
    const viewerSocket = socketFor(viewer);
    if (viewerSocket) {
      io.to(viewerSocket).emit("screen-share-ended", { player });
    }
  }
  viewers.clear();

  emitAuthenticated("screen-sharing", sharing);
}

function removeViewerEverywhere(viewer) {
  for (const sharer of PLAYERS) {
    const viewers = watchersBySharer.get(sharer);
    if (viewers && viewers.delete(viewer)) {
      const sharerSocket = socketFor(sharer);
      if (sharerSocket) {
        io.to(sharerSocket).emit("screen-viewer-left", { viewer });
      }
    }
  }
}


function deletePlayerCompletely(player) {
  if (!PLAYERS.includes(player)) {
    return false;
  }

  leaveVoiceRoom(player);

  // `sorrye` is the permanent administrator account.
  if (playerNameKey(player) === "sorrye") {
    return false;
  }

  // End anything involving the account before removing it
  // from PLAYERS, because the share helpers validate PLAYERS.
  if (sharing[player]) {
    stopShare(player);
  }

  removeViewerEverywhere(player);

  const targetSocketId = socketsByPlayer.get(player);
  const targetSocket = targetSocketId
    ? io.sockets.sockets.get(targetSocketId)
    : null;

  socketsByPlayer.delete(player);

  // Force the currently-open app for that account back to
  // the login screen without dropping the network connection.
  if (targetSocket) {
    targetSocket.data.authenticated = false;
    targetSocket.data.player = null;
    targetSocket.leave(AUTH_ROOM);

    targetSocket.emit("user-deleted", {
      player,
      message:
        `O usuário ${player} foi excluído pelo administrador.`
    });
  }

  // Remove the user from all live WebRTC viewer sets.
  for (const viewers of watchersBySharer.values()) {
    viewers.delete(player);
  }

  watchersBySharer.delete(player);

  // Remove all persistent and runtime account data.
  delete AUTH_DB.profiles[player];
  delete SESSION_DB.profiles[player];
  delete ACTIVITY_DB.lastSeen[player];
  delete computerPresence[player];
  delete presence[player];
  delete sharing[player];
  delete clientVersions[player];

  // Chat is memory-only, but remove the deleted user's messages
  // from the current server history too.
  for (let i = chatHistory.length - 1; i >= 0; i -= 1) {
    if (chatHistory[i]?.from === player) {
      chatHistory.splice(i, 1);
    }
  }

  const index = PLAYERS.indexOf(player);
  if (index >= 0) {
    PLAYERS.splice(index, 1);
  }

  saveAuthDatabase();
  saveSessionDatabase();
  saveActivityDatabase();
  savePresenceDatabase();

  emitPlayers();
  emitAuthenticated("presence", presence);
  emitAuthenticated("screen-sharing", sharing);
  emitOnline();
  emitComputerPresence();
  emitClientVersions();
  emitActivity();

  return true;
}




function authenticateSocketAs(socket, player, extraResult = {}) {
  const oldPlayer = socket.data.player;

  if (
    oldPlayer &&
    oldPlayer !== player &&
    socketsByPlayer.get(oldPlayer) === socket.id
  ) {
    socketsByPlayer.delete(oldPlayer);
    computerPresence[oldPlayer] = {
      state: "offline",
      idleSeconds: 0,
      updatedAt: Date.now()
    };
    touchLastSeen(oldPlayer);
    leaveVoiceRoom(oldPlayer);

    if (sharing[oldPlayer]) {
      stopShare(oldPlayer);
    }

    removeViewerEverywhere(oldPlayer);
  }

  const oldSocketId = socketsByPlayer.get(player);

  if (oldSocketId && oldSocketId !== socket.id) {
    const oldSocket = io.sockets.sockets.get(oldSocketId);

    if (oldSocket) {
      oldSocket.emit("session-replaced", {
        player,
        message: `${player} entrou em outro PC.`
      });

      oldSocket.disconnect(true);
    }
  }

  socket.data.player = player;
  socket.data.authenticated = true;
  socketsByPlayer.set(player, socket.id);

  const clientInfo = socketVersionInfo(socket);
  clientVersions[player] = {
    appVersion: clientInfo.appVersion,
    protocolVersion: clientInfo.protocolVersion,
    compatible: clientInfo.compatible,
    online: true,
    updatedAt: Date.now()
  };

  computerPresence[player] = {
    state: "online",
    idleSeconds: 0,
    updatedAt: Date.now()
  };

  socket.join(AUTH_ROOM);
  touchLastSeen(player);

  socket.emit("auth-result", {
    ok: true,
    player,
    ...extraResult
  });

  socket.emit(
    "state",
    fullState(socket)
  );

  emitAuthenticated("presence", presence);
  emitOnline();
  emitComputerPresence();
  emitClientVersions();
  emitActivity();
}

io.on("connection", (socket) => {
  // A connection itself is a reason to refresh Git immediately. This avoids
  // the old race where a client could open during the polling window.
  void refreshUpdatePolicy();

  socket.data.authenticated = false;
  socket.data.player = null;
  socket.data.rateLimits = new Map();
  socket.data.versionKickTimer = null;

  updateSocketVersion(socket, socket.handshake?.auth || {});

  socket.emit("state", {
    appVersion: APP_VERSION,
    protocolVersion: PROTOCOL_VERSION,
    players: [...PLAYERS],
    versionPolicy: updatePolicy
  });

  emitVersionPolicyToSocket(socket, { enforce: true });

  socket.on("client-version", payload => {
    updateSocketVersion(socket, payload || {});
  });

  socket.on("register", () => {
    if (rejectIfUpdateRequired(socket, "auth-result")) return;
    socket.emit("auth-result", { ok: false, error: "Este cliente precisa autenticar o perfil." });
  });

  socket.on(
    "create-user",
    async ({ username, password }) => {
      if (rejectIfUpdateRequired(socket, "create-user-result")) return;
      if (!canAttemptRegistration(socket)) {
        socket.emit("create-user-result", {
          ok: false,
          error:
            "Muitas tentativas de criação. Aguarde 1 minuto."
        });
        return;
      }

      const player = normalizedPlayerName(username);
      const cleanPassword = String(password || "");

      if (PLAYERS.length >= 50) {
        socket.emit("create-user-result", {
          ok: false,
          error:
            "Limite de usuários do Chat dos Pecinha atingido."
        });
        return;
      }

      if (!validNewPlayerName(player)) {
        socket.emit("create-user-result", {
          ok: false,
          error:
            "Nome precisa ter 3–24 caracteres e usar apenas letras, números, espaço, _, - ou ."
        });
        return;
      }

      if (playerExistsCaseInsensitive(player)) {
        socket.emit("create-user-result", {
          ok: false,
          error: "Esse usuário já existe."
        });
        return;
      }

      if (!validNewPassword(cleanPassword)) {
        socket.emit("create-user-result", {
          ok: false,
          error:
            "A senha precisa ter entre 8 e 128 caracteres."
        });
        return;
      }

      try {
        const passwordEntry =
          await createPasswordEntry(cleanPassword);

        // Re-check after async hashing to avoid two simultaneous
        // requests creating the same case-insensitive name.
        if (playerExistsCaseInsensitive(player)) {
          socket.emit("create-user-result", {
            ok: false,
            error: "Esse usuário já existe."
          });
          return;
        }

        AUTH_DB.profiles[player] = passwordEntry;
        ensurePlayerRuntimeState(player);

        saveAuthDatabase();
        saveActivityDatabase();
        saveSessionDatabase();
        savePresenceDatabase();

        emitPlayers();
        emitAuthenticated("presence", presence);
        emitAuthenticated("screen-sharing", sharing);
        emitOnline();
        emitActivity();

        const rememberToken =
          issueRememberToken(player);

        socket.emit("create-user-result", {
          ok: true,
          player
        });

        authenticateSocketAs(socket, player, {
          rememberToken,
          remembered: false,
          created: true
        });

        console.log(
          `Novo perfil criado: ${player}`
        );
      } catch (error) {
        console.error(
          "Falha ao criar perfil:",
          error
        );

        socket.emit("create-user-result", {
          ok: false,
          error:
            "Não foi possível criar o usuário."
        });
      }
    }
  );

  socket.on("auth-profile", async ({ player, password } = {}) => {
    if (rejectIfUpdateRequired(socket, "auth-result")) return;
    if (!PLAYERS.includes(player)) {
      socket.emit("auth-result", {
        ok: false,
        error: "Perfil inválido."
      });
      return;
    }

    if (!canAttemptAuth(socket, player)) {
      socket.emit("auth-result", {
        ok: false,
        error: "Muitas tentativas. Aguarde 1 minuto."
      });
      return;
    }

    const valid = await verifyPassword(
      player,
      String(password || "")
    );

    if (!valid) {
      socket.emit("auth-result", {
        ok: false,
        player,
        error: "Senha incorreta."
      });
      return;
    }

    clearAuthAttempts(socket, player);

    const rememberToken = issueRememberToken(player);

    authenticateSocketAs(socket, player, {
      rememberToken,
      remembered: false
    });
  });

  socket.on(
    "auth-token",
    ({ player, token } = {}) => {
      if (rejectIfUpdateRequired(socket, "auth-result")) return;
      if (
        !PLAYERS.includes(player) ||
        typeof token !== "string" ||
        token.length > 256
      ) {
      socket.emit("auth-result", {
        ok: false,
        reason: "invalid_token",
        error: "Login salvo inválido."
      });
      return;
    }

    const valid = verifyRememberToken(
      player,
      String(token || "")
    );

    if (!valid) {
      socket.emit("auth-result", {
        ok: false,
        player,
        reason: "invalid_token",
        error: "Login salvo expirou. Digite sua senha novamente."
      });
      return;
    }

    authenticateSocketAs(socket, player, {
      remembered: true
    });
  });

  socket.on(
    "change-password",
    async ({ player, oldPassword, newPassword } = {}) => {
      if (rejectIfUpdateRequired(socket, "change-password-result")) return;
      if (!PLAYERS.includes(player)) {
        socket.emit("change-password-result", {
          ok: false,
          error: "Perfil inválido."
        });
        return;
      }

      if (!canAttemptAuth(socket, player)) {
        socket.emit("change-password-result", {
          ok: false,
          error: "Muitas tentativas. Aguarde 1 minuto."
        });
        return;
      }

      const cleanOld = String(oldPassword || "");
      const cleanNew = String(newPassword || "");

      if (!validNewPassword(cleanNew)) {
        socket.emit("change-password-result", {
          ok: false,
          error:
            "A nova senha precisa ter entre 8 e 128 caracteres."
        });
        return;
      }

      const validOld = await verifyPassword(
        player,
        cleanOld
      );

      if (!validOld) {
        socket.emit("change-password-result", {
          ok: false,
          error: "Senha atual incorreta."
        });
        return;
      }

      if (cleanOld === cleanNew) {
        socket.emit("change-password-result", {
          ok: false,
          error:
            "A nova senha precisa ser diferente da senha atual."
        });
        return;
      }

      try {
        AUTH_DB.profiles[player] =
          await createPasswordEntry(cleanNew);

        saveAuthDatabase();

        // Password changes revoke all remembered tokens.
        SESSION_DB.profiles[player] = [];
        saveSessionDatabase();

        clearAuthAttempts(socket, player);

        const rememberToken =
          issueRememberToken(player);

        socket.emit("change-password-result", {
          ok: true,
          player
        });

        // Knowing the old password is sufficient to log in again.
        authenticateSocketAs(socket, player, {
          rememberToken,
          remembered: false,
          passwordChanged: true
        });

        console.log(
          `Senha alterada para o perfil: ${player}`
        );
      } catch (error) {
        console.error(
          "Falha ao alterar senha:",
          error
        );

        socket.emit("change-password-result", {
          ok: false,
          error:
            "Não foi possível alterar a senha."
        });
      }
    }
  );

  socket.on(
    "delete-user",
    ({ player } = {}) => {
      const requester =
        String(
          socket.data.player || ""
        );

      if (
        !allowSocketEvent(
          socket,
          "delete-user",
          10,
          60_000
        )
      ) {
        return;
      }

    if (
      !socket.data.authenticated ||
      requester.toLowerCase() !== "sorrye"
    ) {
      socket.emit("delete-user-result", {
        ok: false,
        error:
          "Apenas sorrye pode excluir usuários."
      });
      return;
    }

    const requestedKey = playerNameKey(player);

    const target = PLAYERS.find(
      candidate =>
        playerNameKey(candidate) === requestedKey
    );

    if (!target) {
      socket.emit("delete-user-result", {
        ok: false,
        error: "Usuário não encontrado."
      });
      return;
    }

    if (playerNameKey(target) === "sorrye") {
      socket.emit("delete-user-result", {
        ok: false,
        error:
          "A conta sorrye é a conta administrativa e não pode ser excluída."
      });
      return;
    }

    try {
      const removed =
        deletePlayerCompletely(target);

      if (!removed) {
        throw new Error(
          "Não foi possível remover o usuário."
        );
      }

      socket.emit("delete-user-result", {
        ok: true,
        player: target
      });

      console.log(
        `Perfil excluído por sorrye: ${target}`
      );
    } catch (error) {
      console.error(
        "Falha ao excluir perfil:",
        error
      );

      socket.emit("delete-user-result", {
        ok: false,
        error:
          "Não foi possível excluir o usuário."
      });
    }
  });

  socket.on("logout", () => {
    if (!socket.data.authenticated) return;

    const player = socket.data.player;

    if (
      player &&
      socketsByPlayer.get(player) === socket.id
    ) {
      socketsByPlayer.delete(player);
      computerPresence[player] = {
        state: "offline",
        idleSeconds: 0,
        updatedAt: Date.now()
      };
      touchLastSeen(player);
      leaveVoiceRoom(player);

      if (sharing[player]) {
        stopShare(player);
      }

      removeViewerEverywhere(player);
    }

    if (player && clientVersions[player]) {
      clientVersions[player].online = false;
      clientVersions[player].updatedAt = Date.now();
    }

    socket.data.player = null;
    socket.data.authenticated = false;
    socket.leave(AUTH_ROOM);
    emitClientVersions();

    emitAuthenticated("presence", presence);
    emitOnline();
    emitComputerPresence();
    emitActivity();

    socket.emit("logout-result", {
      ok: true
    });
  });

  socket.on(
    "set-presence",
    ({ status, targetAt, customText } = {}) => {
      const player =
        socket.data.player;

      if (
        !socket.data.authenticated ||
        !PLAYERS.includes(player) ||
        !allowSocketEvent(
          socket,
          "presence",
          30,
          60_000
        )
      ) {
        return;
      }

      if (!PRESENCE_STATUSES.has(status)) return;

      let normalizedTarget = null;
      let normalizedCustomText = "";

      if (status === "later") {
        const parsed = Number(targetAt);
        const now = Date.now();
        const maxFuture =
          now + (36 * 60 * 60 * 1000);

        if (
          !Number.isFinite(parsed) ||
          parsed <= now ||
          parsed > maxFuture
        ) {
          return;
        }

        normalizedTarget = parsed;
      }

      if (status === "custom") {
        normalizedCustomText =
          String(customText || "")
            .trim()
            .replace(/\s+/g, " ")
            .slice(0, 80);

        if (
          normalizedCustomText.length < 1
        ) {
          return;
        }
      }

      presence[player] = {
        ...normalizeStoredPresence(
          presence[player]
        ),
        status,
        targetAt: normalizedTarget,
        customText: normalizedCustomText
      };

      savePresenceDatabase();
      emitAuthenticated("presence", presence);
    }
  );

  socket.on(
    "client-idle-state",
    ({ state, idleSeconds } = {}) => {
      const player =
        socket.data.player;

      if (
        !socket.data.authenticated ||
        !PLAYERS.includes(player) ||
        !allowSocketEvent(
          socket,
          "client-idle-state",
          12,
          60_000
        )
      ) {
        return;
      }

      if (
        state !== "online" &&
        state !== "away"
      ) {
        return;
      }

      const normalizedIdle =
        Math.max(
          0,
          Math.min(
            7 * 24 * 60 * 60,
            Math.floor(
              Number(idleSeconds) || 0
            )
          )
        );

      computerPresence[player] = {
        state,
        idleSeconds:
          state === "away"
            ? normalizedIdle
            : 0,
        updatedAt: Date.now()
      };

      // This heartbeat also makes the persisted last-seen timestamp
      // resilient to abrupt HOST restarts.
      touchLastSeen(player);
      emitComputerPresence();
    }
  );

  socket.on(
    "set-player-activity",
    ({ activity } = {}) => {
      const player =
        socket.data.player;

      if (
        !socket.data.authenticated ||
        !PLAYERS.includes(player) ||
        !allowSocketEvent(
          socket,
          "activity",
          30,
          60_000
        )
      ) {
        return;
      }

      if (
        !PLAYER_ACTIVITY_STATES.has(activity)
      ) {
        return;
      }

      const isTaka =
        playerNameKey(player) === "taka";

      if (
        TAKA_ONLY_ACTIVITY_STATES.has(activity) &&
        !isTaka
      ) {
        return;
      }

      presence[player] = {
        ...normalizeStoredPresence(
          presence[player]
        ),
        activity
      };

      savePresenceDatabase();
      emitAuthenticated("presence", presence);
    }
  );

  socket.on("call-player", ({ to } = {}) => {
    const from =
      socket.data.player;

    if (
      !socket.data.authenticated ||
      !PLAYERS.includes(from) ||
      !PLAYERS.includes(to) ||
      !allowSocketEvent(
        socket,
        "call-player",
        10,
        30_000
      )
    ) {
      return;
    }

    const targetSocketId = socketFor(to);
    const payload = {
      from,
      to,
      at: new Date().toISOString()
    };

    if (targetSocketId) {
      io.to(targetSocketId).emit("incoming-call", payload);
    }

    socket.emit("call-result", {
      ...payload,
      delivered: !!targetSocketId
    });
  });

  socket.on("soso-headset-alert", () => {
    if (
      !allowSocketEvent(
        socket,
        "soso-alert",
        4,
        60_000
      )
    ) {
      return;
    }

    // Server-side authorization: only the authenticated `sorrye`
    // account may trigger this squad-wide alert.
    if (
      !socket.data.authenticated ||
      String(socket.data.player || "").toLowerCase() !== "sorrye"
    ) {
      socket.emit("soso-headset-alert-result", {
        ok: false,
        error: "Apenas sorrye pode enviar este alerta."
      });
      return;
    }

    const payload = {
      from: "sorrye",
      message: "FONE DO SOSO DESCARREGOU",
      at: new Date().toISOString()
    };

    let delivered = 0;

    for (const client of io.sockets.sockets.values()) {
      if (!client.data.authenticated) {
        continue;
      }

      client.emit("soso-headset-alert", payload);
      delivered += 1;
    }

    socket.emit("soso-headset-alert-result", {
      ok: true,
      delivered
    });

    console.log(
      `Alerta do fone do soso enviado para ${delivered} usuario(s).`
    );
  });

  socket.on("chat-message", ({ text } = {}) => {
    const from =
      socket.data.player;

    if (
      !socket.data.authenticated ||
      !PLAYERS.includes(from) ||
      !allowSocketEvent(
        socket,
        "chat",
        20,
        10_000
      )
    ) {
      return;
    }

    const clean =
      String(text || "")
        .trim()
        .slice(0, 500);
    if (!clean) return;

    const msg = {
      id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`,
      from,
      text: clean,
      at: new Date().toISOString()
    };

    chatHistory.push(msg);
    if (chatHistory.length > 100) chatHistory.shift();

    emitAuthenticated("chat-message", msg);
  });

  // -----------------------
  // Squad voice room
  // -----------------------

  socket.on("voice-join", () => {
    const player =
      socket.data.player;

    if (
      !socket.data.authenticated ||
      !PLAYERS.includes(player) ||
      !allowSocketEvent(
        socket,
        "voice-membership",
        20,
        60_000
      )
    ) {
      return;
    }

    const existingPeers = [
      ...voiceMembers.keys()
    ].filter(
      other => other !== player
    );

    voiceMembers.set(player, {
      muted: false,
      deafened: false
    });

    // Notify only people who were already inside the voice room.
    // This powers the local "someone joined" cue without making
    // users outside the call hear anything.
    for (const other of existingPeers) {
      const target =
        socketFor(other);

      if (target) {
        io.to(target).emit(
          "voice-peer-joined",
          {
            player
          }
        );
      }
    }

    // The new participant creates offers to everyone who was
    // already in the room. Existing peers simply answer.
    socket.emit("voice-existing-peers", {
      players: existingPeers
    });

    emitVoiceMembers();
  });

  socket.on("voice-leave", () => {
    const player =
      socket.data.player;

    if (
      !socket.data.authenticated ||
      !player ||
      !allowSocketEvent(
        socket,
        "voice-membership",
        20,
        60_000
      )
    ) {
      return;
    }

    leaveVoiceRoom(player);
  });

  socket.on(
    "voice-state",
    ({ muted, deafened }) => {
      const player =
        socket.data.player;

      if (
        !socket.data.authenticated ||
        !voiceMembers.has(player) ||
        !allowSocketEvent(
          socket,
          "voice-state",
          60,
          60_000
        )
      ) {
        return;
      }

      voiceMembers.set(player, {
        muted: !!muted,
        deafened: !!deafened
      });

      emitVoiceMembers();
    }
  );

  socket.on(
    "voice-offer",
    ({ to, sdp } = {}) => {
      const from =
        socket.data.player;

      if (
        !socket.data.authenticated ||
        !voiceMembers.has(from) ||
        !voiceMembers.has(to) ||
        !validSessionDescription(
          sdp,
          ["offer"]
        ) ||
        !allowSocketEvent(
          socket,
          "voice-sdp",
          120,
          60_000
        )
      ) {
        return;
      }

      const target =
        socketFor(to);

      if (target) {
        io.to(target).emit(
          "voice-offer",
          {
            from,
            sdp: {
              type: "offer",
              sdp: sdp.sdp
            }
          }
        );
      }
    }
  );

  socket.on(
    "voice-answer",
    ({ to, sdp } = {}) => {
      const from =
        socket.data.player;

      if (
        !socket.data.authenticated ||
        !voiceMembers.has(from) ||
        !voiceMembers.has(to) ||
        !validSessionDescription(
          sdp,
          ["answer"]
        ) ||
        !allowSocketEvent(
          socket,
          "voice-sdp",
          120,
          60_000
        )
      ) {
        return;
      }

      const target =
        socketFor(to);

      if (target) {
        io.to(target).emit(
          "voice-answer",
          {
            from,
            sdp: {
              type: "answer",
              sdp: sdp.sdp
            }
          }
        );
      }
    }
  );

  socket.on(
    "voice-ice",
    ({ to, candidate } = {}) => {
      const from =
        socket.data.player;

      const cleanCandidate =
        normalizedIceCandidate(
          candidate
        );

      if (
        !socket.data.authenticated ||
        !voiceMembers.has(from) ||
        !voiceMembers.has(to) ||
        !cleanCandidate ||
        !allowSocketEvent(
          socket,
          "voice-ice",
          600,
          60_000
        )
      ) {
        return;
      }

      const target =
        socketFor(to);

      if (target) {
        io.to(target).emit(
          "voice-ice",
          {
            from,
            candidate:
              cleanCandidate
          }
        );
      }
    }
  );

  // -----------------------
  // Screen sharing state
  // -----------------------

  socket.on("screen-share-started", () => {
    const player =
      socket.data.player;

    if (
      !socket.data.authenticated ||
      !PLAYERS.includes(player) ||
      !allowSocketEvent(
        socket,
        "screen-state",
        30,
        60_000
      )
    ) {
      return;
    }

    sharing[player] = true;
    emitAuthenticated(
      "screen-sharing",
      sharing
    );
  });

  socket.on("screen-share-stopped", () => {
    const player =
      socket.data.player;

    if (
      !socket.data.authenticated ||
      !PLAYERS.includes(player) ||
      !allowSocketEvent(
        socket,
        "screen-state",
        30,
        60_000
      )
    ) {
      return;
    }

    stopShare(player);
  });

  socket.on(
    "screen-watch-request",
    ({ sharer } = {}) => {
      const viewer =
        socket.data.player;

      if (
        !socket.data.authenticated ||
        !PLAYERS.includes(viewer) ||
        !PLAYERS.includes(sharer) ||
        viewer === sharer ||
        !sharing[sharer] ||
        !allowSocketEvent(
          socket,
          "screen-watch",
          120,
          60_000
        )
      ) {
        return;
      }

      const sharerSocket = socketFor(sharer);
    if (!sharerSocket) {
      socket.emit("screen-share-ended", { player: sharer });
      return;
    }

    // A viewer may watch multiple sharers simultaneously.
    // Set keeps each viewer unique per sharer.
    watchersBySharer.get(sharer).add(viewer);

    io.to(sharerSocket).emit(
      "screen-watch-request",
      {
        viewer
      }
    );
  }
  );

  socket.on(
    "screen-stop-watching",
    ({ sharer } = {}) => {
      const viewer =
        socket.data.player;

      if (
        !socket.data.authenticated ||
        !PLAYERS.includes(viewer) ||
        !PLAYERS.includes(sharer) ||
        !allowSocketEvent(
          socket,
          "screen-watch",
          120,
          60_000
        )
      ) {
        return;
      }
      watchersBySharer
        .get(sharer)
        ?.delete(viewer);

    const sharerSocket = socketFor(sharer);
      if (sharerSocket) {
        io.to(sharerSocket).emit(
          "screen-viewer-left",
          {
            viewer
          }
        );
      }
    }
  );

  // -----------------------
  // WebRTC signaling relay
  // -----------------------

  socket.on(
    "webrtc-offer",
    ({ to, sdp } = {}) => {
      const from =
        socket.data.player;

      const allowed =
        sharing[from] === true &&
        watchersBySharer
          .get(from)
          ?.has(to);

      if (
        !socket.data.authenticated ||
        !PLAYERS.includes(from) ||
        !PLAYERS.includes(to) ||
        !allowed ||
        !validSessionDescription(
          sdp,
          ["offer"]
        ) ||
        !allowSocketEvent(
          socket,
          "screen-sdp",
          180,
          60_000
        )
      ) {
        return;
      }

      const target =
        socketFor(to);

      if (target) {
        io.to(target).emit(
          "webrtc-offer",
          {
            from,
            sdp: {
              type: "offer",
              sdp: sdp.sdp
            }
          }
        );
      }
    }
  );

  socket.on(
    "webrtc-answer",
    ({ to, sdp } = {}) => {
      const from =
        socket.data.player;

      const allowed =
        sharing[to] === true &&
        watchersBySharer
          .get(to)
          ?.has(from);

      if (
        !socket.data.authenticated ||
        !PLAYERS.includes(from) ||
        !PLAYERS.includes(to) ||
        !allowed ||
        !validSessionDescription(
          sdp,
          ["answer"]
        ) ||
        !allowSocketEvent(
          socket,
          "screen-sdp",
          180,
          60_000
        )
      ) {
        return;
      }

      const target =
        socketFor(to);

      if (target) {
        io.to(target).emit(
          "webrtc-answer",
          {
            from,
            sdp: {
              type: "answer",
              sdp: sdp.sdp
            }
          }
        );
      }
    }
  );

  socket.on(
    "webrtc-ice",
    ({
      to,
      candidate,
      purpose
    } = {}) => {
      const from =
        socket.data.player;

      const cleanCandidate =
        normalizedIceCandidate(
          candidate
        );

      const normalizedPurpose =
        purpose === "answerer"
          ? "answerer"
          : "offerer";

      const allowed =
        normalizedPurpose === "offerer"
          ? (
              sharing[from] === true &&
              watchersBySharer
                .get(from)
                ?.has(to)
            )
          : (
              sharing[to] === true &&
              watchersBySharer
                .get(to)
                ?.has(from)
            );

      if (
        !socket.data.authenticated ||
        !PLAYERS.includes(from) ||
        !PLAYERS.includes(to) ||
        !cleanCandidate ||
        !allowed ||
        !allowSocketEvent(
          socket,
          "screen-ice",
          800,
          60_000
        )
      ) {
        return;
      }

      const target =
        socketFor(to);

      if (target) {
        io.to(target).emit(
          "webrtc-ice",
          {
            from,
            candidate:
              cleanCandidate,
            purpose:
              normalizedPurpose
          }
        );
      }
    }
  );

  socket.on("disconnect", () => {
    if (socket.data.versionKickTimer) {
      clearTimeout(socket.data.versionKickTimer);
      socket.data.versionKickTimer = null;
    }
    const player = socket.data.player;

    if (player && socketsByPlayer.get(player) === socket.id) {
      socketsByPlayer.delete(player);
      computerPresence[player] = {
        state: "offline",
        idleSeconds: 0,
        updatedAt: Date.now()
      };
      touchLastSeen(player);
      leaveVoiceRoom(player);

      if (sharing[player]) {
        stopShare(player);
      }

      removeViewerEverywhere(player);

      if (clientVersions[player]) {
        clientVersions[player].online = false;
        clientVersions[player].updatedAt = Date.now();
      }

      emitAuthenticated("presence", presence);
      emitOnline();
      emitComputerPresence();
      emitClientVersions();
      emitActivity();
    }
  });
});

const PORT = Number(process.env.PORT || 3000);

setTimeout(refreshUpdatePolicy, 2500);
setInterval(refreshUpdatePolicy, UPDATE_CHECK_INTERVAL_MS);

const iceRefreshTimer = setInterval(() => {
  emitAuthenticated("ice-config", {
    iceServers: iceServersForClient()
  });
}, ICE_REFRESH_INTERVAL_MS);
iceRefreshTimer.unref?.();

server.listen(PORT, BIND_HOST, () => {
  console.log("");
  console.log("======================================");
  console.log(` Chat dos Pecinha Server ONLINE ${BIND_HOST}:${PORT}`);
  console.log(` Cloud proxy trust: ${TRUST_PROXY ? "ON" : "OFF"}`);
  console.log(` TURN: ${TURN_HOST && TURN_SECRET ? "ON" : "STUN only"}`);
  console.log(" Screen Share signaling: ON");
  console.log("======================================");
  console.log("");
});
