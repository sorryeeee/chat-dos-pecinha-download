param(
    [Parameter(Mandatory = $true)]
    [string]$ArenaRoot,

    [Parameter(Mandatory = $true)]
    [string]$UserDataPath,

    [int]$MainPid = 0
)

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"

function Write-Step {
    param([string]$Text)
    Write-Host "" 
    Write-Host ("==> " + $Text) -ForegroundColor Cyan
}

function Remove-PathSafe {
    param([string]$Path)
    if (-not $Path) { return }
    if (Test-Path -LiteralPath $Path) {
        try {
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            Write-Host ("Removido: " + $Path) -ForegroundColor Green
        }
        catch {
            Write-Warning ("Nao foi possivel remover agora: " + $Path + " | " + $_.Exception.Message)
        }
    }
}

function Stop-ArenaProcesses {
    param([string]$Root)

    try {
        $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object {
                $_.ProcessId -ne $PID -and
                $_.ExecutablePath -and
                ([IO.Path]::GetFullPath([string]$_.ExecutablePath)).StartsWith(
                    $rootFull,
                    [StringComparison]::OrdinalIgnoreCase
                )
            } |
            ForEach-Object {
                try {
                    Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop
                }
                catch {}
            }
    }
    catch {}
}

function Remove-RunEntriesForArena {
    param([string]$Root)

    $runKeys = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"
    )

    foreach ($key in $runKeys) {
        if (-not (Test-Path $key)) { continue }
        try {
            $props = Get-ItemProperty -Path $key -ErrorAction Stop
            foreach ($property in $props.PSObject.Properties) {
                if ($property.Name -like "PS*") { continue }
                $value = [string]$property.Value
                if (
                    $value -and
                    (
                        $value.IndexOf($Root, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                        $value.IndexOf("ArenaSquad", [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                        $value.IndexOf("Chat dos Pecinha", [StringComparison]::OrdinalIgnoreCase) -ge 0
                    )
                ) {
                    Remove-ItemProperty -Path $key -Name $property.Name -Force -ErrorAction SilentlyContinue
                    Write-Host ("Inicializacao automatica removida: " + $property.Name) -ForegroundColor Green
                }
            }
        }
        catch {}
    }
}

function Invoke-TailscaleUninstall {
    Write-Step "Desconectando e desinstalando Tailscale"

    $tailscaleExeCandidates = @(
        (Join-Path $env:ProgramFiles "Tailscale\tailscale.exe"),
        $(if (${env:ProgramFiles(x86)}) { Join-Path ${env:ProgramFiles(x86)} "Tailscale\tailscale.exe" } else { $null })
    ) | Where-Object { $_ }

    foreach ($exe in $tailscaleExeCandidates) {
        if (Test-Path -LiteralPath $exe) {
            try { & $exe logout 2>$null | Out-Null } catch {}
            break
        }
    }

    try { Stop-Service Tailscale -Force -ErrorAction SilentlyContinue } catch {}

    $uninstalled = $false
    $winget = $null
    try {
        $winget = (Get-Command winget.exe -ErrorAction Stop).Source
    }
    catch {}

    if ($winget) {
        try {
            & $winget uninstall --id "Tailscale.Tailscale" --exact --silent --disable-interactivity 2>$null
            if ($LASTEXITCODE -eq 0) {
                $uninstalled = $true
                Write-Host "Tailscale removido pelo winget." -ForegroundColor Green
            }
        }
        catch {}
    }

    if (-not $uninstalled) {
        $uninstallRoots = @(
            "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
            "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
            "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
        )

        $entry = Get-ItemProperty $uninstallRoots -ErrorAction SilentlyContinue |
            Where-Object { [string]$_.DisplayName -like "Tailscale*" } |
            Select-Object -First 1

        if ($entry) {
            $command = [string]$entry.QuietUninstallString
            if (-not $command) { $command = [string]$entry.UninstallString }

            try {
                $productCode = $null
                if ($command -match '\{[0-9A-Fa-f-]{36}\}') {
                    $productCode = $Matches[0]
                }

                if ($productCode) {
                    Start-Process msiexec.exe -ArgumentList @(
                        "/x", $productCode, "/qn", "/norestart"
                    ) -Wait
                    $uninstalled = $true
                }
                elseif ($command) {
                    Start-Process cmd.exe -ArgumentList @(
                        "/d", "/s", "/c", $command
                    ) -Wait -WindowStyle Hidden
                    $uninstalled = $true
                }
            }
            catch {
                Write-Warning ("Falha no desinstalador registrado do Tailscale: " + $_.Exception.Message)
            }
        }
    }

    try { Stop-Service Tailscale -Force -ErrorAction SilentlyContinue } catch {}
    try { sc.exe delete Tailscale 2>$null | Out-Null } catch {}

    Remove-PathSafe "C:\ProgramData\Tailscale"
    Remove-PathSafe (Join-Path $env:LOCALAPPDATA "Tailscale")
    Remove-PathSafe "C:\Windows\System32\config\systemprofile\AppData\Local\Tailscale"
    Remove-PathSafe (Join-Path $env:ProgramFiles "Tailscale")
    if (${env:ProgramFiles(x86)}) {
        Remove-PathSafe (Join-Path ${env:ProgramFiles(x86)} "Tailscale")
    }

    $tailscaleShortcuts = @(
        (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Tailscale.lnk"),
        "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Tailscale.lnk"
    )
    foreach ($shortcut in $tailscaleShortcuts) {
        Remove-Item -LiteralPath $shortcut -Force -ErrorAction SilentlyContinue
    }
}

Write-Host "============================================================" -ForegroundColor Red
Write-Host " CHAT DOS PECINHA - DESINSTALACAO FINAL" -ForegroundColor Red
Write-Host "============================================================" -ForegroundColor Red
Write-Host ""
Write-Host "Esta rotina foi iniciada apos confirmacao dentro do app."
Write-Host "Ela remove Chat dos Pecinha e Tailscale deste PC."
Write-Host ""

# Guard rails: never recursively delete an arbitrary path passed to this script.
try {
    $arenaRootFull = [IO.Path]::GetFullPath($ArenaRoot).TrimEnd('\')
    $manifestPath = Join-Path $arenaRootFull "desktop\package.json"
    $validArena = $false

    if (Test-Path -LiteralPath $manifestPath) {
        try {
            $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
            $validArena = ([string]$manifest.name -eq "arena-squad-desktop")
        }
        catch {}
    }

    $canonicalArena = [IO.Path]::GetFullPath(
        (Join-Path $env:LOCALAPPDATA "ArenaSquad")
    ).TrimEnd('\')

    if (-not $validArena -and $arenaRootFull -ne $canonicalArena) {
        throw "Pasta do Chat dos Pecinha nao passou na verificacao de seguranca: $arenaRootFull"
    }

    $userDataFull = [IO.Path]::GetFullPath($UserDataPath).TrimEnd('\')
    $appDataFull = [IO.Path]::GetFullPath($env:APPDATA).TrimEnd('\') + '\'
    if (
        -not $userDataFull.StartsWith($appDataFull, [StringComparison]::OrdinalIgnoreCase) -or
        [IO.Path]::GetFileName($userDataFull) -ne "arena-squad-desktop"
    ) {
        throw "Pasta de dados do Electron nao passou na verificacao de seguranca."
    }
}
catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    Read-Host "Pressione ENTER para fechar"
    exit 2
}

Write-Step "Encerrando componentes do Chat dos Pecinha"

try {
    Stop-ScheduledTask -TaskName "Arena Squad Server" -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName "Arena Squad Server" -Confirm:$false -ErrorAction SilentlyContinue
}
catch {}

if ($MainPid -gt 0) {
    try { Stop-Process -Id $MainPid -Force -ErrorAction SilentlyContinue } catch {}
}

Start-Sleep -Milliseconds 500
Stop-ArenaProcesses $arenaRootFull
Start-Sleep -Milliseconds 500

Write-Step "Removendo regras de Firewall e inicializacao"
foreach ($ruleName in @(
    "Arena Squad WebRTC UDP - Tailscale",
    "Arena Squad WebRTC TCP - Tailscale",
    "Arena Squad Server TCP 3000 - Tailscale"
)) {
    try {
        Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue |
            Remove-NetFirewallRule -ErrorAction SilentlyContinue
    }
    catch {}
}
Remove-RunEntriesForArena $arenaRootFull

Write-Step "Removendo atalhos"
$shortcutDirs = @(
    [Environment]::GetFolderPath("Desktop"),
    (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"),
    "C:\Users\Public\Desktop",
    "C:\ProgramData\Microsoft\Windows\Start Menu\Programs"
) | Where-Object { $_ }

foreach ($dir in $shortcutDirs) {
    foreach ($name in @(
        "Chat dos Pecinha.lnk",
        "Chat dos Pecinha HOST.lnk",
        "Arena Squad.lnk",
        "Arena Squad HOST.lnk"
    )) {
        Remove-Item -LiteralPath (Join-Path $dir $name) -Force -ErrorAction SilentlyContinue
    }
}

Write-Step "Removendo arquivos e dados do Chat dos Pecinha"
Remove-PathSafe $userDataFull
Remove-PathSafe $arenaRootFull

foreach ($pattern in @(
    "chat-dos-pecinha-install-*.ps1",
    "chat-dos-pecinha-update-launch-*.ps1",
    "arena-squad-update-*",
    "pecinha-cloud-data-*"
)) {
    Get-ChildItem -LiteralPath $env:TEMP -Filter $pattern -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -ne $PSCommandPath } |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}
Remove-Item -LiteralPath (Join-Path $env:TEMP "arena-squad-install.log") -Force -ErrorAction SilentlyContinue

Invoke-TailscaleUninstall

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host " LIMPEZA CONCLUIDA" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host "Chat dos Pecinha e Tailscale foram removidos deste PC."
Write-Host "Se o adaptador do Tailscale ainda aparecer ate o proximo reboot, reinicie o Windows."
Write-Host ""

$selfPath = $PSCommandPath
Read-Host "Pressione ENTER para fechar"
try { Remove-Item -LiteralPath $selfPath -Force -ErrorAction SilentlyContinue } catch {}
exit 0
