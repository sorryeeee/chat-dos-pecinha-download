const fs = require("fs");
const path = require("path");
const util = require("util");

const logFile = path.join(__dirname, "arena-server.log");

function writeLog(level, args) {
  try {
    const text = args
      .map(value =>
        typeof value === "string"
          ? value
          : util.inspect(value, { depth: 4 })
      )
      .join(" ");

    fs.appendFileSync(
      logFile,
      `[${new Date().toISOString()}] [${level}] ${text}\n`,
      "utf8"
    );
  } catch {}
}

const originalLog = console.log.bind(console);
const originalError = console.error.bind(console);
const originalWarn = console.warn.bind(console);

console.log = (...args) => {
  writeLog("INFO", args);
  originalLog(...args);
};

console.error = (...args) => {
  writeLog("ERROR", args);
  originalError(...args);
};

console.warn = (...args) => {
  writeLog("WARN", args);
  originalWarn(...args);
};

process.on("uncaughtException", error => {
  writeLog("FATAL", [
    error?.stack || error?.message || error
  ]);

  process.exitCode = 1;
});

process.on("unhandledRejection", error => {
  writeLog("REJECTION", [
    error?.stack || error?.message || error
  ]);

  process.exitCode = 1;
});

writeLog("INFO", [
  "Chat dos Pecinha scheduled server launcher starting.",
  `Node ${process.version}`
]);

try {
  require("./index.js");
} catch (error) {
  writeLog("FATAL", [
    error?.stack || error?.message || error
  ]);

  process.exit(1);
}
