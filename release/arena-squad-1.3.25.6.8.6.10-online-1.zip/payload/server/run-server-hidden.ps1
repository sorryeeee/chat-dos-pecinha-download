$ErrorActionPreference = "Stop"

$node = Join-Path `
    $PSScriptRoot `
    "..\runtime\node\node.exe"

if (-not (Test-Path $node)) {
    $node = $null

    try {
        $node = (
            Get-Command `
                node.exe `
                -ErrorAction Stop
        ).Source
    }
    catch {}

    if (-not $node) {
        $candidate = Join-Path `
            $env:ProgramFiles `
            "nodejs\node.exe"

        if (Test-Path $candidate) {
            $node = $candidate
        }
    }
}

if (-not $node -or -not (Test-Path $node)) {
    exit 127
}

$launcher = Join-Path `
    $PSScriptRoot `
    "launcher.js"

if (-not (Test-Path $launcher)) {
    exit 2
}

Set-Location $PSScriptRoot

& $node $launcher

if ($LASTEXITCODE -is [int]) {
    exit $LASTEXITCODE
}

exit 0
