const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const root = process.argv[2];

if (!root) {
  console.error("Arena root ausente.");
  process.exit(1);
}

const serverDir = path.join(root, "server");
const authFile = path.join(serverDir, "profile-auth.json");
const adminFile = path.join(root, "SENHAS-ARENA-SQUAD-ADMIN.txt");

const players = [
  "sorrye",
  "dealer",
  "taka",
  "sage",
  "gordao trem balinha"
];

if (fs.existsSync(authFile)) {
  console.log("profile-auth.json ja existe; mantendo senhas atuais.");
  process.exit(0);
}

const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
const lower = "abcdefghijkmnopqrstuvwxyz";
const digits = "23456789";
const symbols = "!@#$%";
const all = upper + lower + digits + symbols;

function choice(chars) {
  return chars[crypto.randomInt(0, chars.length)];
}

function password() {
  const chars = [
    choice(upper),
    choice(lower),
    choice(digits),
    choice(symbols)
  ];

  while (chars.length < 14) {
    chars.push(choice(all));
  }

  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }

  return chars.join("");
}

const db = {
  version: 1,
  algorithm: "scrypt",
  profiles: {}
};

const plain = {};

for (const player of players) {
  const pass = password();
  const salt = crypto.randomBytes(16);
  const params = {
    N: 32768,
    r: 8,
    p: 1,
    maxmem: 128 * 1024 * 1024
  };

  const hash = crypto.scryptSync(
    pass,
    salt,
    64,
    params
  );

  plain[player] = pass;

  db.profiles[player] = {
    salt: salt.toString("hex"),
    hash: hash.toString("hex"),
    params: {
      N: params.N,
      r: params.r,
      p: params.p
    }
  };
}

fs.mkdirSync(serverDir, { recursive: true });
fs.writeFileSync(
  authFile,
  JSON.stringify(db, null, 2),
  "utf8"
);

const lines = [
  "CHAT DOS PECINHA - SENHAS GERADAS NO HOST",
  "=====================================",
  "",
  "GUARDE ESTE ARQUIVO SOMENTE COM O ADMIN.",
  ""
];

for (const player of players) {
  lines.push(`${player}: ${plain[player]}`);
}

lines.push(
  "",
  "O servidor guarda somente salt + hash scrypt.",
  ""
);

fs.writeFileSync(
  adminFile,
  lines.join("\n"),
  "utf8"
);

console.log("");
console.log("Senhas criadas com sucesso.");
console.log(`Arquivo ADMIN: ${adminFile}`);
